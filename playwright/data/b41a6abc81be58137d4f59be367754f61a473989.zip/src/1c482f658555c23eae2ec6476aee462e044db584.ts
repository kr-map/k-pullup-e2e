import type { ResultSetHeader } from 'mysql2/promise';
import { test, expect } from '../fixtures';

const root = '/api/v1/community/workouts';

test('reviewed public workouts enforce capacity, privacy and the safety cutoff', async ({ api, db, users }) => {
  const [host, moderator, ...visitors] = await Promise.all([
    users.create(), users.create({ admin: true }), users.create(), users.create(), users.create(), users.create(),
  ]);
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location, Address) VALUES (?, ST_GeomFromText('POINT(37.25 127.05)', 4326), ?)",
    [host.userId, '경기도 수원시 영통구 영통동 123'],
  );
  const markerId = marker.insertId;
  await db.execute('INSERT INTO WorkoutPlaces (MarkerID, PlaceName) VALUES (?, ?)', [markerId, '공개 공원 철봉']);
  try {
    const scope = '?markerId=' + markerId;
    const day = new Date(Date.now() + 33 * 3_600_000).toISOString().slice(0, 10);
    const input = { markerId, kind: 'pullup', day, start: '10:00', minutes: 45, capacity: 4, rulesAccepted: true };
    expect(await (await api.get(root + '/availability')).json()).toEqual({ enabled: true });
    expect((await api.post(root, { data: input })).status()).toBe(401);
    expect((await host.api.post(root, { data: { ...input, start: '23:00' } })).status()).toBe(400);
    const created = await host.api.post(root, { data: input });
    expect(created.status(), await created.text()).toBe(201);
    const { id } = await created.json();
    const event = root + '/' + id;
    const review = root + '/moderation/' + id;
    expect((await host.api.post(root, { data: input })).status()).toBe(409);
    expect(await (await api.get(root + scope)).json()).toEqual({ events: [], places: [] });
    expect(await (await host.api.get(root + scope)).json()).toMatchObject({ events: [{ id, state: 'pending' }] });
    expect((await visitors[0].api.put(review, { data: { decision: 'approve' } })).status()).toBe(403);
    expect((await moderator.api.put(review, { data: { decision: 'approve' } })).status()).toBe(204);
    expect((await api.put(event + '/participation', { data: { rulesAccepted: true } })).status()).toBe(401);

    const decisions = await Promise.all(visitors.map((visitor) =>
      visitor.api.put(event + '/participation', { data: { rulesAccepted: true } })));
    expect(decisions.map((response) => response.status()).sort()).toEqual([204, 204, 204, 409]);
    const published = (await (await api.get(root + scope)).json()).events[0];
    expect(published).toMatchObject({ id, state: 'published', participants: 4, joined: false });
    expect(published).not.toHaveProperty('participantIds');
    const joined = visitors.filter((_, i) => decisions[i].status() === 204);
    expect((await joined[0].api.put(event + '/participation', { data: { rulesAccepted: true } })).status()).toBe(204);

    expect((await joined[0].api.post(event + '/report', { data: { reason: 'purpose' } })).status()).toBe(204);
    expect((await joined[0].api.post(event + '/report', { data: { reason: 'purpose' } })).status()).toBe(204);
    const moderation = await moderator.api.get(root + '/moderation');
    expect(moderation.status(), await moderation.text()).toBe(200);
    expect(await moderation.json()).toEqual(expect.arrayContaining([expect.objectContaining({ id, reportCount: 1, reasons: 'purpose' })]));
    expect((await moderator.api.put(review, { data: { decision: 'dismiss' } })).status()).toBe(204);

    await db.execute('UPDATE CommunityWorkouts SET StartsAt = UTC_TIMESTAMP() + INTERVAL 20 MINUTE WHERE WorkoutID = ?', [id]);
    for (const visitor of joined.slice(0, 2)) expect((await visitor.api.delete(event + '/participation')).status()).toBe(204);
    expect(await (await api.get(root + scope)).json()).toMatchObject({ events: [{ id, participants: 2, state: 'cancelled' }] });
    expect((await visitors[0].api.put(event + '/participation', { data: { rulesAccepted: true } })).status()).toBe(409);
    expect((await visitors[0].api.delete(event)).status()).toBe(404);
    expect((await host.api.delete(event)).status()).toBe(204);
  } finally {
    await db.execute('DELETE FROM Markers WHERE MarkerID = ?', [markerId]);
  }
});

import { expect, request, type APIRequestContext } from '@playwright/test';
import { randomInt } from 'node:crypto';
import WebSocket from 'ws';
import { latestMail, newContext, randomIP, type User } from '../fixtures';

// 1x1 PNG, enough for the byte sniffer.
export const PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
  'base64',
);

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** A Seoul land coordinate far enough from other tests' markers (10 m proximity rule). */
export const seoulSpot = () => ({
  latitude: Number((37.45 + randomInt(250_000) / 1e6).toFixed(6)),
  longitude: Number((126.85 + randomInt(300_000) / 1e6).toFixed(6)),
});

export async function createMarker(user: User, description = 'e2e marker') {
  const spot = seoulSpot();
  const res = await user.api.post('/api/v1/markers', {
    multipart: { latitude: String(spot.latitude), longitude: String(spot.longitude), description },
  });
  expect(res.status(), await res.text()).toBe(201);
  return { ...(await res.json()), ...spot } as { markerId: number; latitude: number; longitude: number; description: string };
}

export async function createReport(reporter: User, marker: { markerId: number; latitude: number; longitude: number }, description = 'e2e report') {
  const res = await reporter.api.post('/api/v1/reports', {
    multipart: {
      markerId: String(marker.markerId),
      latitude: String(marker.latitude),
      longitude: String(marker.longitude),
      description,
      photos: { name: 'r.png', mimeType: 'image/png', buffer: PNG },
    },
  });
  expect(res.status(), await res.text()).toBeLessThan(300);
}

async function newestMailId(email: string): Promise<string | undefined> {
  const ctx = await request.newContext({ baseURL: 'http://127.0.0.1:28025' });
  try {
    const res = await ctx.get(`/api/v1/search?query=${encodeURIComponent(`to:"${email}"`)}&limit=1`);
    return (await res.json()).messages?.[0]?.ID;
  } finally {
    await ctx.dispose();
  }
}

/** Sends and confirms a verify-email code for `email`, as the signup and email-change flows need. */
export async function verifyEmail(baseURL: string | undefined, email: string) {
  const anon = await newContext(baseURL, randomIP());
  try {
    const before = await newestMailId(email);
    expect((await anon.post('/api/v1/auth/verify-email/send', { form: { email } })).status()).toBe(200);
    await expect.poll(() => newestMailId(email), { timeout: 10_000 }).not.toBe(before); // the address may already have an old code mail
    const code = (await latestMail(email)).match(/\b\d{6}\b/)?.[0];
    expect(code, 'six-digit code in verification mail').toBeTruthy();
    expect((await anon.post('/api/v1/auth/verify-email/confirm', { form: { email, token: code! } })).status()).toBe(200);
  } finally {
    await anon.dispose();
  }
}

/** Runs the verify-email + signup flow for an exact address. */
export async function signupWith(baseURL: string | undefined, email: string, password: string) {
  await verifyEmail(baseURL, email);
  const anon = await newContext(baseURL, randomIP());
  try {
    const res = await anon.post('/api/v1/auth/signup', { data: { email, password } });
    return { status: res.status(), body: await res.text() };
  } finally {
    await anon.dispose();
  }
}

/** Logs in and returns the encrypted cookie value plus a client that sends it. */
export async function loginSession(baseURL: string | undefined, email: string, password: string, ip = randomIP()) {
  const anon = await newContext(baseURL, ip);
  const res = await anon.post('/api/v1/auth/login', { data: { email, password } });
  expect(res.status(), await res.text()).toBe(200);
  await anon.dispose();
  const cookie = res.headersArray().find((h) => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('token='))!;
  const value = cookie.value.split(';')[0].slice('token='.length);
  const api = await newContext(baseURL, ip, value);
  return { cookie: value, api };
}

export type Notice = { notificationId: number; userId: string; type: string; title: string; message: string; metadata?: unknown };

/** Notification socket that records every frame it gets. */
export class NotificationSocket {
  readonly frames: any[] = [];
  closed = false;
  private constructor(private ws: WebSocket) {
    ws.on('message', (d) => {
      try { this.frames.push(JSON.parse(d.toString())); } catch { this.frames.push(d.toString()); }
    });
    ws.on('close', () => { this.closed = true; });
  }

  static async open(baseURL: string | undefined, opts: { cookie?: string; requestId?: string } = {}) {
    const url = new URL('/ws/notification', baseURL!.replace(/^http/, 'ws'));
    if (opts.requestId) url.searchParams.set('request-id', opts.requestId);
    const headers: Record<string, string> = { 'Fly-Client-IP': randomIP(), Origin: 'https://www.k-pullup.com' }; // server checks Origin
    if (opts.cookie) headers.Cookie = `token=${opts.cookie}`;
    const ws = new WebSocket(url, { headers });
    const sock = new NotificationSocket(ws);
    await new Promise<void>((ok, fail) => { ws.once('open', () => ok()); ws.once('error', fail); });
    return sock;
  }

  async waitFor(pred: (f: any) => boolean, timeoutMs = 5_000) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const hit = this.frames.find(pred);
      if (hit) return hit;
      await sleep(50);
    }
    return undefined;
  }

  async waitClosed(timeoutMs = 3_000) {
    const deadline = Date.now() + timeoutMs;
    while (!this.closed && Date.now() < deadline) await sleep(50);
    return this.closed;
  }

  close() { this.ws.close(); }
}

export const postNotification = (admin: APIRequestContext, body: Record<string, unknown>) =>
  admin.post('/notification', { data: body });

/** Posts probes (personal Like by default, or a broadcast type) until one arrives, so the socket's Redis subscription is live. */
export async function waitSubscribed(sock: NotificationSocket, admin: APIRequestContext, channelId: string, type = 'Like') {
  for (let i = 0; i < 30; i++) {
    const title = `probe-${channelId}-${i}`;
    expect((await postNotification(admin, { userId: channelId, type, title, message: 'probe' })).status()).toBe(200);
    if (await sock.waitFor((f) => f.title === title, 300)) return;
  }
  throw new Error(`notification socket for ${channelId} never subscribed`);
}

import { test, expect, newContext, randomIP, type User } from '../fixtures';
import { createMarker, markerMultipart, offsetNorth, randomLandPoint, tinyPng, waitForAddress, type CreatedMarker, type Point } from '../helpers/markers';

const qs = (p: Point) => `latitude=${p.lat}&longitude=${p.lng}`;
// Coordinates read back from MySQL POINTs can differ in the last float digits.
const near = (m: { latitude: number; longitude: number }) => ({ latitude: expect.closeTo(m.latitude, 6), longitude: expect.closeTo(m.longitude, 6) });
const SEA: Point = { lat: 36.6, lng: 125.8 }; // mock: Yellow Sea, still inside the Asia/Seoul timezone
const TSUSHIMA: Point = { lat: 34.4, lng: 129.3 }; // Japan
const PYONGYANG: Point = { lat: 38.99, lng: 125.75 }; // North Korea

test.describe('create marker', () => {
  test('a user creates a marker with a photo and the photo is served from storage', async ({ users, api }) => {
    const alice = await users.create();
    const at = randomLandPoint();
    const res = await alice.api.post('/api/v1/markers', { multipart: markerMultipart({ at, description: '공원 철봉', photos: 1 }) });
    expect(res.status(), await res.text()).toBe(201);
    const created = await res.json();
    expect(created).toMatchObject({ markerId: expect.any(Number), latitude: at.lat, longitude: at.lng, description: '공원 철봉' });

    const details = await (await api.get(`/api/v1/markers/${created.markerId}/details`)).json();
    expect(details.photos).toHaveLength(1);
    expect(details.photos[0]).toMatchObject({ photoId: expect.any(Number), markerId: created.markerId, photoUrl: expect.stringMatching(/^http.*\.png$/) });
    const photo = await api.get(details.photos[0].photoUrl);
    expect(photo.status()).toBe(200);
    expect(photo.headers()['x-amz-meta-photo-watermark']).toBe('logo-balanced-3-angle-v2');
    const stored = await photo.body();
    expect(stored.subarray(0, 8).equals(tinyPng().subarray(0, 8))).toBe(true); // Still PNG.
    expect(stored.readUInt32BE(16)).toBe(8);
    expect(stored.readUInt32BE(20)).toBe(8);
  });

  test('photos are optional', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.post('/api/v1/markers', { multipart: markerMultipart() });
    expect(res.status(), await res.text()).toBe(201);
  });

  test('the /markers/new alias creates a marker like the frontend does', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.post('/api/v1/markers/new', { multipart: markerMultipart() });
    expect(res.status(), await res.text()).toBe(201);
  });

  test('an anonymous client cannot create a marker', async ({ api }) => {
    const res = await api.post('/api/v1/markers', { multipart: markerMultipart() });
    expect(res.status()).toBe(401);
  });

  test('a non-image file named .jpg is rejected with 400 and no marker is left behind', async ({ users, api }) => {
    const alice = await users.create();
    const at = randomLandPoint();
    const res = await alice.api.post('/api/v1/markers', {
      multipart: { latitude: String(at.lat), longitude: String(at.lng), description: 'x', photos: { name: 'evil.jpg', mimeType: 'image/jpeg', buffer: Buffer.from('<svg onload=alert(1)></svg>') } },
    });
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toBeTruthy();
    expect((await api.get(`/api/v1/markers/verify?${qs(at)}`)).status(), 'location is still free').toBe(200);
  });

  test('missing or non-numeric coordinates get 400', async ({ users }) => {
    const alice = await users.create();
    for (const multipart of [{ description: 'no coords' }, { latitude: 'abc', longitude: '127.5' }, { latitude: '36.5', longitude: '' }]) {
      const res = await alice.api.post('/api/v1/markers', { multipart });
      expect(res.status(), JSON.stringify(multipart)).toBe(400);
      expect((await res.json()).error).toBeTruthy();
    }
  });

  test('coordinates outside South Korea are rejected with 403', async ({ users }) => {
    const alice = await users.create();
    for (const at of [TSUSHIMA, PYONGYANG, { lat: 35.68, lng: 139.69 }]) {
      const res = await alice.api.post('/api/v1/markers', { multipart: markerMultipart({ at }) });
      expect(res.status(), JSON.stringify(at)).toBe(403);
    }
  });

  test('coordinates in the sea are rejected', async ({ users }) => {
    test.fail(true, 'BUG: sea markers are accepted; FetchRegionWaterInfo (IS_WATER_API) is never called on create');
    const alice = await users.create();
    const at = { lat: SEA.lat + Math.random() * 0.1, lng: SEA.lng + Math.random() * 0.1 };
    const res = await alice.api.post('/api/v1/markers', { multipart: markerMultipart({ at }) });
    // A sea marker never gets an address, and NULL addresses break other endpoints, so don't leave it behind.
    if (res.status() === 201) await alice.api.delete(`/api/v1/markers/${(await res.json()).markerId}`);
    expect(res.status()).toBeGreaterThanOrEqual(400);
    expect(res.status()).toBeLessThan(500);
  });

  test('a second marker within 10 m of an existing one gets 409, one 50 m away is fine', async ({ users }) => {
    const alice = await users.create();
    const bob = await users.create();
    const first = await createMarker(alice);
    const at = { lat: first.latitude, lng: first.longitude };

    const close = await bob.api.post('/api/v1/markers', { multipart: markerMultipart({ at: offsetNorth(at, 3) }) });
    expect(close.status()).toBe(409);
    expect((await close.json()).error).toBeTruthy();

    const far = await bob.api.post('/api/v1/markers', { multipart: markerMultipart({ at: offsetNorth(at, 50) }) });
    expect(far.status(), await far.text()).toBe(201);
  });

  test('a description with a bad word is rejected with 400', async ({ users, api }) => {
    const alice = await users.create();
    const at = randomLandPoint();
    const res = await alice.api.post('/api/v1/markers', { multipart: markerMultipart({ at, description: '여기 철봉 fuck 좋아요' }) });
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toBeTruthy();
    expect((await api.get(`/api/v1/markers/verify?${qs(at)}`)).status(), 'no marker was stored').toBe(200);
  });

  test('a restricted area is rejected with 422', async ({ users, db }) => {
    const alice = await users.create();
    const at = randomLandPoint();
    const d = 0.001; // SRID 4326 axis order is lat lng
    const ring = [[at.lat - d, at.lng - d], [at.lat - d, at.lng + d], [at.lat + d, at.lng + d], [at.lat + d, at.lng - d], [at.lat - d, at.lng - d]].map((c) => c.join(' ')).join(',');
    const name = `e2e-restricted-${at.lat}`;
    await db.execute(`INSERT INTO RestrictedAreas (Name, Polygon) VALUES (?, ST_GeomFromText(?, 4326))`, [name, `POLYGON((${ring}))`]);
    try {
      const res = await alice.api.post('/api/v1/markers', { multipart: markerMultipart({ at }) });
      expect(res.status()).toBe(422);
      expect((await alice.api.get(`/api/v1/markers/verify?${qs(at)}`)).status()).toBe(422);
    } finally {
      await db.execute('DELETE FROM RestrictedAreas WHERE Name = ?', [name]);
    }
  });

  test('a user can create at most 10 markers a day', async ({ users }) => {
    test.setTimeout(60_000);
    const alice = await users.create();
    for (let i = 0; i < 10; i++) await createMarker(alice);
    await new Promise((r) => setTimeout(r, 500)); // the daily counter is incremented asynchronously
    const res = await alice.api.post('/api/v1/markers', { multipart: markerMultipart() });
    expect(res.status()).toBe(429);
    expect((await res.json()).error).toContain('10');
  });
});

test.describe('marker details', () => {
  test('bundled page matches detail, public sections and viewer permissions', async ({ users, api, db }) => {
    const owner = await users.create();
    const marker = await createMarker(owner);
    const id = marker.markerId;
    await waitForAddress(db, id);
    const response = await owner.api.get(`/api/v1/markers/${id}/page`);
    expect(response.status(), await response.text()).toBe(200);
    expect(response.headers()['cache-control']).toBe('private, no-store');
    const bundle = await response.json();
    const [detail, facilities, comments, stories] = await Promise.all([
      owner.api.get(`/api/v1/markers/${id}/details`).then((r) => r.json()),
      api.get(`/api/v1/markers/${id}/facilities`).then((r) => r.json()),
      api.get(`/api/v1/comments/${id}/comments?page=1&pageSize=10`).then((r) => r.json()),
      api.get(`/api/v1/markers/${id}/stories`).then((r) => r.json()),
    ]);
    expect(bundle).toEqual({ marker: detail, facilities, comments, stories });
    expect(bundle.marker.isChulbong).toBe(true);
    const guest = await api.get(`/api/v1/markers/${id}/page`);
    expect((await guest.json()).marker.isChulbong).toBeFalsy();
    expect((await api.get('/api/v1/markers/999999999/page')).status()).toBe(404);
    expect((await api.get('/api/v1/markers/abc/page')).status()).toBe(400);
  });
  test('anyone can read a marker; only the owner sees isChulbong', async ({ users, api }) => {
    const alice = await users.create();
    const bob = await users.create();
    const m = await createMarker(alice, { description: '학교 운동장' });

    const anon = await api.get(`/api/v1/markers/${m.markerId}/details`);
    expect(anon.status()).toBe(200);
    const body = await anon.json();
    expect(body).toMatchObject({ markerId: m.markerId, ...near(m), description: '학교 운동장', userId: alice.userId, username: alice.username, disliked: false });
    expect(body.isChulbong ?? false).toBe(false);
    expect(body.reactions).toBeTruthy();

    expect((await (await alice.api.get(`/api/v1/markers/${m.markerId}/details`)).json()).isChulbong).toBe(true);
    expect((await (await bob.api.get(`/api/v1/markers/${m.markerId}/details`)).json()).isChulbong ?? false).toBe(false);
  });

  test('an unknown marker gets 404 and a non-numeric ID gets 400', async ({ api }) => {
    expect((await api.get('/api/v1/markers/999999999/details')).status()).toBe(404);
    expect((await api.get('/api/v1/markers/abc/details')).status()).toBe(400);
  });
});

test.describe('update description', () => {
  test('the owner updates the description and details show it', async ({ users, api }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    const res = await alice.api.put(`/api/v1/markers/${m.markerId}`, { multipart: { description: '새 설명' } });
    expect(res.status(), await res.text()).toBe(200);
    expect(await res.json()).toEqual({ description: '새 설명' });
    expect((await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json()).description).toBe('새 설명');
  });

  test('another user gets 403, an admin may update, anonymous gets 401', async ({ users, api }) => {
    const alice = await users.create();
    const bob = await users.create();
    const admin = await users.create({ admin: true });
    const m = await createMarker(alice, { description: 'original' });

    expect((await bob.api.put(`/api/v1/markers/${m.markerId}`, { multipart: { description: 'hijack' } })).status()).toBe(403);
    expect((await api.put(`/api/v1/markers/${m.markerId}`, { multipart: { description: 'anon' } })).status()).toBe(401);
    expect((await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json()).description).toBe('original');

    expect((await admin.api.put(`/api/v1/markers/${m.markerId}`, { multipart: { description: 'by admin' } })).status()).toBe(200);
    expect((await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json()).description).toBe('by admin');
  });

  test('a bad-word description gets 400 and an unknown marker gets 404', async ({ users }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    expect((await alice.api.put(`/api/v1/markers/${m.markerId}`, { multipart: { description: 'sibal' } })).status()).toBe(400);
    expect((await alice.api.put('/api/v1/markers/999999999', { multipart: { description: 'ok' } })).status()).toBe(404);
  });
});

test.describe('delete marker', () => {
  test('the owner deletes their marker and it is gone from details and the full list', async ({ users, api }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    await expect.poll(async () => (await (await api.get('/api/v1/markers')).json()).some((x: any) => x.markerId === m.markerId)).toBe(true);

    expect((await alice.api.delete(`/api/v1/markers/${m.markerId}`)).status()).toBe(200);
    expect((await api.get(`/api/v1/markers/${m.markerId}/details`)).status()).toBe(404);
    const all = await (await api.get('/api/v1/markers')).json();
    expect(all.some((x: any) => x.markerId === m.markerId)).toBe(false);
  });

  test('another user gets 403 and the marker stays', async ({ users, api }) => {
    const alice = await users.create();
    const bob = await users.create();
    const m = await createMarker(alice);
    const res = await bob.api.delete(`/api/v1/markers/${m.markerId}`);
    expect((await api.get(`/api/v1/markers/${m.markerId}/details`)).status()).toBe(200);
    expect(res.status()).toBe(403);
  });

  test('an admin can delete any marker', async ({ users, api }) => {
    const alice = await users.create();
    const admin = await users.create({ admin: true });
    const m = await createMarker(alice);
    expect((await admin.api.delete(`/api/v1/markers/${m.markerId}`)).status()).toBe(200);
    expect((await api.get(`/api/v1/markers/${m.markerId}/details`)).status()).toBe(404);
  });

  test('anonymous gets 401, an unknown marker gets 404', async ({ users, api }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    expect((await api.delete(`/api/v1/markers/${m.markerId}`)).status()).toBe(401);
    expect((await alice.api.delete('/api/v1/markers/999999999')).status()).toBe(404);
  });
});

test.describe('delete photo', () => {
  test('the owner deletes a photo; a repeat delete is an idempotent 200', async ({ users, api }) => {
    const alice = await users.create();
    const m = await createMarker(alice, { photos: 1 });
    const { photos } = await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json();
    const url = `/api/v1/markers/${m.markerId}/photos/${photos[0].photoId}`;

    const res = await alice.api.delete(url);
    expect(res.status()).toBe(200);
    expect(await res.json()).toMatchObject({ message: expect.any(String) });
    expect((await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json()).photos ?? []).toHaveLength(0);
    expect((await alice.api.delete(url)).status()).toBe(200);
  });

  test('another user gets 403 and the photo stays', async ({ users, api }) => {
    const alice = await users.create();
    const bob = await users.create();
    const m = await createMarker(alice, { photos: 1 });
    const { photos } = await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json();
    expect((await bob.api.delete(`/api/v1/markers/${m.markerId}/photos/${photos[0].photoId}`)).status()).toBe(403);
    expect((await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json()).photos).toHaveLength(1);
  });

  test('a photo of an unknown marker gets 404', async ({ users }) => {
    const alice = await users.create();
    expect((await alice.api.delete('/api/v1/markers/999999999/photos/1')).status()).toBe(404);
  });
});

test.describe('marker lists', () => {
  test('map pins use a separate ETag and keep the same IDs, coordinates and photos', async ({ api, users }) => {
    const marker = await createMarker(await users.create(), { photos: 1 });
    await expect.poll(async () => {
      const res = await api.get('/api/v1/markers/map-pins');
      expect(res.status()).toBe(200);
      const pins: [number, number, number, number][] = await res.json();
      return pins.find(([id]) => id === marker.markerId);
    }).toEqual([marker.markerId, Math.round(marker.latitude * 1e6), Math.round(marker.longitude * 1e6), 1]);

    const fullTag = (await api.get('/api/v1/markers')).headers().etag;
    const pins = await api.get('/api/v1/markers/map-pins', { headers: { 'If-None-Match': fullTag } });
    expect(pins.status()).toBe(200);
    expect(pins.headers().etag).toMatch(/^W\/"map-pins-v\d+"$/);
    await expect.poll(async () => {
      const tag = (await api.get('/api/v1/markers/map-pins')).headers().etag;
      return (await api.get('/api/v1/markers/map-pins', { headers: { 'If-None-Match': tag } })).status();
    }).toBe(304);
  });

  test('a new marker shows up in the full list even when the client revalidates with an old ETag', async ({ users, api }) => {
    const alice = await users.create();
    const before = await api.get('/api/v1/markers');
    expect(before.status()).toBe(200);
    const etag = before.headers()['etag'];
    expect(etag).toBeTruthy();

    const m = await createMarker(alice, { photos: 1 });
    await expect.poll(async () => {
      const res = await api.get('/api/v1/markers', { headers: { 'If-None-Match': etag } });
      if (res.status() !== 200) return res.status();
      return (await res.json()).find((x: any) => x.markerId === m.markerId) ?? 'missing';
    }, { timeout: 5_000 }).toMatchObject({ markerId: m.markerId, ...near(m), hasPhoto: true });
  });

  test('an unchanged full list answers 304 to its own ETag', async ({ api }) => {
    let again;
    for (let attempt = 0; attempt < 5; attempt++) {
      const etag = (await api.get('/api/v1/markers')).headers()['etag'];
      again = await api.get('/api/v1/markers', { headers: { 'If-None-Match': etag } });
      // Another worker creating a marker in between legitimately changes the ETag; retry then.
      if (again.status() === 304 || again.headers()['etag'] === etag) break;
    }
    expect(again!.status()).toBe(304);
  });

  test('the full list sent as brotli matches the uncompressed list', async ({ api }) => {
    // The first br request builds a precompressed copy in the background; later ones send it.
    await expect.poll(async () => {
      const br = await api.get('/api/v1/markers', { headers: { 'Accept-Encoding': 'br' } });
      const plain = await api.get('/api/v1/markers', { headers: { 'Accept-Encoding': 'identity' } });
      if (br.headers()['etag'] !== plain.headers()['etag']) return 'list changed in between';
      expect(br.headers()['content-encoding']).toBe('br');
      expect(plain.headers()['content-encoding']).toBeUndefined();
      return (await br.body()).equals(await plain.body()) ? 'same' : 'different';
    }, { intervals: [100, 200, 500] }).toBe('same');
  });

  test('new markers still list a marker whose author deleted their account', async ({ users, api, db }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    await waitForAddress(db, m.markerId);
    expect((await alice.api.delete('/api/v1/users/me')).status()).toBeLessThan(300);
    const res = await api.get('/api/v1/markers/new?page=1&pageSize=50');
    expect(res.status()).toBe(200);
    expect((await res.json()).find((x: any) => x.markerId === m.markerId)).toMatchObject(near(m));
  });

  test('new-markers returns markers after a given ID', async ({ users, api }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    const res = await api.get(`/api/v1/markers/new-markers?lastMarkerID=${m.markerId - 1}`);
    expect(res.status()).toBe(200);
    const list = await res.json();
    expect(list.find((x: any) => x.markerId === m.markerId)).toMatchObject(near(m));
    expect(list.every((x: any) => x.markerId > m.markerId - 1)).toBe(true);
  });

  test('markers by username page through that user\'s markers', async ({ users, api, db }) => {
    const alice = await users.create();
    const a = await createMarker(alice, { description: 'first' });
    const b = await createMarker(alice, { description: 'second' });
    await waitForAddress(db, a.markerId);
    await waitForAddress(db, b.markerId);
    const res = await api.get(`/api/v1/markers/user/${encodeURIComponent(alice.username)}?page=1&pageSize=1`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({ currentPage: 1, totalPages: 2, totalMarkers: 2 });
    expect(body.markers).toHaveLength(1);
    const page2 = await (await api.get(`/api/v1/markers/user/${encodeURIComponent(alice.username)}?page=2&pageSize=1`)).json();
    expect([body.markers[0].markerId, page2.markers[0].markerId].sort()).toEqual([a.markerId, b.markerId].sort());
  });

  test('new-pictures includes a freshly uploaded photo', async ({ users, api }) => {
    const alice = await users.create();
    const m = await createMarker(alice, { photos: 1 });
    const res = await api.get('/api/v1/markers/new-pictures');
    expect(res.status()).toBe(200);
    const list = await res.json();
    expect(list.length).toBeLessThanOrEqual(10);
    expect(list.find((x: any) => x.markerId === m.markerId)).toMatchObject({ photoURL: expect.stringMatching(/^http/) });
  });

  test('close markers find a marker within the radius, with its distance', async ({ users, api, db }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    await waitForAddress(db, m.markerId);
    const from = offsetNorth({ lat: m.latitude, lng: m.longitude }, 30);
    const res = await api.get(`/api/v1/markers/close?${qs(from)}&distance=100&page=1&pageSize=10`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({ currentPage: 1, totalMarkers: expect.any(Number), totalPages: expect.any(Number), markers: expect.any(Array) });
    const hit = body.markers.find((x: any) => x.markerId === m.markerId);
    expect(hit).toMatchObject(near(m));
    expect(hit.distance).toBeGreaterThan(10);
    expect(hit.distance).toBeLessThan(60);
  });

  test('close marker pages report the full count and preserve the requested page', async ({ users, api }) => {
    const owner = await users.create();
    const center = randomLandPoint();
    const fixtures = [];
    for (const meters of [0, 50, 100]) {
      fixtures.push(await createMarker(owner, { at: offsetNorth(center, meters) }));
    }
    const url = `/api/v1/markers/close?${qs(center)}&distance=120&pageSize=2`;
    const expectedIDs = fixtures.map((marker) => marker.markerId);
    for (const [page, ids] of [[1, expectedIDs.slice(0, 2)], [2, expectedIDs.slice(2)], [3, []]] as const) {
      const res = await api.get(`${url}&page=${page}`);
      expect(res.status(), await res.text()).toBe(200);
      const body = await res.json();
      expect(body).toMatchObject({ currentPage: page, totalMarkers: 3, totalPages: 2 });
      expect(body.markers.map((marker: CreatedMarker) => marker.markerId)).toEqual(ids);
    }
  });

  test('close markers list a marker once when its newest photos share an upload time', async ({ users, api, db }) => {
    const m = await createMarker(await users.create(), { photos: 1 });
    await db.query('INSERT INTO Photos (MarkerID, PhotoURL, ThumbnailURL, UploadedAt) SELECT MarkerID, PhotoURL, ThumbnailURL, UploadedAt FROM Photos WHERE MarkerID = ?', [m.markerId]);
    const body = await (await api.get(`/api/v1/markers/close?latitude=${m.latitude}&longitude=${m.longitude}&distance=100&page=1&pageSize=10`)).json();
    const hits = body.markers.filter((x: any) => x.markerId === m.markerId);
    expect(hits).toHaveLength(1);
    expect(hits[0].thumbnail).toBeTruthy();
  });

  // The address is filled in asynchronously after creation and stays NULL when the lookup fails.
  for (const [name, url] of [
    ['markers by username', (m: CreatedMarker, u: User) => `/api/v1/markers/user/${encodeURIComponent(u.username)}`],
    ['close markers', (m: CreatedMarker) => `/api/v1/markers/close?latitude=${m.latitude}&longitude=${m.longitude}&distance=100&page=1`],
    ['new markers', () => '/api/v1/markers/new?page=1&pageSize=50'],
    ['save-offline', (m: CreatedMarker) => `/api/v1/markers/save-offline?latitude=${m.latitude}&longitude=${m.longitude}`],
  ] as const) {
    test(`${name} still answer while a marker has no address yet`, async ({ users, api, db }) => {
      const alice = await users.create();
      const m = await createMarker(alice);
      await waitForAddress(db, m.markerId); // so the async lookup can't overwrite the NULL below
      await db.execute('UPDATE Markers SET Address = NULL WHERE MarkerID = ?', [m.markerId]);
      try {
        const res = await api.get(url(m, alice));
        expect(res.status()).toBe(200);
        if (name !== 'save-offline') expect(JSON.stringify(await res.json())).toContain(`"markerId":${m.markerId}`);
      } finally {
        await alice.api.delete(`/api/v1/markers/${m.markerId}`); // a NULL address left behind would break the RSS feed for everyone
      }
    });
  }

  test('close markers reject invalid coordinates with 400', async ({ api }) => {
    for (const [latitude, longitude] of [
      ['-1.6998952150150572e+24', '3.1123736822310117e+22'],
      ['-90.1', '127'], ['90.1', '127'], ['37', '-180'], ['37', '180.1'],
      ['NaN', '127'], ['37', 'NaN'], ['+Inf', '127'], ['37', '-Inf'],
      ['', '127'], ['37', ''],
    ]) {
      const query = new URLSearchParams({ latitude, longitude, distance: '50', page: '1', pageSize: '1' });
      const res = await api.get(`/api/v1/markers/close?${query}`);
      expect(res.status(), `${latitude},${longitude}: ${await res.text()}`).toBe(400);
      expect((await res.json()).error).toBeTruthy();
    }
  });

  test('close markers refuse a radius over 50 km and bad query values', async ({ api }) => {
    const p = randomLandPoint();
    expect((await api.get(`/api/v1/markers/close?${qs(p)}&distance=50001&page=1`)).status()).toBe(403);
    const bad = await api.get('/api/v1/markers/close?latitude=abc&longitude=127&distance=100&page=1');
    expect(bad.status()).toBe(400);
  });
});

test.describe('ranking', () => {
  test('ranking and area ranking return arrays', async ({ api }) => {
    const r = await api.get('/api/v1/markers/ranking');
    expect(r.status()).toBe(200);
    expect(Array.isArray(await r.json())).toBe(true);
    const a = await api.get(`/api/v1/markers/area-ranking?${qs(randomLandPoint())}&limit=10`);
    expect(a.status()).toBe(200);
    expect(Array.isArray(await a.json())).toBe(true);
  });

  test('area ranking rejects out-of-range coordinates and a bad limit', async ({ api }) => {
    expect((await api.get('/api/v1/markers/area-ranking?latitude=50&longitude=127')).status()).toBe(400);
    expect((await api.get(`/api/v1/markers/area-ranking?${qs(randomLandPoint())}&limit=x`)).status()).toBe(400);
  });

  test('unique-ranking returns the visitor count and needs a markerId', async ({ api }) => {
    const res = await api.get('/api/v1/markers/unique-ranking?markerId=1');
    expect(res.status()).toBe(200);
    expect(await res.json()).toMatchObject({ markerId: '1', visitors: expect.any(Number) });
    expect((await api.get('/api/v1/markers/unique-ranking')).status()).toBe(400);
  });

  // A marker-page view is any API call a browser makes with Referer /pullup/{id}.
  const CHROME = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36';
  const view = (api: any, markerId: number, ip = randomIP(), ua = CHROME, referer = `https://www.k-pullup.test/pullup/${markerId}`) =>
    api.get(`/api/v1/markers/${markerId}/facilities`, { headers: { 'Fly-Client-IP': ip, 'User-Agent': ua, Referer: referer } });
  const visitors = async (api: any, markerId: number) =>
    (await (await api.get(`/api/v1/markers/unique-ranking?markerId=${markerId}`)).json()).visitors;

  test('a visitor counts once a day; bots, server-side calls and calls without the page referer do not count', async ({ users, api }) => {
    const m = await createMarker(await users.create());
    const ip = randomIP();
    await view(api, m.markerId, ip);
    await view(api, m.markerId, ip);
    await view(api, m.markerId, ip, CHROME, `https://www.k-pullup.test/pullup/${m.markerId}/moment`);
    await view(api, m.markerId);
    await view(api, m.markerId, randomIP(), 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)');
    await view(api, m.markerId, randomIP(), 'node'); // Next.js server rendering
    await view(api, m.markerId, randomIP(), CHROME, 'https://www.k-pullup.test/');
    await expect.poll(() => visitors(api, m.markerId)).toBe(2);
    await new Promise((r) => setTimeout(r, 500)); // let a wrongly counted view land before the final check
    expect(await visitors(api, m.markerId)).toBe(2);
  });

  test('ranking counts recent engagement, excluding views, owner actions and older activity', async ({ users, api, db }) => {
    const p = randomLandPoint();
    const alice = await users.create();
    const m = await createMarker(alice, { at: p });
    const [bob, carol, dave] = await Promise.all([users.create(), users.create(), users.create()]);
    expect((await alice.api.post(`/api/v1/markers/${m.markerId}/favorites`)).status()).toBeLessThan(300); // owner: ignored
    expect((await alice.api.post(`/api/v1/markers/${m.markerId}/reactions`, { data: { reactionType: 'clean' } })).status()).toBe(200); // owner: ignored
    expect((await bob.api.post(`/api/v1/markers/${m.markerId}/favorites`)).status()).toBeLessThan(300); // +5
    expect((await bob.api.post(`/api/v1/markers/${m.markerId}/reactions`, { data: { reactionType: 'clean' } })).status()).toBe(200); // same user, lower weight
    expect((await carol.api.post(`/api/v1/markers/${m.markerId}/reactions`, { data: { reactionType: 'clean' } })).status()).toBe(200); // +3
    expect((await dave.api.post(`/api/v1/markers/${m.markerId}/reactions`, { data: { reactionType: 'broken' } })).status()).toBe(200); // -5
    await view(api, m.markerId);
    await view(api, m.markerId);
    await db.execute('INSERT INTO Favorites (UserID, MarkerID, CreatedAt) VALUES (?, ?, NOW() - INTERVAL 8 DAY)', [dave.userId, m.markerId]);
    const expected = 5 + 3 - 5;
    // area-ranking reports the score in its "distance" field.
    const score = async () => (await (await api.get(`/api/v1/markers/area-ranking?${qs(p)}&limit=50`)).json()).find((x: any) => x.markerId === m.markerId)?.distance;
    await expect.poll(score, { timeout: 10_000 }).toBeCloseTo(expected, 2);
  });

  test('area ranking includes a ranked marker farther away than the nearest `limit` markers', async ({ users, api }) => {
    const p = randomLandPoint();
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    for (let i = 1; i <= 3; i++) await createMarker(alice, { at: offsetNorth(p, 20 * i) });
    const far = await createMarker(alice, { at: offsetNorth(p, 3000) });
    expect((await bob.api.post(`/api/v1/markers/${far.markerId}/favorites`)).status()).toBeLessThan(300);
    const ids = async () => (await (await api.get(`/api/v1/markers/area-ranking?${qs(p)}&limit=2`)).json()).map((x: any) => x.markerId);
    await expect.poll(ids, { timeout: 10_000 }).toContain(far.markerId);
  });

  test('the ranking orders markers by score and drops a deleted marker', async ({ users, api }) => {
    const alice = await users.create();
    const [hot, warm] = [await createMarker(alice), await createMarker(alice)];
    const onlyViewed = await createMarker(alice);
    const [bob, carol] = await Promise.all([users.create(), users.create()]);
    for (const [user, id] of [[bob, hot.markerId], [carol, hot.markerId], [bob, warm.markerId]] as const) {
      expect((await user.api.post(`/api/v1/markers/${id}/favorites`)).status()).toBeLessThan(300);
    }
    await Promise.all(Array.from({ length: 20 }, () => view(api, onlyViewed.markerId)));
    await expect.poll(() => visitors(api, onlyViewed.markerId)).toBe(20);
    const order = async () => (await (await api.get('/api/v1/markers/ranking')).json()).map((x: any) => x.markerId).filter((id: number) => id === hot.markerId || id === warm.markerId);
    await expect.poll(order, { timeout: 10_000 }).toEqual([hot.markerId, warm.markerId]);
    expect((await (await api.get('/api/v1/markers/ranking')).json()).map((x: any) => x.markerId)).not.toContain(onlyViewed.markerId);

    expect((await alice.api.delete(`/api/v1/markers/${warm.markerId}`)).status()).toBe(200);
    expect(await order()).toEqual([hot.markerId]);
  });
});

test.describe('location utilities', () => {
  test('location-check says whether a point is in South Korea @readonly', async ({ api }) => {
    expect(await (await api.get('/api/v1/markers/location-check?latitude=37.5665&longitude=126.978')).json()).toEqual({ result: true });
    expect(await (await api.get(`/api/v1/markers/location-check?${qs(TSUSHIMA)}`)).json()).toEqual({ result: false });
    expect(await (await api.get(`/api/v1/markers/location-check?${qs(PYONGYANG)}`)).json()).toEqual({ result: false });
    expect((await api.get('/api/v1/markers/location-check?latitude=35.68&longitude=139.69')).status()).toBe(400);
  });

  test('convert turns WGS84 into WCONGNAMUL coordinates @readonly', async ({ api }) => {
    const res = await api.get('/api/v1/markers/convert?latitude=37.5665&longitude=126.978');
    expect(res.status()).toBe(200);
    const { X, Y } = await res.json();
    // Seoul City Hall is roughly (496000, 1129000) in Kakao's WCONGNAMUL.
    expect(X).toBeGreaterThan(480_000); expect(X).toBeLessThan(510_000);
    expect(Y).toBeGreaterThan(1_110_000); expect(Y).toBeLessThan(1_150_000);
    expect((await api.get('/api/v1/markers/convert?latitude=x&longitude=127')).status()).toBe(400);
  });

  test('weather is returned for land and shared across a ~2 km grid cell', async ({ api, baseURL }) => {
    const p = randomLandPoint();
    const cell = { lat: Math.round(p.lat * 50) / 50, lng: Math.round(p.lng * 50) / 50 };
    const first = await api.get(`/api/v1/markers/weather?${qs({ lat: cell.lat + 0.001, lng: cell.lng + 0.001 })}`);
    expect(first.status(), await first.text()).toBe(200);
    const body = await first.json();
    expect(body).toMatchObject({ temperature: expect.any(String), desc: expect.any(String), humidity: expect.any(String), rainfall: expect.any(String), iconImage: expect.any(String) });

    const other = await newContext(baseURL, randomIP());
    try {
      await expect.poll(async () => (await other.get(`/api/v1/markers/weather?${qs({ lat: cell.lat - 0.002, lng: cell.lng - 0.002 })}`)).headers()['x-cache']).toBe('hit');
      expect(await (await other.get(`/api/v1/markers/weather?${qs({ lat: cell.lat - 0.002, lng: cell.lng - 0.002 })}`)).json()).toEqual(body);
    } finally {
      await other.dispose();
    }
    expect((await api.get('/api/v1/markers/weather?latitude=10&longitude=127')).status()).toBe(400);
  });

  test('concurrent weather misses share one upstream call and publish the cache immediately', async ({ api }) => {
    const at = randomLandPoint();
    const url = `/api/v1/markers/weather?${qs(at)}`;
    const coords = await (await api.get(`/api/v1/markers/convert?${qs(at)}`)).json();
    const responses = await Promise.all(Array.from({ length: 20 }, () => api.get(url)));
    const bodies = await Promise.all(responses.map(async (res) => {
      expect(res.status(), await res.text()).toBe(200);
      return res.json();
    }));
    bodies.forEach((body) => expect(body).toEqual(bodies[0]));
    const next = await api.get(url);
    expect(next.headers()['x-cache']).toBe('hit');
    const requests = await (await api.get('http://127.0.0.1:18090/__requests')).json();
    const calls = requests.filter((r: any) => r.path === '/api/dapi/point/weather'
      && Math.abs(Number(r.query.x) - coords.X) < 0.00001 && Math.abs(Number(r.query.y) - coords.Y) < 0.00001);
    expect(calls).toHaveLength(1);
  });

  test('roadview-date returns the latest shot date', async ({ api }) => {
    const res = await api.get(`/api/v1/markers/roadview-date?${qs(randomLandPoint())}`);
    expect(res.status(), await res.text()).toBe(200);
    expect((await res.json()).shot_date).toMatch(/^2024-05-01T10:30:00/);
    expect((await api.get('/api/v1/markers/roadview-date?latitude=x&longitude=127')).status()).toBe(400);
  });

  test('roadview-date answers 404, not 500, where Kakao has no road view, and remembers it', async ({ api }) => {
    const sea = { lat: Number((SEA.lat + Math.random() / 100).toFixed(6)), lng: SEA.lng }; // fresh spot, mock: no road view at sea
    const first = await api.get(`/api/v1/markers/roadview-date?${qs(sea)}`);
    expect(first.status(), await first.text()).toBe(404);
    await expect.poll(async () => {
      const again = await api.get(`/api/v1/markers/roadview-date?${qs(sea)}`);
      return `${again.status()} ${again.headers()['x-cache']}`;
    }).toBe('404 hit');
  });

  test('roadview-date asks Kakao once per spot and serves repeats from cache', async ({ api, request }) => {
    const p = randomLandPoint();
    const { X, Y } = await (await api.get(`/api/v1/markers/convert?${qs(p)}`)).json(); // what the API sends Kakao as PX/PY
    const kakaoCalls = async () => {
      const calls = await (await request.get('http://127.0.0.1:18090/__requests')).json();
      return calls.filter((c: any) => c.path === '/roadview' && c.query.PX === X.toFixed(6) && c.query.PY === Y.toFixed(6)).length;
    };
    const first = await api.get(`/api/v1/markers/roadview-date?${qs(p)}`);
    expect(first.status()).toBe(200);
    // The cache write is asynchronous: poll until a repeat is served from it.
    await expect.poll(async () => (await api.get(`/api/v1/markers/roadview-date?${qs(p)}`)).headers()['x-cache']).toBe('hit');
    expect(await kakaoCalls()).toBeGreaterThanOrEqual(1);
    const before = await kakaoCalls();
    const again = await api.get(`/api/v1/markers/roadview-date?${qs(p)}`);
    expect(await again.json()).toEqual(await first.json());
    expect(await kakaoCalls()).toBe(before);
  });

  test('verify accepts a free spot and rejects a taken or foreign one', async ({ users, api }) => {
    const alice = await users.create();
    const free = randomLandPoint();
    const ok = await api.get(`/api/v1/markers/verify?${qs(free)}`);
    expect(ok.status()).toBe(200);
    expect(await ok.text()).toBe('OK');

    const m = await createMarker(alice);
    expect((await api.get(`/api/v1/markers/verify?${qs(offsetNorth({ lat: m.latitude, lng: m.longitude }, 2))}`)).status()).toBe(409);
    expect((await api.get(`/api/v1/markers/verify?${qs(TSUSHIMA)}`)).status()).toBe(403);
    expect((await api.get('/api/v1/markers/verify?latitude=x&longitude=127')).status()).toBe(400);
  });
});

test.describe('facilities', () => {
  test('the owner sets facilities and everyone reads the new list', async ({ users, api }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    const empty = await api.get(`/api/v1/markers/${m.markerId}/facilities`);
    expect(empty.status()).toBe(200);
    expect(await empty.json()).toEqual([]); // also warms the cache, which the write must invalidate

    const set = await alice.api.post('/api/v1/markers/facilities', { data: { markerId: m.markerId, facilities: [{ facilityId: 1, quantity: 2 }, { facilityId: 2, quantity: 1 }] } });
    expect(set.status(), await set.text()).toBe(200);

    const got = await (await api.get(`/api/v1/markers/${m.markerId}/facilities`)).json();
    expect(got).toEqual(expect.arrayContaining([{ facilityId: 1, markerId: m.markerId, quantity: 2 }, { facilityId: 2, markerId: m.markerId, quantity: 1 }]));
    expect(got).toHaveLength(2);
  });

  test('another user gets 403, anonymous 401, an admin may set them', async ({ users, api }) => {
    const alice = await users.create();
    const bob = await users.create();
    const admin = await users.create({ admin: true });
    const m = await createMarker(alice);
    const data = { markerId: m.markerId, facilities: [{ facilityId: 1, quantity: 3 }] };

    expect((await bob.api.post('/api/v1/markers/facilities', { data })).status()).toBe(403);
    expect((await api.post('/api/v1/markers/facilities', { data })).status()).toBe(401);
    expect(await (await api.get(`/api/v1/markers/${m.markerId}/facilities`)).json()).toEqual([]);

    expect((await admin.api.post('/api/v1/markers/facilities', { data })).status()).toBe(200);
    expect(await (await api.get(`/api/v1/markers/${m.markerId}/facilities`)).json()).toEqual([{ facilityId: 1, markerId: m.markerId, quantity: 3 }]);
  });

  test('invalid facility payloads get 400 and an unknown marker gets 404', async ({ users }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    const post = (data: unknown) => alice.api.post('/api/v1/markers/facilities', { data });
    expect((await post({ markerId: m.markerId, facilities: [{ facilityId: 1, quantity: -1 }] })).status()).toBe(400);
    expect((await post({ markerId: m.markerId, facilities: [{ facilityId: 0, quantity: 1 }] })).status()).toBe(400);
    expect((await post({ markerId: 0, facilities: [] })).status()).toBe(400);
    expect((await post({ markerId: 999999999, facilities: [{ facilityId: 1, quantity: 1 }] })).status()).toBe(404);
    expect((await alice.api.get('/api/v1/markers/abc/facilities')).status()).toBe(400);
  });
});

test.describe('offline map and feeds', () => {
  test('save-offline returns a PDF for a spot with markers and 204 for an empty one', async ({ users, api, db }) => {
    const alice = await users.create();
    const m = await createMarker(alice);
    await waitForAddress(db, m.markerId);
    const res = await api.get(`/api/v1/markers/save-offline?${qs(offsetNorth({ lat: m.latitude, lng: m.longitude }, 20))}`);
    expect(res.status(), res.status() >= 400 ? await res.text() : '').toBe(200);
    expect((await res.body()).subarray(0, 5).toString()).toBe('%PDF-');

    // An empty spot far from any marker (random inland points are ~km apart).
    const empty = await api.get(`/api/v1/markers/save-offline?latitude=34.95&longitude=127.05`);
    expect(empty.status()).toBe(204);
  });

  test('save-offline allows 5 requests per minute per IP', async ({ api }) => {
    const statuses: number[] = [];
    for (let i = 0; i < 6; i++) {
      const res = await api.get('/api/v1/markers/save-offline?latitude=x&longitude=127');
      statuses.push(res.status());
      // Parallel PDF tests may hold the single generator slot before input validation runs.
      if (i < 5 && res.status() === 503) expect(res.headers()['retry-after']).toBe('3');
    }
    for (const status of statuses.slice(0, 5)) expect([400, 503]).toContain(status);
    expect(statuses[5]).toBe(429);
  });

  test('rss serves an XML feed @readonly', async ({ api }) => {
    const res = await api.get('/api/v1/markers/rss');
    expect(res.status()).toBe(200);
    expect(res.headers()['content-type']).toContain('xml');
    expect(await res.text()).toContain('<rss');
  });
});

import { test, expect, type User } from '../fixtures';
import { createMarker, pngOfSize } from '../helpers/markers';
import type { APIRequestContext } from '@playwright/test';

// /api/v1/next/image: the mobile site's <img src> for marker photos (?url=<photo>&os=iOS|Android|Windows).
const WEBP = 'image/avif,image/webp,*/*';

test('new photos keep their URL and dimensions while stored pixels receive the watermark', async ({ users, api }) => {
  const alice = await users.create();
  const original = pngOfSize(600, 400);
  const marker = await createMarker(alice, { photos: 1, photo: original });
  const details = await (await alice.api.get(`/api/v1/markers/${marker.markerId}/details`)).json();
  const photo = details.photos[0];
  expect(photo.photoUrl).toMatch(/\/markers\/.*\.png$/);
  const res = await api.get(photo.photoUrl);
  expect(res.status()).toBe(200);
  expect(res.headers()['content-type']).toContain('image/png');
  expect(res.headers()['x-amz-meta-photo-watermark']).toBe('logo-balanced-3-angle-v2');
  const body = await res.body();
  expect(body.equals(original)).toBe(false);
  expect(body.readUInt32BE(16)).toBe(600);
  expect(body.readUInt32BE(20)).toBe(400);
  const thumb = await api.get(photo.thumbnailUrl);
  expect(thumb.status()).toBe(200);
  expect(thumb.headers()['x-amz-meta-photo-watermark']).toBe('logo-balanced-3-angle-v2');
});

async function photoUrl(user: User, w: number, h: number): Promise<string> {
  const m = await createMarker(user, { photos: 1, photo: pngOfSize(w, h) });
  const details = await (await user.api.get(`/api/v1/markers/${m.markerId}/details`)).json();
  return details.photos[0].photoUrl;
}

const nextImage = (api: APIRequestContext, url: string, query = '', accept = WEBP) =>
  api.get(`/api/v1/next/image?url=${encodeURIComponent(url)}${query}`, { headers: { Accept: accept }, maxRedirects: 0 });

/** Location of the stored copy; it's uploaded after the first answer, so earlier requests build again. */
async function storedCopy(api: APIRequestContext, url: string, query: string): Promise<string> {
  let location = '';
  await expect.poll(async () => (location = (await nextImage(api, url, query)).headers()['location'] ?? '')).not.toBe('');
  return location;
}

/** Pixel width from a WebP header (lossy, lossless or extended). */
function webpWidth(b: Buffer): number {
  expect(b.subarray(0, 4).toString()).toBe('RIFF');
  const chunk = b.subarray(12, 16).toString();
  if (chunk === 'VP8 ') return b.readUInt16LE(26) & 0x3fff;
  if (chunk === 'VP8L') return (b.readUInt32LE(21) & 0x3fff) + 1;
  return b.readUIntLE(24, 3) + 1; // VP8X
}

test('a large photo is resized for phones once, then served by redirect to the stored copy', async ({ users, api }) => {
  const url = await photoUrl(await users.create(), 2000, 1000);

  const first = await nextImage(api, url, '&os=Android');
  expect(first.status(), await first.text()).toBe(200);
  expect(first.headers()['content-type']).toBe('image/webp');
  expect(first.headers()['vary']).toContain('Accept');
  expect(webpWidth(await first.body())).toBe(1280);

  const location = await storedCopy(api, url, '&os=Android');
  expect(location).toMatch(/\/next\/.*_w1280_q75\.webp$/);
  const stored = await api.get(location);
  expect(stored.status()).toBe(200);
  expect(stored.headers()['x-amz-meta-photo-watermark']).toBe('logo-balanced-3-angle-v2');
  expect(webpWidth(await stored.body())).toBe(1280);

  // The stored copy already fits, so asking for it redirects straight back to it.
  const self = await nextImage(api, location, '&os=Android');
  expect(self.status()).toBe(302);
  expect(self.headers()['location']).toBe(location);
});

test('desktop gets 1920 wide, an explicit width wins, and browsers without WebP get JPEG', async ({ users, api }) => {
  const url = await photoUrl(await users.create(), 2500, 400);
  expect(webpWidth(await (await nextImage(api, url, '&os=Windows')).body())).toBe(1920);
  expect(webpWidth(await (await nextImage(api, url, '&w=640&q=60')).body())).toBe(640);
  const jpeg = await nextImage(api, url, '&os=iOS', 'image/jpeg,*/*');
  expect(jpeg.status()).toBe(200);
  expect(jpeg.headers()['content-type']).toBe('image/jpeg');
});

test('deleting the marker also deletes the resized copies of its photo', async ({ users, api }) => {
  const alice = await users.create();
  const m = await createMarker(alice, { photos: 1, photo: pngOfSize(2000, 1000) });
  const url = (await (await alice.api.get(`/api/v1/markers/${m.markerId}/details`)).json()).photos[0].photoUrl;
  expect((await nextImage(api, url, '&os=iOS')).status()).toBe(200);
  const copy = await storedCopy(api, url, '&os=iOS');
  expect((await api.get(copy)).status()).toBe(200);

  expect((await alice.api.delete(`/api/v1/markers/${m.markerId}`)).status()).toBe(200);
  await expect.poll(async () => (await api.get(copy)).status()).toBe(404);
});

test('only photos from our bucket are served', async ({ api }) => {
  for (const url of ['https://example.com/a.webp', 'http://169.254.169.254/latest/meta-data/', '']) {
    const res = await nextImage(api, url);
    expect(res.status(), url).toBe(400);
  }
});

test('storage failures return readable generic JSON with gzip or Brotli requested', async ({ api }) => {
  const missing = `http://127.0.0.1:29090/chulbong-e2e/missing-${Date.now()}.jpg`;
  for (const encoding of ['gzip', 'br']) {
    const res = await api.get(`/api/v1/next/image?url=${encodeURIComponent(missing)}`, {
      headers: { 'Accept-Encoding': encoding }, maxRedirects: 0,
    });
    expect(res.status()).toBe(502);
    expect(res.headers()['content-type']).toContain('application/json');
    expect(await res.json()).toEqual({ error: 'Internal server error' });
  }
});

test('account deletion removes its original photos, thumbnails, and resized variants', async ({ users, api }) => {
  const alice = await users.create();
  const m = await createMarker(alice, { photos: 1, photo: pngOfSize(2000, 1000) });
  const photo = (await (await api.get(`/api/v1/markers/${m.markerId}/details`)).json()).photos[0];
  expect((await nextImage(api, photo.photoUrl, '&os=iOS')).status()).toBe(200);
  const variant = await storedCopy(api, photo.photoUrl, '&os=iOS');
  expect((await api.get(variant)).status()).toBe(200);
  expect((await alice.api.delete('/api/v1/users/me')).status()).toBe(204);
  for (const url of [photo.photoUrl, photo.thumbnailUrl, variant].filter(Boolean)) {
    expect((await api.get(url)).status(), url).toBe(404);
  }
});

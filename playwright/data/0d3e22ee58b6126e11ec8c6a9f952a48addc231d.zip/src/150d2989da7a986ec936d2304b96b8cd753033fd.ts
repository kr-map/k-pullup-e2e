import type { APIRequestContext } from '@playwright/test';
import { test, expect, newContext, randomIP, uniqueEmail, PASSWORD } from '../fixtures';
import {
  confirmCode, errorOf, login, mailCount, mailedCode, mailedResetLink, requestReset, resetPassword, sendCode, signup, sleep,
} from '../helpers/auth';

const NEW_PASSWORD = 'N3w-passw0rd!';

test.describe('verify-email', () => {
  test('code guesses share an address-wide budget across IPs and email casing', async ({ api, baseURL, db }) => {
    const email = uniqueEmail('guess-limit');
    expect((await sendCode(api, email)).status()).toBe(200);
    const code = await mailedCode(email);
    const wrong = code === '000000' ? '000001' : '000000';
    for (let i = 0; i < 10; i++) {
      const client = await newContext(baseURL, randomIP());
      try {
        expect((await confirmCode(client, i % 2 ? email.toUpperCase() : email, wrong)).status()).toBe(400);
      } finally { await client.dispose(); }
    }
    const res = await confirmCode(api, email, code);
    expect(res.status()).toBe(429);
    expect(res.headers()['retry-after']).toBe('300');
    const [rows] = await db.query('SELECT Verified FROM PasswordTokens WHERE Email = ?', [email]);
    expect((rows as { Verified: number }[])[0].Verified).toBe(0);
  });

  test('sending a code mails a six-digit code that confirms the address', async ({ api }) => {
    const email = uniqueEmail('verify');
    expect((await sendCode(api, email)).status()).toBe(200);
    const code = await mailedCode(email);
    expect((await confirmCode(api, email, code)).status()).toBe(200);
  });

  test('an already registered email cannot get a code', async ({ api, users }) => {
    const alice = await users.create();
    const res = await sendCode(api, alice.email);
    expect(res.status()).toBe(409);
    expect(await errorOf(res)).toBeTruthy();
  });

  test('a wrong code is rejected', async ({ api }) => {
    const email = uniqueEmail('verify');
    expect((await sendCode(api, email)).status()).toBe(200);
    const code = await mailedCode(email);
    const wrong = code === '000000' ? '000001' : '000000';
    const res = await confirmCode(api, email, wrong);
    expect(res.status()).toBe(400);
    expect(await errorOf(res)).toBeTruthy();
  });

  test('a code is only valid for the address it was sent to', async ({ api }) => {
    const email = uniqueEmail('verify');
    expect((await sendCode(api, email)).status()).toBe(200);
    const code = await mailedCode(email);
    expect((await confirmCode(api, uniqueEmail('other'), code)).status()).toBe(400);
  });

  test('an expired code is rejected', async ({ api, db }) => {
    const email = uniqueEmail('verify');
    expect((await sendCode(api, email)).status()).toBe(200);
    const code = await mailedCode(email);
    await db.execute('UPDATE PasswordTokens SET ExpiresAt = NOW() - INTERVAL 1 MINUTE WHERE Email = ?', [email]);
    expect((await confirmCode(api, email, code)).status()).toBe(400);
  });

  test('an address gets at most 5 codes per hour', async ({ api, baseURL }) => {
    const email = uniqueEmail('verify');
    for (let i = 0; i < 5; i++) expect((await sendCode(api, email)).status()).toBe(200);
    // A different IP doesn't reset the per-address limit.
    const other = await newContext(baseURL, randomIP());
    const res = await sendCode(other, email);
    expect(res.status()).toBe(429);
    expect(await errorOf(res)).toBeTruthy();
    await other.dispose();
  });
});

test.describe('signup', () => {
  async function verified(api: Parameters<typeof sendCode>[0]) {
    const email = uniqueEmail('signup');
    expect((await sendCode(api, email)).status()).toBe(200);
    expect((await confirmCode(api, email, await mailedCode(email))).status()).toBe(200);
    return email;
  }

  test('a verified email can sign up and then log in', async ({ api }) => {
    const email = await verified(api);
    const res = await signup(api, email, PASSWORD);
    expect(res.status()).toBe(201);
    expect(await res.json()).toMatchObject({ email, userId: expect.any(Number), username: expect.any(String) });
    expect(JSON.stringify(await res.json())).not.toContain(PASSWORD);
    expect((await login(api, email, PASSWORD)).status()).toBe(200);
  });

  test('an unverified email cannot sign up', async ({ api }) => {
    const res = await signup(api, uniqueEmail('unverified'), PASSWORD);
    expect(res.status()).toBe(400);
    expect(await errorOf(res)).toBeTruthy();
  });

  test('an email with only a sent but unconfirmed code cannot sign up', async ({ api }) => {
    const email = uniqueEmail('unconfirmed');
    expect((await sendCode(api, email)).status()).toBe(200);
    await mailedCode(email);
    expect((await signup(api, email, PASSWORD)).status()).toBe(400);
  });

  for (const [why, password] of [
    ['shorter than 8 characters', 'abc1234'],
    ['without a letter', '12345678'],
    ['without a digit', 'abcdefgh'],
    ['longer than 72 characters', `a1${'x'.repeat(71)}`],
  ]) {
    test(`a password ${why} is rejected and the verification stays usable`, async ({ api }) => {
      const email = await verified(api);
      const res = await signup(api, email, password);
      expect(res.status()).toBe(400);
      expect(await errorOf(res)).toBeTruthy();
      expect((await signup(api, email, PASSWORD)).status()).toBe(201);
    });
  }

  test('a malformed body gets 400', async ({ api }) => {
    const res = await api.post('/api/v1/auth/signup', { data: '{"email":', headers: { 'Content-Type': 'application/json' } });
    expect(res.status()).toBe(400);
  });

  test('signing up again with a registered email is rejected', async ({ api, users }) => {
    const alice = await users.create();
    const res = await signup(api, alice.email, PASSWORD);
    expect(res.status()).toBeGreaterThanOrEqual(400);
    expect(res.status()).toBeLessThan(500);
  });

  test('a registered email gets 409 even when it holds a verified token', async ({ api, users, db }) => {
    const alice = await users.create();
    await db.execute(
      'INSERT INTO PasswordTokens (Token, Email, Verified, ExpiresAt, CreatedAt) VALUES (?, ?, TRUE, NOW() + INTERVAL 5 MINUTE, NOW()) ' +
        'ON DUPLICATE KEY UPDATE Verified = TRUE, ExpiresAt = VALUES(ExpiresAt)',
      ['123456', alice.email],
    );
    expect((await confirmCode(api, alice.email, '123456')).status()).toBe(200);
    const res = await signup(api, alice.email, NEW_PASSWORD);
    expect(res.status()).toBe(409);
    expect((await login(api, alice.email, PASSWORD)).status()).toBe(200);
  });
});

test.describe('login', () => {
  test('correct credentials return the user and token and set the session cookie', async ({ api, users }) => {
    const alice = await users.create();
    const res = await login(api, alice.email, PASSWORD);
    expect(res.status()).toBe(200);
    expect(await res.json()).toMatchObject({ user: { userId: alice.userId, email: alice.email }, token: expect.any(String) });
    const cookie = res.headersArray().find((h) => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('token='));
    expect(cookie?.value).toMatch(/HttpOnly/i);
  });

  test('a wrong password gets 401', async ({ api, users }) => {
    const alice = await users.create();
    const res = await login(api, alice.email, 'Wrong-passw0rd');
    expect(res.status()).toBe(401);
    expect(await errorOf(res)).toBeTruthy();
  });

  test('an unknown email gets the same 401 as a wrong password', async ({ api }) => {
    const res = await login(api, uniqueEmail('nobody'), PASSWORD);
    expect(res.status()).toBe(401);
    expect(await errorOf(res)).toBe('Invalid email or password');
  });

  test('a malformed body gets 400', async ({ api }) => {
    const res = await api.post('/api/v1/auth/login', { data: 'not json', headers: { 'Content-Type': 'application/json' } });
    expect(res.status()).toBe(400);
  });

  test('10 failures from one IP lock that email from that IP, even with the right password', async ({ api, users }) => {
    const alice = await users.create();
    for (let i = 0; i < 10; i++) expect((await login(api, alice.email, `Wrong-${i}-pw`)).status()).toBe(401);
    expect((await login(api, alice.email, 'Wrong-x-pw')).status()).toBe(429);
    const res = await login(api, alice.email, PASSWORD);
    expect(res.status()).toBe(429);
    expect(await errorOf(res)).toBeTruthy();
  });

  test('a locked email can still log in from another IP', async ({ api, users, baseURL }) => {
    const alice = await users.create();
    for (let i = 0; i < 10; i++) await login(api, alice.email, `Wrong-${i}-pw`);
    expect((await login(api, alice.email, PASSWORD)).status()).toBe(429);
    const other = await newContext(baseURL, randomIP());
    expect((await login(other, alice.email, PASSWORD)).status()).toBe(200);
    await other.dispose();
  });

  test('the lock is per email, so another account from the same IP can log in', async ({ api, users }) => {
    const alice = await users.create();
    const bob = await users.create();
    for (let i = 0; i < 10; i++) await login(api, alice.email, `Wrong-${i}-pw`);
    expect((await login(api, bob.email, PASSWORD)).status()).toBe(200);
  });

  test('a successful login clears the failure count', async ({ api, users }) => {
    const alice = await users.create();
    for (let i = 0; i < 9; i++) expect((await login(api, alice.email, `Wrong-${i}-pw`)).status()).toBe(401);
    expect((await login(api, alice.email, PASSWORD)).status()).toBe(200);
    for (let i = 0; i < 9; i++) expect((await login(api, alice.email, `Wrong-${i}-pw`)).status()).toBe(401);
    expect((await login(api, alice.email, PASSWORD)).status()).toBe(200);
  });
});

test.describe('logout', () => {
  test('logout revokes the session so the old cookie gets 401', async ({ users }) => {
    const alice = await users.create();
    expect((await alice.api.get('/api/v1/users/me')).status()).toBe(200);
    const res = await alice.api.post('/api/v1/auth/logout');
    expect(res.status()).toBe(200);
    expect(await res.json()).toMatchObject({ message: expect.any(String) });
    expect((await alice.api.get('/api/v1/users/me')).status()).toBe(401);
  });

  test('logout clears the session cookie', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.post('/api/v1/auth/logout');
    const cleared = res.headersArray().find((h) => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('token='));
    expect(cleared?.value).toMatch(/expires=Thu, 01 Jan 1970|max-age=0|token=;/i);
  });

  test('logout ends only that session, not the same user elsewhere', async ({ users }) => {
    const alice = await users.create();
    const laptop = await users.login(alice.email, PASSWORD);
    expect((await alice.api.post('/api/v1/auth/logout')).status()).toBe(200);
    expect((await alice.api.get('/api/v1/users/me')).status()).toBe(401);
    expect((await laptop.api.get('/api/v1/users/me')).status()).toBe(200);
  });

  test('anonymous logout gets 401', async ({ api }) => {
    expect((await api.post('/api/v1/auth/logout')).status()).toBe(401);
  });
});

test.describe('password reset', () => {
  test('requesting a reset mails a link to the frontend reset page with a token', async ({ api, users }) => {
    const alice = await users.create();
    expect((await requestReset(api, alice.email)).status()).toBe(200);
    const { link, token } = await mailedResetLink(alice.email);
    expect(link.startsWith('https://www.k-pullup.test/reset-password?')).toBe(true);
    expect(token.length).toBeGreaterThan(10);
  });

  test('an unknown email still gets 200 and no mail is sent', async ({ api }) => {
    const email = uniqueEmail('ghost');
    expect((await requestReset(api, email)).status()).toBe(200);
    await sleep(1500);
    expect(await mailCount(email)).toBe(0);
  });

  test('an address gets at most 5 reset mails per hour, and every request still answers 200', async ({ api, users }) => {
    const alice = await users.create();
    const before = await mailCount(alice.email); // the signup verification mail
    for (let i = 0; i < 7; i++) expect((await requestReset(api, alice.email)).status()).toBe(200);
    await expect.poll(() => mailCount(alice.email), { timeout: 10_000 }).toBe(before + 5);
    await sleep(1500);
    expect(await mailCount(alice.email)).toBe(before + 5);
  });

  test('a reset token sets the new password once; the old password stops working', async ({ api, users }) => {
    const alice = await users.create();
    expect((await requestReset(api, alice.email)).status()).toBe(200);
    const { token } = await mailedResetLink(alice.email);

    expect((await resetPassword(api, token, NEW_PASSWORD)).status()).toBe(200);
    expect((await login(api, alice.email, PASSWORD)).status()).toBe(401);
    expect((await login(api, alice.email, NEW_PASSWORD)).status()).toBe(200);

    const again = await resetPassword(api, token, 'An0ther-passw0rd');
    expect(again.status()).toBe(400);
    expect(await errorOf(again)).toBeTruthy();
    expect((await login(api, alice.email, NEW_PASSWORD)).status()).toBe(200);
  });

  test('a password reset revokes every existing session', async ({ api, users }) => {
    const alice = await users.create();
    const phone = await users.login(alice.email, PASSWORD);
    // Hit both sessions first so they are cached in Redis, which must be invalidated too.
    expect((await alice.api.get('/api/v1/users/me')).status()).toBe(200);
    expect((await phone.api.get('/api/v1/users/me')).status()).toBe(200);

    expect((await requestReset(api, alice.email)).status()).toBe(200);
    const { token } = await mailedResetLink(alice.email);
    expect((await resetPassword(api, token, NEW_PASSWORD)).status()).toBe(200);

    expect((await alice.api.get('/api/v1/users/me')).status()).toBe(401);
    expect((await phone.api.get('/api/v1/users/me')).status()).toBe(401);
  });

  test('an unknown token is rejected', async ({ api }) => {
    const res = await resetPassword(api, 'not-a-real-token-0123456789', NEW_PASSWORD);
    expect(res.status()).toBe(400);
    expect(await errorOf(res)).toBeTruthy();
  });

  test('an expired token is rejected and the password is unchanged', async ({ api, users, db }) => {
    const alice = await users.create();
    expect((await requestReset(api, alice.email)).status()).toBe(200);
    const { token } = await mailedResetLink(alice.email);
    await db.execute('UPDATE PasswordResetTokens SET ExpiresAt = NOW() - INTERVAL 1 MINUTE WHERE UserID = ?', [alice.userId]);

    expect((await resetPassword(api, token, NEW_PASSWORD)).status()).toBe(400);
    expect((await login(api, alice.email, PASSWORD)).status()).toBe(200);
  });

  test('a newer reset request invalidates the older link', async ({ api, users }) => {
    const alice = await users.create();
    expect((await requestReset(api, alice.email)).status()).toBe(200);
    const first = (await mailedResetLink(alice.email)).token;
    expect((await requestReset(api, alice.email)).status()).toBe(200);
    await expect.poll(async () => (await mailedResetLink(alice.email)).token).not.toBe(first);
    const second = (await mailedResetLink(alice.email)).token;

    expect((await resetPassword(api, first, NEW_PASSWORD)).status()).toBe(400);
    expect((await resetPassword(api, second, NEW_PASSWORD)).status()).toBe(200);
  });

  test('a weak new password is rejected and the token stays usable', async ({ api, users }) => {
    const alice = await users.create();
    expect((await requestReset(api, alice.email)).status()).toBe(200);
    const { token } = await mailedResetLink(alice.email);

    const res = await resetPassword(api, token, 'short1');
    expect(res.status()).toBe(400);
    expect(await errorOf(res)).toBeTruthy();
    expect((await login(api, alice.email, PASSWORD)).status()).toBe(200);
    expect((await resetPassword(api, token, NEW_PASSWORD)).status()).toBe(200);
  });
});

test.describe('oauth start', () => {
  for (const [provider, host] of [
    ['google', 'accounts.google.com'],
    ['kakao', 'kauth.kakao.com'],
    ['naver', 'nid.naver.com'],
  ]) {
    test(`/auth/${provider} redirects to ${provider} with a state and sets the oauth_state cookie`, async ({ api }) => {
      const res = await api.get(`/api/v1/auth/${provider}`, { maxRedirects: 0 });
      expect([302, 303]).toContain(res.status());
      const location = new URL(res.headers()['location']);
      expect(location.host).toBe(host);
      const state = location.searchParams.get('state');
      expect(state).toBeTruthy();
      // Cookies are encrypted by the API, so only presence can be checked here.
      const cookie = res.headersArray().find((h) => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('oauth_state='));
      expect(cookie?.value).toMatch(/^oauth_state=[^;]+;.*HttpOnly/i);
    });
  }
});

test.describe('apple login', () => {
  // The e2e mock plays appleid.apple.com: it serves the JWKS and signs identityTokens.
  const appleToken = async (api: APIRequestContext, q: Record<string, string>) =>
    (await api.get(`http://127.0.0.1:18090/__apple/token?${new URLSearchParams(q)}`)).text();
  const appleLogin = (api: APIRequestContext, identityToken?: string) => api.post('/api/v1/auth/apple', { data: { identityToken } });

  test('a valid identityToken logs in, and the same Apple account gets the same user', async ({ api, baseURL }) => {
    const sub = `001234.${Date.now()}`;
    const email = uniqueEmail('apple');
    const first = await appleLogin(api, await appleToken(api, { sub, email }));
    expect(first.status()).toBe(200);
    const { user } = await first.json();
    expect(user).toMatchObject({ email });

    // The API encrypts cookies, so authenticate with the Set-Cookie value rather than the raw token.
    const cookie = first.headersArray().find((h) => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('token='))!;
    const me = await (await newContext(baseURL, randomIP(), cookie.value.split(';')[0].slice('token='.length))).get('/api/v1/users/me');
    expect(await me.json()).toMatchObject({ userId: user.userId, email, provider: 'apple' });

    const again = await appleLogin(api, await appleToken(api, { sub, email }));
    expect((await again.json()).user.userId).toBe(user.userId);
  });

  test('an Apple account that shared no email is refused', async ({ api }) => {
    const res = await appleLogin(api, await appleToken(api, { sub: `001234.${Date.now()}` }));
    expect(res.status()).toBe(400);
  });

  test('tokens for another app, expired, or missing are rejected', async ({ api }) => {
    const email = uniqueEmail('apple');
    expect((await appleLogin(api, await appleToken(api, { sub: 's', email, aud: 'com.other.app' }))).status()).toBe(401);
    expect((await appleLogin(api, await appleToken(api, { sub: 's', email, exp: '-60' }))).status()).toBe(401);
    expect((await appleLogin(api)).status()).toBe(400);
  });
});

test.describe('session tokens', () => {
  test('concurrent logins each get a cookie for their own account', async ({ users, baseURL }) => {
    const people: Awaited<ReturnType<typeof users.create>>[] = [];
    for (let i = 0; i < 12; i++) people.push(await users.create());
    // Users hold at most 3 sessions, so each logs in once more, all at the same time.
    const results = await Promise.all(people.map(async (p) => {
      const ctx = await newContext(baseURL, p.ip);
      const res = await login(ctx, p.email, PASSWORD);
      const cookie = res.headersArray().find((h) => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('token='));
      await ctx.dispose();
      if (!cookie) return { want: p.userId, got: `login ${res.status()}` };
      const me = await newContext(baseURL, p.ip, cookie.value.split(';')[0].slice('token='.length));
      const r = await me.get('/api/v1/users/me');
      const got = r.status() === 200 ? (await r.json()).userId : `me ${r.status()}`;
      await me.dispose();
      return { want: p.userId, got };
    }));
    expect(results.filter((r) => r.got !== r.want)).toEqual([]);
  });

  test('concurrent reset requests each mail a link that resets only that account', async ({ users, baseURL }) => {
    const people: Awaited<ReturnType<typeof users.create>>[] = [];
    for (let i = 0; i < 8; i++) people.push(await users.create());
    await Promise.all(people.map(async (p) => expect((await requestReset(p.api, p.email)).status()).toBe(200)));
    const results = [];
    for (const p of people) {
      const { token } = await mailedResetLink(p.email);
      const reset = (await resetPassword(p.api, token, NEW_PASSWORD)).status();
      const ctx = await newContext(baseURL, p.ip);
      results.push({ email: p.email, reset, newLogin: (await login(ctx, p.email, NEW_PASSWORD)).status() });
      await ctx.dispose();
    }
    expect(results.filter((r) => r.reset !== 200 || r.newLogin !== 200)).toEqual([]);
  });
});

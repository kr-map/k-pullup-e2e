import { execFileSync } from 'node:child_process';
import type { APIResponse } from '@playwright/test';
import type { Pool } from 'mysql2/promise';
import { test, expect } from '../fixtures';
import { createMarker, markerMultipart, offsetNorth, randomLandPoint, tinyPng, waitForAddress } from '../helpers/markers';

const redis = (...args: string[]) => execFileSync('docker', ['exec', process.env.E2E_REDIS_CONTAINER || 'kpull-e2e-redis-1', 'redis-cli', '--raw', ...args], { encoding: 'utf8' }).trim();

async function raceCreates(db: Pool, userId: number, count: number, run: () => Promise<APIResponse[]>) {
  const blocker = await db.getConnection();
  let pending: Promise<APIResponse[]> | undefined;
  let barrierError: unknown;
  try {
    await blocker.beginTransaction();
    await blocker.execute('SELECT UserID FROM Users WHERE UserID = ? FOR UPDATE', [userId]);
    pending = run();
    // Old requests wait on the FK; new ones queue behind the final DB write lock.
    await expect.poll(async () => {
      const [rows] = await db.query(
        'SELECT COUNT(DISTINCT w.REQUESTING_ENGINE_TRANSACTION_ID) n FROM performance_schema.data_lock_waits w ' +
        'JOIN performance_schema.data_locks l ON l.ENGINE_LOCK_ID = w.REQUESTING_ENGINE_LOCK_ID ' +
        "WHERE l.OBJECT_SCHEMA = 'chulbong' AND l.OBJECT_NAME = 'Users' AND l.INDEX_NAME = 'PRIMARY' AND l.LOCK_DATA = ?",
        [String(userId)],
      );
      const [locks] = await db.query("SELECT COUNT(*) n FROM performance_schema.metadata_locks WHERE OBJECT_TYPE = 'USER LEVEL LOCK' AND OBJECT_NAME = 'kpullup:marker-create' AND LOCK_STATUS = 'PENDING'");
      return Number((rows as { n: number }[])[0].n) + Number((locks as { n: number }[])[0].n);
    }, { timeout: 10_000 }).toBeGreaterThanOrEqual(count);
  } catch (err) { barrierError = err; }
  finally { await blocker.rollback(); blocker.release(); }
  const results = await pending!;
  if (barrierError) throw barrierError;
  return results;
}

for (const photos of [0, 1]) test(`marker concurrency: nearby simultaneous creates with ${photos} photos save exactly one marker`, async ({ users, db }) => {
  const alice = await users.create();
  const at = randomLandPoint();
  const results = await raceCreates(db, alice.userId, 4, () => Promise.all(
    Array.from({ length: 4 }, (_, i) => alice.api.post('/api/v1/markers', {
      multipart: markerMultipart({ at: offsetNorth(at, i), photos }),
    })),
  ));
  expect(results.map(r => r.status()).sort()).toEqual([201, 409, 409, 409]);
  for (const result of results.filter(r => r.status() === 409)) expect((await result.json()).error).toContain('nearby');
  const [rows] = await db.query('SELECT COUNT(*) n FROM Markers WHERE UserID = ?', [alice.userId]);
  expect(Number((rows as { n: number }[])[0].n)).toBe(1);
});

test('marker concurrency: concurrent facility replacements stay complete', async ({ users, db }) => {
  const alice = await users.create();
  const { markerId } = await createMarker(alice);
  const payloads = [
    [{ facilityId: 1, quantity: 1 }, { facilityId: 2, quantity: 2 }],
    [{ facilityId: 2, quantity: 3 }, { facilityId: 3, quantity: 4 }],
  ];
  const results = await Promise.all(payloads.map(facilities => alice.api.post('/api/v1/markers/facilities', {
    data: { markerId, facilities },
  })));
  expect(results.map(r => r.status())).toEqual([200, 200]);
  const [rows] = await db.query('SELECT FacilityID facilityId, Quantity quantity FROM MarkerFacilities WHERE MarkerID = ? ORDER BY FacilityID', [markerId]);
  expect(payloads).toContainEqual(rows);
});

test('marker concurrency: an invalid daily counter rejects creation until recovery', async ({ users }) => {
  const alice = await users.create();
  await createMarker(alice);
  const key = redis('KEYS', `marker_limit:${alice.userId}:*`);
  redis('SET', key, 'invalid', 'EX', '86400');
  try {
    const result = await alice.api.post('/api/v1/markers', { multipart: markerMultipart() });
    expect(result.status()).toBe(503);
    expect(result.headers()['retry-after']).toBe('3');
  } finally { redis('SET', key, '1', 'EX', '86400'); }
  await createMarker(alice);
  expect(redis('GET', key)).toBe('2');
});

test('marker concurrency: simultaneous creates cannot cross the daily limit', async ({ users, db }) => {
  const alice = await users.create();
  await createMarker(alice);
  let key = '';
  await expect.poll(() => (key = redis('KEYS', `marker_limit:${alice.userId}:*`))).not.toBe('');
  redis('SET', key, '9', 'EX', '86400');
  const results = await raceCreates(db, alice.userId, 3, () => Promise.all(
    Array.from({ length: 3 }, () => alice.api.post('/api/v1/markers', { multipart: markerMultipart() })),
  ));
  expect(results.map(r => r.status()).sort()).toEqual([201, 429, 429]);
  expect(redis('GET', key)).toBe('10');
});

test('marker concurrency: repeated identical description updates all succeed', async ({ users }) => {
  const alice = await users.create();
  const { markerId } = await createMarker(alice);
  const results = await Promise.all(Array.from({ length: 4 }, () => alice.api.put(`/api/v1/markers/${markerId}`, {
    multipart: { description: 'same description' },
  })));
  expect(results.map(r => r.status())).toEqual([200, 200, 200, 200]);
});

test('marker concurrency: updates racing with deletion leave no marker or server errors', async ({ users, api }) => {
  const alice = await users.create();
  const { markerId } = await createMarker(alice, { photos: 1 });
  const results = await Promise.all([
    alice.api.delete(`/api/v1/markers/${markerId}`),
    ...Array.from({ length: 4 }, (_, i) => alice.api.put(`/api/v1/markers/${markerId}`, {
      multipart: { description: `parallel ${i}` },
    })),
  ]);
  expect(results[0].status()).toBe(200);
  for (const result of results.slice(1)) expect([200, 404]).toContain(result.status());
  expect((await api.get(`/api/v1/markers/${markerId}/details`)).status()).toBe(404);
});

test('marker concurrency: distinct reports on one marker approve without losing photos or comments', async ({ users, api, db }) => {
  const alice = await users.create();
  const marker = await createMarker(alice);
  await waitForAddress(db, marker.markerId);
  for (let i = 0; i < 2; i++) {
    const result = await alice.api.post('/api/v1/reports', { multipart: {
      markerId: String(marker.markerId), latitude: String(marker.latitude), longitude: String(marker.longitude),
      description: `parallel report ${i}`,
      photos: { name: 'report.png', mimeType: 'image/png', buffer: tinyPng() },
    } });
    expect(result.status(), await result.text()).toBe(200);
  }
  const reports = await (await api.get(`/api/v1/reports/marker/${marker.markerId}`)).json();
  expect(reports).toHaveLength(2);
  const results = await Promise.all(reports.map((r: { reportId: number }) => alice.api.post(`/api/v1/reports/approve/${r.reportId}`)));
  expect(results.map((r: APIResponse) => r.status())).toEqual([200, 200]);
  const [rows] = await db.query('SELECT (SELECT COUNT(*) FROM Photos WHERE MarkerID = ?) photos, (SELECT COUNT(*) FROM Comments WHERE MarkerID = ?) comments', [marker.markerId, marker.markerId]);
  expect(rows).toEqual([{ photos: 2, comments: 2 }]);
});

test('marker concurrency: admin photo uploads preserve the response and refresh the map', async ({ users, api }) => {
  const admin = await users.create({ admin: true });
  const { markerId } = await createMarker(admin);
  await api.get('/api/v1/markers');
  const form = () => ({ markerId: String(markerId), photos: { name: 'photo.png', mimeType: 'image/png', buffer: tinyPng() } });
  const uploaded = await admin.api.post('/api/v1/markers/upload', { multipart: form() });
  expect(uploaded.status(), await uploaded.text()).toBe(200);
  expect((await uploaded.json()).urls).toEqual([expect.any(String)]);
  expect((await (await api.get('/api/v1/markers')).json()).find((m: { markerId: number }) => m.markerId === markerId).hasPhoto).toBe(true);
  const [upload, deletion] = await Promise.all([
    admin.api.post('/api/v1/markers/upload', { multipart: form() }),
    admin.api.delete(`/api/v1/markers/${markerId}`),
  ]);
  expect([200, 404]).toContain(upload.status());
  expect(deletion.status()).toBe(200);
  expect((await api.get(`/api/v1/markers/${markerId}/details`)).status()).toBe(404);
});

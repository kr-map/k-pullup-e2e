import WebSocket from 'ws';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { test, expect, randomIP } from '../fixtures';

async function notificationSocket(baseURL: string) {
  const url = new URL('/ws/notification', baseURL.replace(/^http/, 'ws'));
  url.searchParams.set('request-id', `limits-${randomUUID()}`);
  const ws = new WebSocket(url, { headers: { Origin: 'https://www.k-pullup.com', 'Fly-Client-IP': randomIP() } });
  await once(ws, 'open');
  return ws;
}

for (const kind of ['text', 'binary', 'fragmented'] as const) {
  test(`security limits: an oversized ${kind} notification message closes only its sender`, async ({ baseURL, api }) => {
    const ws = await notificationSocket(baseURL!);
    let closeCode: number | undefined;
    ws.on('close', code => { closeCode = code; });
    try {
      expect(ws.extensions).not.toContain('permessage-deflate');
      if (kind === 'fragmented') {
        ws.send(Buffer.alloc(4096, 65), { binary: false, fin: false });
        ws.send('a', { fin: true });
      } else {
        ws.send(Buffer.alloc(8192, 65), { binary: kind === 'binary' });
      }
      await expect.poll(() => closeCode, { timeout: 3000 }).toBe(1009);
    } finally {
      ws.terminate();
      expect((await api.get('/')).status()).toBe(200);
    }
  });
}

test('security limits: notification messages and close reasons cannot inject server logs', async ({ baseURL, api }) => {
  const ws = await notificationSocket(baseURL!);
  const marker = `notification-sensitive-${randomUUID()}`;
  try {
    const pong = once(ws, 'pong');
    ws.send(marker);
    ws.ping();
    await pong; // The reader has processed the preceding data message.
    expect(await readFile('.run/api-output.txt', 'utf8')).not.toContain(marker);
    const closeReason = `close-sensitive-${randomUUID()}`;
    const closed = once(ws, 'close');
    ws.close(1000, closeReason);
    await closed;
    // Let the server finish its read-error path after the close handshake.
    await new Promise(resolve => setTimeout(resolve, 100));
    expect((await api.get('/')).status()).toBe(200);
    expect(await readFile('.run/api-output.txt', 'utf8')).not.toContain(closeReason);
  } finally { ws.terminate(); }
});

test('security limits: a 4 KiB notification message and heartbeats remain supported', async ({ baseURL }) => {
  const ws = await notificationSocket(baseURL!);
  try {
    const pong = once(ws, 'pong');
    ws.send('a'.repeat(4096));
    ws.send('{"type":"ping"}');
    ws.ping();
    await pong;
    expect(ws.readyState).toBe(WebSocket.OPEN);
  } finally { ws.terminate(); }
});

const navigation = { 'Sec-Fetch-Site': 'cross-site', 'Sec-Fetch-Mode': 'navigate', 'Sec-Fetch-Dest': 'document' };

test('security limits: an administrator opening a link cannot trigger S3 cleanup', async ({ users, api }) => {
  const admin = await users.create({ admin: true });
  const objectUrl = `http://127.0.0.1:29090/chulbong-e2e/csrf-${randomUUID()}.txt`;
  expect((await api.put(objectUrl, { data: 'must survive GET', headers: { 'Content-Type': 'text/plain' } })).status()).toBe(200);
  try {
    const res = await admin.api.get('/api/v1/admin/dead?kill=y', { headers: navigation });
    expect((await api.get(objectUrl)).status()).toBe(200);
    expect(res.status()).toBe(405);
    expect(res.headers()['allow']).toBe('POST');
    expect((await admin.api.head('/api/v1/admin/dead?kill=y')).status()).toBe(405);
  } finally { await api.delete(objectUrl); }
});

test('security limits: an administrator opening a link cannot trigger marker imports', async ({ users }) => {
  const admin = await users.create({ admin: true });
  // A future date keeps the old implementation from importing real fixture markers.
  const path = '/api/v1/admin/fetch?post=y&date=2100-01-01';
  const res = await admin.api.get(path, { headers: navigation });
  expect(res.status()).toBe(405);
  expect(res.headers()['allow']).toBe('POST');
  expect((await admin.api.head(path)).status()).toBe(405);
});

for (const [preview, action] of [
  ['/api/v1/admin/dead', '/api/v1/admin/dead?kill=y'],
  ['/api/v1/admin/fetch?date=2100-01-01', '/api/v1/admin/fetch?post=y&date=2100-01-01'],
]) {
  test(`security limits: ${preview} keeps admin previews and rejects unauthorized POST actions`, async ({ users, api }) => {
    const admin = await users.create({ admin: true });
    const ordinary = await users.create();
    expect((await api.post(action)).status()).toBe(401);
    expect((await ordinary.api.post(action)).status()).toBe(403);
    expect((await admin.api.post(action, { headers: { Origin: 'https://evil.test', 'Sec-Fetch-Site': 'cross-site' } })).status()).toBe(403);
    expect((await admin.api.get(preview)).status()).toBe(200);
    expect((await admin.api.post(preview, { headers: { Origin: 'https://www.k-pullup.com', 'Sec-Fetch-Site': 'same-site' } })).status()).toBe(200);
  });
}

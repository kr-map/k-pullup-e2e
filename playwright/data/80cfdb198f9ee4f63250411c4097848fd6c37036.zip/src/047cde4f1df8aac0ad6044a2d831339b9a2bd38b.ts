import { test, expect, type User } from '../fixtures';
import { createMarker } from '../helpers/markers';
import type { APIRequestContext } from '@playwright/test';

const UNKNOWN = 2_000_000_000;

async function details(api: APIRequestContext, markerId: number) {
  const res = await api.get(`/api/v1/markers/${markerId}/details`);
  expect(res.status()).toBe(200);
  return res.json();
}

const react = (user: User, markerId: number, reactionType: string) =>
  user.api.post(`/api/v1/markers/${markerId}/reactions`, { data: { reactionType } });

test.describe('dislikes', () => {
  test('a dislike shows in the status, the marker details and is undone', async ({ users, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(owner);

    expect(await (await alice.api.get(`/api/v1/markers/${markerId}/dislike-status`)).json()).toEqual({ disliked: false });

    expect((await alice.api.post(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(200);
    expect(await (await alice.api.get(`/api/v1/markers/${markerId}/dislike-status`)).json()).toEqual({ disliked: true });
    expect(await details(alice.api, markerId)).toMatchObject({ dislikeCount: 1, disliked: true });
    expect(await details(api, markerId)).toMatchObject({ dislikeCount: 1, disliked: false });

    expect((await alice.api.delete(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(200);
    expect(await (await alice.api.get(`/api/v1/markers/${markerId}/dislike-status`)).json()).toEqual({ disliked: false });
    const after = await details(alice.api, markerId);
    expect(after.dislikeCount ?? 0).toBe(0);
    expect(after.disliked).toBe(false);
  });

  test('disliking twice counts once', async ({ users, api }) => {
    const [owner, alice, bob] = await Promise.all([users.create(), users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    expect((await alice.api.post(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(200);
    expect((await alice.api.post(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(200);
    expect((await details(api, markerId)).dislikeCount).toBe(1);
    expect((await bob.api.post(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(200);
    expect((await details(api, markerId)).dislikeCount).toBe(2);
  });

  test('undoing a dislike that does not exist is a 4xx, not a server error', async ({ users }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    expect((await alice.api.delete(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(404);
  });

  test('disliking an unknown marker gives 404', async ({ users }) => {
    const alice = await users.create();
    expect((await alice.api.post(`/api/v1/markers/${UNKNOWN}/dislike`)).status()).toBe(404);
  });

  test('dislike endpoints need a login', async ({ users, api }) => {
    const { markerId } = await createMarker(await users.create());
    expect((await api.post(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(401);
    expect((await api.delete(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(401);
    expect((await api.get(`/api/v1/markers/${markerId}/dislike-status`)).status()).toBe(401);
  });

  test('a non-numeric marker id gives 400 on every dislike endpoint', async ({ users }) => {
    const alice = await users.create();
    expect((await alice.api.get('/api/v1/markers/abc/dislike-status')).status()).toBe(400);
    expect((await alice.api.post('/api/v1/markers/abc/dislike')).status()).toBe(400);
    expect((await alice.api.delete('/api/v1/markers/abc/dislike')).status()).toBe(400);
  });
});

test.describe('reactions', () => {
  test('a reaction is counted, shown as mine, changed and removed', async ({ users, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(owner);

    const set = await react(alice, markerId, 'clean');
    expect(set.status()).toBe(200);
    expect(await set.json()).toMatchObject({ counts: { clean: 1, crowded: 0, broken: 0, busy: 0, calm: 0 }, myReaction: 'clean' });

    const changed = await react(alice, markerId, 'calm');
    expect(await changed.json()).toMatchObject({ counts: { clean: 0, calm: 1 }, myReaction: 'calm' });

    const anon = await (await api.get(`/api/v1/markers/${markerId}/reactions`)).json();
    expect(anon.counts).toMatchObject({ calm: 1 });
    expect(anon.myReaction).toBeUndefined();
    expect((await details(alice.api, markerId)).reactions).toMatchObject({ counts: { calm: 1 }, myReaction: 'calm' });

    const removed = await alice.api.delete(`/api/v1/markers/${markerId}/reactions`);
    expect(removed.status()).toBe(200);
    const body = await removed.json();
    expect(body.counts).toMatchObject({ clean: 0, crowded: 0, broken: 0, busy: 0, calm: 0 });
    expect(body.myReaction).toBeUndefined();
    expect((await details(api, markerId)).reactions.counts.calm).toBe(0);
  });

  test('details show every count plus only the viewer\'s own dislike, favorite and reaction', async ({ users, api }) => {
    const [owner, alice, bob, carol] = await Promise.all([users.create(), users.create(), users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    expect((await alice.api.post(`/api/v1/markers/${markerId}/dislike`)).status()).toBe(200);
    expect((await alice.api.post(`/api/v1/markers/${markerId}/favorites`)).status()).toBeLessThan(300);
    for (const [u, r] of [[alice, 'clean'], [bob, 'broken'], [carol, 'clean']] as const) expect((await react(u, markerId, r)).status()).toBe(200);
    const counts = { clean: 2, crowded: 0, broken: 1, busy: 0, calm: 0, missing: 0 };

    const mine = await details(alice.api, markerId);
    expect(mine).toMatchObject({ dislikeCount: 1, favCount: 1, disliked: true, favorited: true });
    expect(mine.reactions).toEqual({ counts, myReaction: 'clean' });
    const bobs = await details(bob.api, markerId);
    expect(bobs).toMatchObject({ dislikeCount: 1, favCount: 1, disliked: false });
    expect(bobs.favorited).toBeUndefined();
    expect(bobs.reactions).toEqual({ counts, myReaction: 'broken' });
    const anon = await details(api, markerId);
    expect(anon).toMatchObject({ dislikeCount: 1, favCount: 1, disliked: false });
    expect(anon.favorited).toBeUndefined();
    expect(anon.reactions).toEqual({ counts });
  });

  test('reactions from different users add up', async ({ users, api }) => {
    const [owner, alice, bob] = await Promise.all([users.create(), users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    await react(alice, markerId, 'busy');
    await react(bob, markerId, 'busy');
    await react(owner, markerId, 'broken');

    const mine = await (await bob.api.get(`/api/v1/markers/${markerId}/reactions`)).json();
    expect(mine).toMatchObject({ counts: { busy: 2, broken: 1 }, myReaction: 'busy' });
  });

  test('every allowed reaction type is accepted', async ({ users }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    for (const type of ['clean', 'crowded', 'broken', 'busy', 'calm', 'missing']) {
      const res = await react(alice, markerId, type);
      expect(res.status(), type).toBe(200);
      expect((await res.json()).myReaction).toBe(type);
    }
  });

  test('missing is persisted, counted in the page bundle and removable', async ({ users, api, db }) => {
    const [owner, alice, bob] = await Promise.all([users.create(), users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    expect((await react(bob, markerId, 'crowded')).status()).toBe(200);
    expect((await react(alice, markerId, 'busy')).status()).toBe(200);
    const set = await react(alice, markerId, 'missing');
    expect(set.status(), await set.text()).toBe(200);
    expect(await set.json()).toMatchObject({ counts: { busy: 0, crowded: 1, missing: 1 }, myReaction: 'missing' });
    const [rows] = await db.execute('SELECT ReactionType FROM MarkerReactions WHERE MarkerID = ? AND UserID = ?', [markerId, alice.userId]);
    expect(rows).toEqual([{ ReactionType: 'missing' }]);
    const page = await alice.api.get(`/api/v1/markers/${markerId}/page`);
    expect(page.status()).toBe(200);
    expect((await page.json()).marker.reactions).toMatchObject({ counts: { crowded: 1, missing: 1 }, myReaction: 'missing' });
    const read = await api.get(`/api/v1/markers/${markerId}/reactions`);
    expect(read.headers()['cache-control']).toBe('private, no-store');
    expect(await read.json()).toMatchObject({ counts: { crowded: 1, missing: 1 } });
    expect((await details(api, markerId)).reactions.myReaction).toBeUndefined();
    const removed = await alice.api.delete(`/api/v1/markers/${markerId}/reactions`);
    expect(removed.status()).toBe(200);
    expect((await removed.json()).counts).toMatchObject({ crowded: 1, missing: 0 });
  });

  test('an unknown reaction type is rejected', async ({ users, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    for (const type of ['love', '', 'thumbsup']) {
      const res = await react(alice, markerId, type);
      expect(res.status(), JSON.stringify(type)).toBe(400);
      expect((await res.json()).error).toBeTruthy();
    }
    const summary = await (await api.get(`/api/v1/markers/${markerId}/reactions`)).json();
    expect(Object.values(summary.counts).every((n) => n === 0)).toBe(true);
  });

  test('reacting to an unknown marker gives 404', async ({ users }) => {
    const alice = await users.create();
    expect((await react(alice, UNKNOWN, 'clean')).status()).toBe(404);
  });

  test('reading reactions of an unknown marker gives 404', async ({ api }) => {
    expect((await api.get(`/api/v1/markers/${UNKNOWN}/reactions`)).status()).toBe(404);
  });

  test('reacting needs a login', async ({ users, api }) => {
    const { markerId } = await createMarker(await users.create());
    expect((await api.post(`/api/v1/markers/${markerId}/reactions`, { data: { reactionType: 'clean' } })).status()).toBe(401);
    expect((await api.delete(`/api/v1/markers/${markerId}/reactions`)).status()).toBe(401);
  });

  test('a non-numeric marker id gives 400 on every reaction endpoint', async ({ users, api }) => {
    expect((await api.get('/api/v1/markers/abc/reactions')).status()).toBe(400);
    const alice = await users.create();
    expect((await alice.api.delete('/api/v1/markers/abc/reactions')).status()).toBe(400);
    expect((await react(alice, Number.NaN, 'clean')).status()).toBe(400);
  });
});

test.describe('favorites', () => {
  const favoriteIds = async (user: User) => {
    const res = await user.api.get('/api/v1/users/favorites');
    expect(res.status()).toBe(200);
    return ((await res.json()) ?? []).map((f: { markerId: number }) => f.markerId);
  };

  test('a favorite shows in my list and in the marker details until removed', async ({ users, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    expect(await favoriteIds(alice)).not.toContain(markerId); // primes the favorites cache

    const add = await alice.api.post(`/api/v1/markers/${markerId}/favorites`);
    expect(add.status()).toBe(200);
    expect(await favoriteIds(alice)).toContain(markerId);
    expect(await details(alice.api, markerId)).toMatchObject({ favCount: 1, favorited: true });
    expect((await details(api, markerId)).favorited ?? false).toBe(false);

    expect((await alice.api.delete(`/api/v1/markers/${markerId}/favorites`)).status()).toBe(204);
    expect(await favoriteIds(alice)).not.toContain(markerId);
    const after = await details(alice.api, markerId);
    expect(after.favCount ?? 0).toBe(0);
    expect(after.favorited ?? false).toBe(false);
  });

  test('favorite counts add up across users', async ({ users, api }) => {
    const [owner, alice, bob] = await Promise.all([users.create(), users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    await alice.api.post(`/api/v1/markers/${markerId}/favorites`);
    await bob.api.post(`/api/v1/markers/${markerId}/favorites`);
    expect((await details(api, markerId)).favCount).toBe(2);
  });

  test('favoriting the same marker twice is a conflict', async ({ users, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(owner);
    expect((await alice.api.post(`/api/v1/markers/${markerId}/favorites`)).status()).toBe(200);
    const again = await alice.api.post(`/api/v1/markers/${markerId}/favorites`);
    expect((await details(api, markerId)).favCount).toBe(1);
    expect(again.status()).toBe(409);
  });

  test('a user can keep at most 10 favorites', async ({ users }) => {
    test.slow();
    const [ownerA, ownerB, alice] = await Promise.all([users.create(), users.create(), users.create()]);
    const markers = [
      ...(await Promise.all(Array.from({ length: 6 }, () => createMarker(ownerA)))),
      ...(await Promise.all(Array.from({ length: 5 }, () => createMarker(ownerB)))),
    ];
    for (const { markerId } of markers.slice(0, 10)) {
      expect((await alice.api.post(`/api/v1/markers/${markerId}/favorites`)).status()).toBe(200);
    }
    const eleventh = await alice.api.post(`/api/v1/markers/${markers[10].markerId}/favorites`);
    expect(eleventh.status()).toBe(403);
    expect((await eleventh.json()).error).toBeTruthy();
    expect(await favoriteIds(alice)).toHaveLength(10);

    // Removing one frees a slot.
    expect((await alice.api.delete(`/api/v1/markers/${markers[0].markerId}/favorites`)).status()).toBe(204);
    expect((await alice.api.post(`/api/v1/markers/${markers[10].markerId}/favorites`)).status()).toBe(200);
  });

  test('favoriting an unknown marker gives 404', async ({ users }) => {
    const alice = await users.create();
    expect((await alice.api.post(`/api/v1/markers/${UNKNOWN}/favorites`)).status()).toBe(404);
  });

  test('favorites need a login and a numeric marker id', async ({ users, api }) => {
    const { markerId } = await createMarker(await users.create());
    expect((await api.post(`/api/v1/markers/${markerId}/favorites`)).status()).toBe(401);
    expect((await api.delete(`/api/v1/markers/${markerId}/favorites`)).status()).toBe(401);
    expect((await api.get('/api/v1/users/favorites')).status()).toBe(401);
    const alice = await users.create();
    expect((await alice.api.post('/api/v1/markers/abc/favorites')).status()).toBe(400);
    expect((await alice.api.delete('/api/v1/markers/abc/favorites')).status()).toBe(400);
  });
});

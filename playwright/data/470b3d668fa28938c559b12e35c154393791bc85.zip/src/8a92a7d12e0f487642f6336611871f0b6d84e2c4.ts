import { test, expect } from '../fixtures';

const ORIGIN = 'https://www.k-pullup.com';

test('one PHP probe immediately bans the client, including API-prefixed paths', async ({ api }) => {
  expect((await api.get('/api/v1/search/marker?term=guide.php')).status()).toBe(200);
  const probe = await api.get('/api/v1/akp.PHP.bak');
  expect(probe.status()).toBe(403);
  expect(Number(probe.headers()['retry-after'])).toBeGreaterThan(0);
  expect((await api.get('/api/v1/markers')).status()).toBe(403);
});

test('Spamhaus DROP rejects IPv4 and IPv6 clients on their first API request', async ({ api }) => {
  // Addresses inside the official bundled snapshots; no requests leave the local stack.
  for (const ip of ['1.10.16.1', '2001:678:254::1']) {
    const res = await api.get('/api/v1/markers/9999999/details', { headers: { 'Fly-Client-IP': ip } });
    expect(res.status()).toBe(403);
    expect(res.headers()['x-request-id']).toBeTruthy();
  }
  expect((await api.get('/api/v1/markers/9999999/details')).status()).toBe(404);
});

test('repeated secret and PHP probes ban only the scanning client', async ({ api, users }) => {
  const alice = await users.create();
  for (let i = 0; i < 4; i++) {
    expect((await api.get('/robots.txt')).status()).toBe(404);
    expect((await api.get('/api/v1/markers/9999999/details')).status()).toBe(404);
  }
  for (const path of ['/.env', '/wp-admin/admin.php', '/.aws/credentials']) {
    const probe = await api.get(path);
    expect(probe.status()).toBe(403);
    expect(probe.headers()['x-request-id']).toBeTruthy();
  }
  const blocked = await api.get('/api/v1/markers/9999999/details');
  expect(blocked.status()).toBe(403);
  expect(Number(blocked.headers()['retry-after'])).toBeGreaterThan(0);
  expect((await api.get('/')).status()).toBe(200);
  expect((await alice.api.get('/api/v1/users/me')).status()).toBe(200);
});

test('browser profile PATCH has a cached preflight and works with credentials', async ({ users }) => {
  const alice = await users.create();
  const preflight = await alice.api.fetch('/api/v1/users/me', {
    method: 'OPTIONS', headers: { Origin: ORIGIN, 'Access-Control-Request-Method': 'PATCH', 'Access-Control-Request-Headers': 'content-type' },
  });
  expect(preflight.status()).toBe(204);
  expect(preflight.headers()['access-control-allow-methods']).toContain('PATCH');
  expect(preflight.headers()['access-control-max-age']).toBe('600');
  const res = await alice.api.patch('/api/v1/users/me', {
    headers: { Origin: ORIGIN, 'Sec-Fetch-Site': 'same-site' }, data: { username: `browser-${alice.userId}` },
  });
  expect(res.status(), await res.text()).toBe(200);
  expect(res.headers()['access-control-allow-credentials']).toBe('true');
  expect(res.headers()['access-control-expose-headers']).toContain('X-Request-ID');
  expect(res.headers()['x-request-id']).toBeTruthy();
});

test('untrusted browser writes cannot change or delete an account', async ({ users }) => {
  const alice = await users.create();
  for (const origin of ['https://evil.test', 'https://untrusted.k-pullup.com']) {
    const headers = { Origin: origin, 'Sec-Fetch-Site': origin.endsWith('.k-pullup.com') ? 'same-site' : 'cross-site' };
    expect((await alice.api.patch('/api/v1/users/me', { headers, data: { username: 'attacker-change' } })).status()).toBe(403);
    expect((await alice.api.delete('/api/v1/users/me', { headers })).status()).toBe(403);
  }
  const profile = await alice.api.get('/api/v1/users/me');
  expect(profile.status()).toBe(200);
  expect((await profile.json()).username).toBe(alice.username);
});

test('rate limits group resource IDs and retain CORS and request ID on rejection', async ({ api }) => {
  for (let i = 0; i < 60; i++) {
    const res = await api.put(`/api/v1/markers/${9000000+i}`, { headers: { Origin: ORIGIN }, data: {} });
    expect(res.status()).toBe(401);
  }
  const res = await api.put('/api/v1/markers/9999999', { headers: { Origin: ORIGIN }, data: {} });
  expect(res.status()).toBe(429);
  expect(res.headers()['access-control-allow-origin']).toBe(ORIGIN);
  expect(res.headers()['retry-after']).toBeTruthy();
  expect(res.headers()['x-request-id']).toBeTruthy();
  expect((await api.get('/api/v1/markers/9999999/details')).status()).toBe(404);
});

test('Apple cross-origin POST still reaches identity-token validation', async ({ api }) => {
  const res = await api.post('/api/v1/auth/apple', {
    headers: { Origin: 'https://appleid.apple.com', 'Sec-Fetch-Site': 'cross-site' }, data: {},
  });
  expect(res.status()).toBe(400);
  expect((await api.post('/api/v1/auth/apple', {
    headers: { Origin: 'https://evil.test', 'Sec-Fetch-Site': 'cross-site' }, data: {},
  })).status()).toBe(403);
});

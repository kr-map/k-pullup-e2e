import { type RowDataPacket } from 'mysql2';
import { test, expect } from '../fixtures';

const list = '/api/v1/notices';
const create = '/api/v1/admin/notices';
const preview = `${create}/preview`;
const editor = '/api/v1/admin/notices-ui';

test('public notices keep their response shape and reflect admin publishing and deletion', async ({ api, db, users }) => {
  const admin = await users.create({ admin: true });
  const user = await users.create();
  const input = { title: '  공지 테스트  ', content: '첫 문단\n\n**강조**\n\n<em data-raw-html>HTML</em>' };
  await db.execute('INSERT INTO Notices (Title, Content, AuthorID, Published) VALUES (?, ?, ?, 0)', ['Draft', 'Hidden', admin.userId]);

  try {
    const empty = await api.get(list);
    expect(empty.status()).toBe(200);
    expect(await empty.json()).toEqual([]);
    expect((await api.get(editor)).status()).toBe(401);
    expect((await user.api.get(editor)).status()).toBe(403);
    expect((await user.api.post(create, { data: input })).status()).toBe(403);
    expect((await api.post(preview, { data: input })).status()).toBe(401);
    const page = await admin.api.get(editor);
    expect(page.status(), await page.text()).toBe(200);
    expect(page.headers()['cache-control']).toBe('no-store');
    expect(await page.text()).toContain('공지 작성');

    const rendered = await admin.api.post(preview, { data: input });
    expect(rendered.status(), await rendered.text()).toBe(200);
    const { title, html } = await rendered.json();
    expect(title).toBe(input.title.trim());
    expect(html).toContain('<strong>강조</strong>');
    expect(html).not.toContain('<em data-raw-html>');
    const [rows] = await db.query<RowDataPacket[]>('SELECT Title FROM Notices WHERE AuthorID = ?', [admin.userId]);
    expect(rows.map(row => row.Title)).toEqual(['Draft']);

    for (const invalid of [
      { ...input, title: ' ' },
      { ...input, content: '\n\t ' },
      { ...input, title: '가'.repeat(201) },
      { ...input, content: '가'.repeat(21846) },
    ]) {
      expect((await admin.api.post(create, { data: invalid })).status()).toBe(400);
    }

    const published = await admin.api.post(create, { data: input });
    expect(published.status(), await published.text()).toBe(200);
    const { noticeID } = await published.json();
    expect(Number.isInteger(noticeID)).toBe(true);
    const response = await api.get(list);
    expect(response.status()).toBe(200);
    expect(response.headers()['content-type']).toMatch(/^application\/json\b/);
    expect(await response.json()).toEqual([{
      noticeId: noticeID, title: input.title.trim(), content: input.content,
      createdAt: expect.any(String), updatedAt: expect.any(String),
    }]);

    expect((await user.api.delete(`${create}/${noticeID}`)).status()).toBe(403);
    expect((await admin.api.delete(`${create}/0`)).status()).toBe(400);
    expect((await admin.api.delete(`${create}/${noticeID}`)).status()).toBe(200);
    expect(await (await api.get(list)).json()).toEqual([]);
  } finally {
    await db.execute('DELETE FROM Notices WHERE AuthorID = ?', [admin.userId]);
  }
});

import { test, expect } from '../fixtures';

test('server answers @readonly', async ({ api }) => {
  expect((await api.get('/')).status()).toBe(200);
});

test('a new user can sign up, log in and see their profile', async ({ users }) => {
  const alice = await users.create();
  const me = await alice.api.get('/api/v1/users/me');
  expect(me.status()).toBe(200);
  expect(await me.json()).toMatchObject({ userId: alice.userId, email: alice.email });
});

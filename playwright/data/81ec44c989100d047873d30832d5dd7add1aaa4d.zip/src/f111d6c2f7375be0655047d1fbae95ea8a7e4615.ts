import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import type { APIResponse } from '@playwright/test';
import type { Pool } from 'mysql2/promise';
import { test, expect, type User } from '../fixtures';
import { createMarker } from '../helpers/markers';

const post = (user: User, markerId: number, text = 'quota check') =>
  user.api.post('/api/v1/comments', { data: { markerId, commentText: text } });
const redis = (...args: string[]) => execFileSync('docker', [
  'compose', '-f', fileURLToPath(new URL('../docker-compose.yml', import.meta.url)),
  'exec', '-T', 'redis', 'redis-cli', '--raw', ...args,
], { encoding: 'utf8' }).trim();

async function limitedUser(users: { create(): Promise<User> }) {
  const user = await users.create();
  // The reserved k-pullup account (ID 1) is exempt, including in an empty test DB.
  return user.userId === 1 ? users.create() : user;
}

async function quotaKey(userId: number) {
  let key = '';
  await expect.poll(() => (key = redis('KEYS', `comment_limit:${userId}:*`))).not.toBe('');
  return key;
}

async function raceUnderAuthorLock(db: Pool, userId: number, count: number, run: () => Promise<APIResponse[]>) {
  const blocker = await db.getConnection();
  let pending: Promise<APIResponse[]> | undefined;
  let barrierError: unknown;
  try {
    await blocker.beginTransaction();
    await blocker.execute('SELECT UserID FROM Users WHERE UserID = ? FOR UPDATE', [userId]);
    pending = run();
    // The old INSERT waits on its author FK; the fix waits before reading the quota.
    await expect.poll(async () => {
      const [rows] = await db.query(
        'SELECT COUNT(DISTINCT w.REQUESTING_ENGINE_TRANSACTION_ID) n FROM performance_schema.data_lock_waits w ' +
        'JOIN performance_schema.data_locks l ON l.ENGINE_LOCK_ID = w.REQUESTING_ENGINE_LOCK_ID ' +
        "WHERE l.OBJECT_SCHEMA = 'chulbong' AND l.OBJECT_NAME = 'Users' AND l.INDEX_NAME = 'PRIMARY' AND l.LOCK_DATA = ?",
        [String(userId)],
      );
      return Number((rows as { n: number }[])[0].n);
    }, { timeout: 10_000 }).toBeGreaterThanOrEqual(count);
  } catch (err) { barrierError = err; }
  finally { await blocker.rollback(); blocker.release(); }
  const results = await pending!;
  if (barrierError) throw barrierError;
  return results;
}

test('comment quota: concurrent posts cannot exceed three active comments per marker', async ({ users, db }) => {
  const alice = await limitedUser(users);
  const admin = await users.create({ admin: true });
  const { markerId } = await createMarker(alice);
  const results = await raceUnderAuthorLock(db, alice.userId, 4, () =>
    Promise.all(Array.from({ length: 4 }, (_, i) => post(alice, markerId, `parallel ${i}`))));
  expect(results.map(r => r.status()).sort()).toEqual([200, 200, 200, 400]);
  const [rows] = await db.query('SELECT COUNT(*) n FROM Comments WHERE MarkerID = ? AND UserID = ? AND DeletedAt IS NULL', [markerId, alice.userId]);
  expect(Number((rows as { n: number }[])[0].n)).toBe(3);
  const status = await admin.api.get(`/api/v1/admin/users/${alice.userId}/daily-status`);
  expect((await status.json()).comments).toMatchObject({ current: 3, remaining: 12 });
});

test('comment quota: concurrent posts cannot cross the daily limit or charge rejected posts', async ({ users, db }) => {
  const alice = await limitedUser(users);
  const admin = await users.create({ admin: true });
  const { markerId } = await createMarker(alice);
  expect((await post(alice, markerId, 'seed')).status()).toBe(200);
  const key = await quotaKey(alice.userId);
  // Real historical rows, including deletions, still count toward creations today.
  await db.query('INSERT INTO Comments (MarkerID, UserID, CommentText, PostedAt, UpdatedAt, DeletedAt) VALUES ' +
    Array(13).fill('(?, ?, ?, NOW(), NOW(), NOW())').join(','),
    Array.from({ length: 13 }, (_, i) => [markerId, alice.userId, `history ${i}`]).flat());
  expect(redis('SET', key, '14', 'EX', '86400')).toBe('OK');
  const results = await raceUnderAuthorLock(db, alice.userId, 2, () =>
    Promise.all([post(alice, markerId, 'last slot a'), post(alice, markerId, 'last slot b')]));
  expect(results.map(r => r.status()).sort()).toEqual([200, 429]);
  expect((await post(alice, markerId, 'already full')).status()).toBe(429);
  const status = await admin.api.get(`/api/v1/admin/users/${alice.userId}/daily-status`);
  expect((await status.json()).comments).toMatchObject({ current: 15, remaining: 0 });
  const [rows] = await db.query('SELECT COUNT(*) n FROM Comments WHERE UserID = ?', [alice.userId]);
  expect(Number((rows as { n: number }[])[0].n)).toBe(15);
});

test('comment quota: a broken counter fails closed and a retry succeeds after recovery', async ({ users, db }) => {
  const alice = await limitedUser(users);
  const { markerId } = await createMarker(alice);
  expect((await post(alice, markerId, 'seed')).status()).toBe(200);
  const key = await quotaKey(alice.userId);
  redis('SET', key, 'invalid', 'EX', '86400');
  try {
    const res = await post(alice, markerId, 'must not be stored');
    expect(res.status()).toBe(503);
    expect(res.headers()['retry-after']).toBe('3');
    const [rows] = await db.query('SELECT COUNT(*) n FROM Comments WHERE UserID = ?', [alice.userId]);
    expect(Number((rows as { n: number }[])[0].n)).toBe(1);
  } finally { redis('SET', key, '1', 'EX', '86400'); }
  expect((await post(alice, markerId, 'recovered')).status()).toBe(200);
  expect(redis('GET', key)).toBe('2');
});

test('comment quota: a failed insert rolls back without consuming quota or keeping locks', async ({ users }) => {
  const alice = await limitedUser(users);
  const { markerId } = await createMarker(alice);
  // Exceeds MySQL TEXT capacity; a future early 4xx validation is also acceptable.
  const bad = await post(alice, markerId, 'a'.repeat(65536));
  expect(bad.status()).toBeGreaterThanOrEqual(400);
  expect(redis('KEYS', `comment_limit:${alice.userId}:*`)).toBe('');
  expect((await post(alice, markerId, 'valid retry')).status()).toBe(200);
  expect(redis('GET', await quotaKey(alice.userId))).toBe('1');
});

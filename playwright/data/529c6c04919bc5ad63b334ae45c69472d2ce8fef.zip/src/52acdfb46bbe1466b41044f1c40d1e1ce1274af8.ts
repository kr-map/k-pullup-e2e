import { randomBytes } from 'node:crypto';
import { test, expect, PASSWORD, uniqueEmail } from '../fixtures';
import {
  NotificationSocket, createMarker, createReport, loginSession, postNotification, signupWith, sleep, verifyEmail, waitSubscribed,
} from '../helpers/users';

const tag = () => randomBytes(4).toString('hex');
const NEW_PASSWORD = 'E2e-changed9!';

test.describe('GET /users/me', () => {
  test('anonymous callers get 401 on every user endpoint', async ({ api }) => {
    for (const [method, path] of [
      ['get', '/api/v1/users/me'], ['patch', '/api/v1/users/me'], ['delete', '/api/v1/users/me'],
      ['get', '/api/v1/users/favorites'], ['get', '/api/v1/users/reports'], ['get', '/api/v1/users/reports/for-my-markers'],
      ['delete', '/api/v1/users/s3/objects'],
    ] as const) {
      const res = await api[method](path);
      expect(res.status(), `${method} ${path}`).toBe(401);
      expect((await res.json()).error).toBeTruthy();
    }
  });

  test('a forged cookie gets 401', async ({ api }) => {
    const res = await api.get('/api/v1/users/me', { headers: { Cookie: 'token=not-a-real-token' } });
    expect(res.status()).toBe(401);
  });

  test('a new user sees their id, email, username and website provider', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.get('/api/v1/users/me');
    expect(res.status()).toBe(200);
    const me = await res.json();
    expect(me).toMatchObject({ userId: alice.userId, email: alice.email, username: alice.username, provider: 'website' });
    expect(me.username).toBeTruthy();
    expect(me.chulbong ?? false).toBe(false);
  });

  test('signing up without a username gives a random name, never the email address part', async ({ users }) => {
    const alice = await users.create(); // the fixture signs up with email and password only
    expect(alice.username).toMatch(/^[가-힣]+-[가-힣]+-\d{2,3}$/);
    expect(alice.username).not.toContain(alice.email.split('@')[0]);
  });

  test('an admin profile is flagged chulbong', async ({ users }) => {
    const admin = await users.create({ admin: true });
    expect(await (await admin.api.get('/api/v1/users/me')).json()).toMatchObject({ userId: admin.userId, chulbong: true });
  });

  test('the profile counts a marker created after it was cached', async ({ users }) => {
    const alice = await users.create();
    await expect.poll(async () => (await alice.api.get('/api/v1/users/me')).headers()['x-cache']).toBe('hit');
    await createMarker(alice);
    expect((await (await alice.api.get('/api/v1/users/me')).json()).markerCount).toBe(1);
  });
});

test.describe('PATCH /users/me', () => {
  test('a user can rename themselves and the profile shows the new name', async ({ users }) => {
    const alice = await users.create();
    await expect.poll(async () => (await alice.api.get('/api/v1/users/me')).headers()['x-cache']).toBe('hit');
    const name = `e2e-${tag()}`;
    const res = await alice.api.patch('/api/v1/users/me', { data: { username: name } });
    expect(res.status(), await res.text()).toBe(200);
    expect(await res.json()).toMatchObject({ userId: alice.userId, username: name, email: alice.email });
    expect((await (await alice.api.get('/api/v1/users/me')).json()).username).toBe(name);
  });

  test("a username another user already has is rejected with 400", async ({ users }) => {
    const alice = await users.create();
    const bob = await users.create();
    const res = await bob.api.patch('/api/v1/users/me', { data: { username: alice.username } });
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toContain('already in use');
    expect((await (await bob.api.get('/api/v1/users/me')).json()).username).toBe(bob.username);
  });

  test('bad words in a username are masked', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.patch('/api/v1/users/me', { data: { username: `e2e${tag()}fuck` } });
    expect(res.status(), await res.text()).toBe(200);
    const { username } = await res.json();
    expect(username).not.toMatch(/fuck/i);
    expect(username).toContain('****');
  });

  test('a username containing "admin" in any letter case is replaced', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.patch('/api/v1/users/me', { data: { username: `Admin${tag()}` } });
    expect(res.status(), await res.text()).toBe(200);
    expect((await res.json()).username).not.toMatch(/admin/i);
  });

  test('an empty, blank or 1-character username is rejected with 400', async ({ users }) => {
    const alice = await users.create();
    for (const username of ['', '   ', 'a']) {
      const res = await alice.api.patch('/api/v1/users/me', { data: { username } });
      expect(res.status(), JSON.stringify(username)).toBe(400);
      expect((await res.json()).error).not.toContain('already in use'); // a blank name is invalid, not taken
    }
    expect((await (await alice.api.get('/api/v1/users/me')).json()).username).toBe(alice.username);
  });

  test('a username longer than the column fits is rejected with 400, not 5xx', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.patch('/api/v1/users/me', { data: { username: `e2e${tag()}${'a'.repeat(300)}` } });
    expect(res.status()).toBe(400);
  });

  test('a malformed body is rejected with 400', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.patch('/api/v1/users/me', { headers: { 'Content-Type': 'application/json' }, data: '{"username":' });
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toBeTruthy();
  });

  test('a weak new password is rejected and the old one keeps working', async ({ users }) => {
    const alice = await users.create();
    for (const password of ['short1', 'onlyletters', '12345678901']) {
      const res = await alice.api.patch('/api/v1/users/me', { data: { password } });
      expect(res.status(), password).toBe(400);
      expect((await res.json()).error).toBeTruthy();
    }
    await users.login(alice.email, PASSWORD);
  });

  test('a password change keeps this session, ends the others and swaps the login password', async ({ users, baseURL, api }) => {
    const alice = await users.create();
    const other = await loginSession(baseURL, alice.email, PASSWORD);
    expect((await other.api.get('/api/v1/users/me')).status()).toBe(200); // warm the session cache

    const res = await alice.api.patch('/api/v1/users/me', { data: { password: NEW_PASSWORD } });
    expect(res.status(), await res.text()).toBe(200);

    expect((await alice.api.get('/api/v1/users/me')).status()).toBe(200);
    expect((await other.api.get('/api/v1/users/me')).status()).toBe(401);
    expect((await api.post('/api/v1/auth/login', { data: { email: alice.email, password: PASSWORD } })).status()).toBe(401);
    await users.login(alice.email, NEW_PASSWORD);
    await other.api.dispose();
  });

  test('an email another user already has is rejected with 400', async ({ users }) => {
    const alice = await users.create();
    const bob = await users.create();
    const res = await bob.api.patch('/api/v1/users/me', { data: { email: alice.email } });
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toContain('already in use');
  });

  test('an email that is not an address is rejected with 400', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.patch('/api/v1/users/me', { data: { email: `not-an-email-${tag()}` } });
    expect(res.status(), await res.text()).toBe(400);
    expect((await (await alice.api.get('/api/v1/users/me')).json()).email).toBe(alice.email);
  });

  test('an email change to an address that was never verified is rejected', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.patch('/api/v1/users/me', { data: { email: uniqueEmail('unverified') } });
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toContain('verify');
    expect((await (await alice.api.get('/api/v1/users/me')).json()).email).toBe(alice.email);
  });

  test('after an email change the user logs in with the new address only', async ({ users, api, baseURL }) => {
    const alice = await users.create();
    const email = uniqueEmail('moved');
    await verifyEmail(alice.api, email);
    const res = await alice.api.patch('/api/v1/users/me', { data: { email } });
    expect(res.status(), await res.text()).toBe(200);
    expect(await res.json()).toMatchObject({ email });
    expect((await api.post('/api/v1/auth/login', { data: { email: alice.email, password: PASSWORD } })).status()).toBe(401);
    await users.login(email, PASSWORD);
  });
});

test.describe('DELETE /users/me', () => {
  test('a deleted account loses every session, cannot log in, and its email can sign up again', async ({ users, baseURL, api }) => {
    const alice = await users.create();
    await createMarker(alice);
    const other = await loginSession(baseURL, alice.email, PASSWORD);
    expect((await other.api.get('/api/v1/users/me')).status()).toBe(200);

    expect((await alice.api.delete('/api/v1/users/me')).status()).toBe(204);

    expect((await alice.api.get('/api/v1/users/me')).status()).toBe(401);
    expect((await other.api.get('/api/v1/users/me')).status()).toBe(401);
    expect((await api.post('/api/v1/auth/login', { data: { email: alice.email, password: PASSWORD } })).status()).toBe(401);

    const again = await signupWith(baseURL, alice.email, PASSWORD);
    expect(again.status, again.body).toBe(201);
    const back = await users.login(alice.email, PASSWORD);
    expect(back.userId).not.toBe(alice.userId);
    await other.api.dispose();
  });
});

test.describe('GET /users/favorites', () => {
  test('a new user has no favorites', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.get('/api/v1/users/favorites');
    expect(res.status()).toBe(200);
    expect(await res.json()).toEqual([]);
  });

  test('a favorited marker shows up in the list and leaves it when removed', async ({ users }) => {
    const alice = await users.create();
    const bob = await users.create();
    const marker = await createMarker(bob, `fav ${tag()}`);
    expect(await (await alice.api.get('/api/v1/users/favorites')).json()).toEqual([]); // cached empty list

    expect((await alice.api.post(`/api/v1/markers/${marker.markerId}/favorites`)).status()).toBeLessThan(300);
    const favs = await (await alice.api.get('/api/v1/users/favorites')).json();
    expect(favs).toHaveLength(1);
    expect(favs[0]).toMatchObject({ markerId: marker.markerId, description: marker.description });
    expect(favs[0].latitude).toBeCloseTo(marker.latitude, 5);
    expect(favs[0].longitude).toBeCloseTo(marker.longitude, 5);
    expect(await (await bob.api.get('/api/v1/users/favorites')).json()).toEqual([]);

    expect((await alice.api.delete(`/api/v1/markers/${marker.markerId}/favorites`)).status()).toBeLessThan(300);
    expect(await (await alice.api.get('/api/v1/users/favorites')).json()).toEqual([]);
  });
});

test.describe('GET /users/reports', () => {
  test('a new user has no reports either way', async ({ users }) => {
    const alice = await users.create();
    for (const path of ['/api/v1/users/reports', '/api/v1/users/reports/for-my-markers']) {
      const res = await alice.api.get(path);
      expect(res.status(), path).toBe(404); // documented "No reports found"
      expect((await res.json()).message).toBe('No reports found');
    }
  });

  test("a report shows up in the reporter's list and in the marker owner's list only", async ({ users }) => {
    const owner = await users.create();
    const reporter = await users.create();
    const marker = await createMarker(owner);
    const description = `report ${tag()}`;
    await createReport(reporter, marker, description);

    const mine = await reporter.api.get('/api/v1/users/reports');
    expect(mine.status()).toBe(200);
    const list = await mine.json();
    expect(list).toHaveLength(1);
    expect(list[0]).toMatchObject({ markerId: marker.markerId, userId: reporter.userId, description, status: 'PENDING' });
    expect(list[0].photoUrls).toHaveLength(1);

    const forMine = await owner.api.get('/api/v1/users/reports/for-my-markers');
    expect(forMine.status()).toBe(200);
    const grouped = await forMine.json();
    expect(grouped).toMatchObject({ totalReports: 1, markers: [{ markerID: marker.markerId, reports: [{ description, status: 'PENDING' }] }] });
    expect(grouped.markers[0].reports[0].photos).toHaveLength(1);

    expect((await owner.api.get('/api/v1/users/reports')).status()).toBe(404);
    expect((await reporter.api.get('/api/v1/users/reports/for-my-markers')).status()).toBe(404);
  });
});

test.describe('admin-only and public pages', () => {
  test('a normal user cannot delete S3 objects', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.delete('/api/v1/users/s3/objects', { data: { objectUrl: 'http://127.0.0.1:29090/chulbong-e2e/x.png' } });
    expect(res.status()).toBe(403);
  });

  test('the gallery page renders for administrators', async ({ users }) => {
    const admin = await users.create({ admin: true });
    const res = await admin.api.get('/api/v1/gallery');
    expect(res.status()).toBe(200);
    expect(res.headers()['content-type']).toContain('text/html');
    expect(await res.text()).toContain('Photo Gallery');
  });
});

test.describe('notifications', () => {
  const notice = (userId: string, type: string) => ({ userId, type, title: `${type}-${tag()}`, message: 'hello from e2e' });

  test('only an admin can post a notification', async ({ api, users }) => {
    const alice = await users.create();
    const body = notice(String(alice.userId), 'Like');
    expect((await postNotification(api, body)).status()).toBe(401);
    expect((await postNotification(alice.api, body)).status()).toBe(403);
  });

  test('an admin notification with an unknown type or a broken body gets 400', async ({ users }) => {
    const admin = await users.create({ admin: true });
    expect((await admin.api.post('/notification', { headers: { 'Content-Type': 'application/json' }, data: '{"userId":' })).status()).toBe(400);
    expect((await postNotification(admin.api, notice('1', 'Bogus'))).status()).toBe(400);
  });

  test('a connected user gets their personal notification and another user does not', async ({ users, baseURL }) => {
    const admin = await users.create({ admin: true });
    const alice = await users.create();
    const bob = await users.create();
    const aliceWs = await NotificationSocket.open(baseURL, { cookie: (await loginSession(baseURL, alice.email, PASSWORD)).cookie });
    const bobWs = await NotificationSocket.open(baseURL, { cookie: (await loginSession(baseURL, bob.email, PASSWORD)).cookie });
    await waitSubscribed(aliceWs, admin.api, String(alice.userId));
    await waitSubscribed(bobWs, admin.api, String(bob.userId));

    const body = notice(String(alice.userId), 'Like');
    expect((await postNotification(admin.api, body)).status()).toBe(200);
    expect(await aliceWs.waitFor((f) => f.title === body.title)).toMatchObject({ ...body, notificationId: expect.any(Number) });
    await sleep(1000);
    expect(bobWs.frames.find((f) => f.title === body.title)).toBeUndefined();
    aliceWs.close(); bobWs.close();
  });

  test('a personal notification sent while offline arrives on the next connect, once', async ({ users, baseURL }) => {
    const admin = await users.create({ admin: true });
    const alice = await users.create();
    const body = notice(String(alice.userId), 'Comment');
    expect((await postNotification(admin.api, body)).status()).toBe(200);
    const { cookie } = await loginSession(baseURL, alice.email, PASSWORD);

    const first = await NotificationSocket.open(baseURL, { cookie });
    expect(await first.waitFor((f) => f.title === body.title)).toMatchObject(body);
    await sleep(300);
    first.close();

    const second = await NotificationSocket.open(baseURL, { cookie });
    await sleep(1500);
    expect(second.frames.find((f) => f.title === body.title)).toBeUndefined();
    second.close();
  });

  test('an anonymous client gets system broadcasts', async ({ users, baseURL }) => {
    const admin = await users.create({ admin: true });
    const cid = `e2e-cid-${tag()}`;
    const sock = await NotificationSocket.open(baseURL, { requestId: cid });
    await waitSubscribed(sock, admin.api, cid, 'System'); // anonymous clients only hear broadcasts
    const body = notice('0', 'System');
    expect((await postNotification(admin.api, body)).status()).toBe(200);
    expect(await sock.waitFor((f) => f.title === body.title)).toMatchObject({ type: 'System', title: body.title });
    sock.close();
  });

  test("an anonymous client using a user id as request-id cannot read that user's notifications", async ({ users, baseURL }) => {
    const admin = await users.create({ admin: true });
    const alice = await users.create();
    const sock = await NotificationSocket.open(baseURL, { requestId: String(alice.userId) });
    await waitSubscribed(sock, admin.api, `leak-${alice.userId}-${tag()}`, 'System'); // proves the socket is live

    const body = notice(String(alice.userId), 'Like');
    expect((await postNotification(admin.api, body)).status()).toBe(200);
    await sleep(1500);
    expect(sock.frames.find((f) => f.title === body.title)).toBeUndefined();
    sock.close();
  });

  test('a socket with neither a session nor a request-id is told so and closed', async ({ baseURL }) => {
    const sock = await NotificationSocket.open(baseURL);
    expect(await sock.waitFor((f) => f.error === 'wrong user id')).toBeTruthy();
    expect(await sock.waitClosed()).toBe(true);
  });

  test('a plain GET without an upgrade gets 426', async ({ api }) => {
    expect((await api.get('/ws/notification')).status()).toBe(426);
  });
});

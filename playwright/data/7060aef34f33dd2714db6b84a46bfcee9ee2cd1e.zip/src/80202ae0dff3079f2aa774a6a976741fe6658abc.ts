import { randomInt } from 'node:crypto';
import { test, expect, uniqueEmail } from '../fixtures';

const providers = ['google', 'kakao', 'naver'];
const frontend = 'https://k-pullup.com';
const mockToken = (email: string) => Buffer.from(JSON.stringify({ sub: String(randomInt(1, 2 ** 48 - 1)), email })).toString('base64url');

for (const provider of providers) {
  test(`oauth redirect: ${provider} cannot redirect a successful login to an external host`, async ({ api, db }) => {
    const email = uniqueEmail(`redirect-${provider}`);
    const query = new URLSearchParams({ mobileToken: mockToken(email), returnUrl: '@attacker.invalid' });
    const res = await api.get(`/api/v1/auth/${provider}?${query}`, { maxRedirects: 0 });
    expect(res.headers()['location'] ?? '').not.toContain('@attacker.invalid');
    expect(res.status()).toBe(400);
    expect((await api.storageState()).cookies.some(c => c.name === 'token')).toBe(false);
    const [rows] = await db.query('SELECT COUNT(*) n FROM Users WHERE Email = ?', [email]);
    expect(Number((rows as { n: number }[])[0].n)).toBe(0);
  });

  test(`oauth redirect: ${provider} keeps internal paths and logs in normally`, async ({ api }) => {
    const email = uniqueEmail(`internal-${provider}`);
    const token = mockToken(email);
    const target = '/pullup/7610?view=photos#top';
    const query = new URLSearchParams({ mobileToken: token, returnUrl: target });
    const res = await api.get(`/api/v1/auth/${provider}?${query}`, { maxRedirects: 0 });
    expect(res.status()).toBe(303);
    expect(res.headers()['location']).toBe(frontend + target);
    const me = await api.get('/api/v1/users/me');
    expect(me.status()).toBe(200);
    expect(await me.json()).toMatchObject({ email, provider });
    const normal = await api.get(`/api/v1/auth/${provider}?${new URLSearchParams({ mobileToken: token })}`, { maxRedirects: 0 });
    expect(normal.status()).toBe(303);
    expect(normal.headers()['location']).toBe(frontend + '/mypage');
  });

  test(`oauth redirect: ${provider} rejects unsafe destinations before starting authentication`, async ({ api }) => {
    for (const target of ['@attacker.invalid', '.attacker.invalid', 'https://attacker.invalid', '//attacker.invalid', '/\\attacker.invalid', '/%5cattacker.invalid', '/%2f%2fattacker.invalid', '/%0d%0aLocation:%20https://attacker.invalid']) {
      const res = await api.get(`/api/v1/auth/${provider}?${new URLSearchParams({ returnUrl: target })}`, { maxRedirects: 0 });
      expect(res.status(), target).toBe(400);
      expect(res.headers()['location']).toBeUndefined();
    }
  });
}

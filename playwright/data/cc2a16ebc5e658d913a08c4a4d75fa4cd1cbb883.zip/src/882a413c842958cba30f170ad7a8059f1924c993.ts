import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { test, expect } from '../fixtures';

const exec = promisify(execFile);
const redis = (...args: string[]) => exec('docker', ['compose', 'exec', '-T', 'redis', 'redis-cli', ...args]);

test('daily visitors use Redis counts, validate dates and require admin access', async ({ api, users }) => {
  const admin = await users.create({ admin: true });
  const member = await users.create();
  const date = '2001-01-02';
  const key = 'visitors:20010102';
  const path = `/api/v1/admin/unique-visitors/${date}`;
  expect((await api.get(path)).status()).toBe(401);
  expect((await member.api.get(path)).status()).toBe(403);

  await redis('PFADD', key, '192.0.2.1', '192.0.2.1', '192.0.2.2');
  await redis('EXPIRE', key, '60');
  try {
    const res = await admin.api.get(path);
    expect(res.status()).toBe(200);
    expect(await res.json()).toEqual({ date, unique_visitors: 2 });
    const missing = await admin.api.get('/api/v1/admin/unique-visitors/2001-01-03');
    expect(missing.status()).toBe(200);
    expect(await missing.json()).toEqual({ date: '2001-01-03', unique_visitors: 0 });
    for (const invalid of ['2026-02-30', '20261107', 'not-a-date']) {
      expect((await admin.api.get(`/api/v1/admin/unique-visitors/${invalid}`)).status()).toBe(400);
    }
  } finally {
    await redis('DEL', key);
  }
});

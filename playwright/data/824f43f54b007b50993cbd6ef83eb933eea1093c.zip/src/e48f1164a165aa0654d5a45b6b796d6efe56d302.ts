import { request, type APIRequestContext, type APIResponse } from '@playwright/test';
import { latestMail } from '../fixtures';

const MAILPIT = 'http://127.0.0.1:28025';

/** Number of mails Mailpit holds for `email`. */
export async function mailCount(email: string): Promise<number> {
  const ctx = await request.newContext({ baseURL: MAILPIT });
  try {
    const res = await ctx.get(`/api/v1/search?query=${encodeURIComponent(`to:"${email}"`)}&limit=1`);
    return (await res.json()).messages_count ?? 0;
  } finally {
    await ctx.dispose();
  }
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const sendCode = (api: APIRequestContext, email: string) => api.post('/api/v1/auth/verify-email/send', { form: { email } });
export const confirmCode = (api: APIRequestContext, email: string, token: string) =>
  api.post('/api/v1/auth/verify-email/confirm', { form: { email, token } });
export const signup = (api: APIRequestContext, email: string, password: string) =>
  api.post('/api/v1/auth/signup', { data: { email, password } });
export const login = (api: APIRequestContext, email: string, password: string) =>
  api.post('/api/v1/auth/login', { data: { email, password } });
export const requestReset = (api: APIRequestContext, email: string) =>
  api.post('/api/v1/auth/request-password-reset', { form: { email } });
export const resetPassword = (api: APIRequestContext, token: string, password: string) =>
  api.post('/api/v1/auth/reset-password', { form: { token, password } });

/** Six-digit code from the newest verification mail. */
export async function mailedCode(email: string): Promise<string> {
  const code = (await latestMail(email)).match(/\b\d{6}\b/)?.[0];
  if (!code) throw new Error(`no six-digit code in mail to ${email}`);
  return code;
}

/** Reset link and its token from the newest reset mail; waits past the earlier verification mail. */
export async function mailedResetLink(email: string, timeoutMs = 10_000): Promise<{ link: string; token: string }> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const body = (await latestMail(email)).replaceAll('&amp;', '&');
    const link = body.match(/https?:\/\/\S+?reset-password\?[^\s"'<]+/)?.[0];
    const token = link && new URL(link).searchParams.get('token');
    if (link && token) return { link, token };
    await sleep(200);
  }
  throw new Error(`no reset link in mail to ${email}`);
}

export const errorOf = async (res: APIResponse) => (await res.json()).error as string;

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { test, expect } from '../fixtures';

const exec = promisify(execFile);
const enqueue = (id: number) => exec('docker', ['compose', 'exec', '-T', 'redis', 'redis-cli',
  'XADD', 'search:marker-updates', '*', 'markerId', String(id)]);

test('web search includes places before the map loads and normalizes whitespace', async ({ api }) => {
  const res = await api.get('/api/v1/search/web', { params: { term: ' 양화진  ' } });
  expect(res.status(), await res.text()).toBe(200);
  expect(await res.json()).toMatchObject({
    markers: expect.any(Array), station: [], around: expect.any(Array), failed: false, partial: false,
    places: [{ id: 'service-1', place_name: '양화진' }, { id: 'service-2', place_name: '양화진역사공원' }],
  });
  for (const term of ['  ', '가'.repeat(81)]) {
    expect((await api.get('/api/v1/search/web', { params: { term } })).status()).toBe(400);
  }
});

for (const scenario of [
  { term: 'Busanjin-gu', canonical: '부산진구', address: '부산광역시 부산진구 당감동 899', point: 'POINT(35.168 129.021)' },
  { term: '여수시웅천', canonical: '여수시 웅천', address: '전라남도 여수시 웅천동 1846', point: 'POINT(34.748 127.675)' },
  { term: '마곡나루역 철봉', canonical: '마곡나루역', address: '서울특별시 강서구 마곡동 743-3', point: 'POINT(37.567 126.828)' },
  { term: '재능대학교 제물포캠퍼스', canonical: '재능대', address: '인천광역시 미추홀구 도화동 193-12', point: 'POINT(37.475 126.654)' },
  { term: 'geukdong', canonical: '충북 극동대', address: '충청북도 음성군 감곡면 왕장리 450', point: 'POINT(37.127407 127.644136)' },
  { term: 'Geukdong University', canonical: '충북 극동대', address: '충청북도 음성군 감곡면 왕장리 450', point: 'POINT(37.127407 127.644136)' },
  { term: '안산화랑공원', canonical: '화랑유원지', address: '경기도 안산시 단원구 초지동 667', point: 'POINT(37.325 126.810)' },
  { term: '삼봉지구', canonical: '완주 삼봉지구', address: '전북특별자치도 완주군 삼례읍 수계리 1241-1', point: 'POINT(35.921 127.122)' },
  { term: '광교 경기대역', canonical: '광교역', address: '경기도 수원시 영통구 이의동 산 94-6', point: 'POINT(37.303 127.043)', path: 'station' },
  { term: '둔촌역', canonical: '둔촌동역', address: '서울특별시 강동구 둔촌동 555', point: 'POINT(37.526 127.136)', path: 'station' },
  { term: '양수리578', canonical: '양서문화체육공원', address: '경기도 양평군 양서면 양수로 105 양서문화체육공원', point: 'POINT(37.552 127.326)' },
  { term: '축동로83', canonical: '군산시립도서관', address: '전북특별자치도 군산시 수송동 798-1 군산시립도서관', point: 'POINT(35.966 126.711)' },
  { term: '양화진', canonical: '성산중학교', address: '서울특별시 마포구 성지1길 32-13 성산중학교', point: 'POINT(37.549 126.912)' },
  { term: '부산 연제구 신촌로2', canonical: '연산동 1478-1', address: '부산광역시 연제구 연산동 1478-1', point: 'POINT(35.183 129.079)', ambiguous: '신촌로2' },
]) {
  test(`recent zero-result search resolves: ${scenario.term}`, async ({ api, db, users }) => {
    test.setTimeout(60_000);
    const owner = await users.create();
    const [insert]: any = await db.execute(
      'INSERT INTO Markers (UserID, Location, Address) VALUES (?, ST_GeomFromText(?, 4326), ?)',
      [owner.userId, scenario.point, scenario.address]);
    const id = insert.insertId;
    const find = async (term: string) => {
      const res = await api.get(`/api/v1/search/${scenario.path ?? 'marker'}?term=${encodeURIComponent(term)}`);
      expect(res.status(), await res.text()).toBe(200);
      const body = await res.json();
      expect(Array.isArray(body.markers)).toBe(true);
      return body.markers.find((marker: any) => marker.markerId === id);
    };
    try {
      await enqueue(id);
      await expect.poll(() => find(scenario.canonical), { timeout: 20_000 }).toBeTruthy();
      expect(await find(scenario.term)).toMatchObject({ markerId: id, photoCount: 0, facilityCount: 0, facilityTotal: 0 });
      if (scenario.ambiguous) {
        const res = await api.get('/api/v1/search/marker', { params: { term: scenario.ambiguous } });
        expect(res.status(), await res.text()).toBe(200);
        expect((await res.json()).markers).toEqual([]);
      }
      // Repeated queries must retain the same response contract when cached.
      expect(await find(scenario.term)).toMatchObject({ markerId: id, photoCount: 0 });
      if (scenario.path === 'station') {
        const res = await api.get('/api/v1/search/web', { params: { term: scenario.term } });
        expect(res.status(), await res.text()).toBe(200);
        const body = await res.json();
        expect(body.station).toEqual(expect.arrayContaining([expect.objectContaining({ markerId: id })]));
        expect(body.markers.some((marker: { markerId: number }) => marker.markerId === id)).toBe(false);
      }
    } finally {
      await db.execute('DELETE FROM Markers WHERE MarkerID = ?', [id]);
      await enqueue(id);
    }
  });
}

test('a committed marker move refreshes search and summaries remain fresh', async ({ api, db, users }) => {
  test.setTimeout(60_000);
  const suffix = Date.now();
  const oldAddress = `서울특별시 강남구 이전주소검증${suffix}`;
  const address = `서울특별시 강남구 이동주소검증${suffix}`;
  const owner = await users.create();
  const [insert]: any = await db.execute(
    "INSERT INTO Markers (UserID, Location, Address) VALUES (?, ST_GeomFromText('POINT(37.5 127)', 4326), ?)", [owner.userId, oldAddress]);
  const id = insert.insertId;
  const lookup = async (term: string) => {
    const res = await api.get(`/api/v1/search/marker?term=${encodeURIComponent(term)}`);
    expect(res.status(), await res.text()).toBe(200);
    return (await res.json()).markers.find((m: any) => m.markerId === id);
  };
  try {
    await enqueue(id);
    await expect.poll(async () => (await lookup(`이전주소검증${suffix}`))?.address,
      { timeout: 20_000 }).toContain(`이전주소검증${suffix}`);
    await db.execute("UPDATE Markers SET Address = ?, Location = ST_GeomFromText('POINT(37.501 127)', 4326), UpdatedAt = NOW() WHERE MarkerID = ?", [address, id]);
    await enqueue(id);
    await expect.poll(async () => (await lookup(`이동주소검증${suffix}`))?.address,
      { timeout: 20_000 }).toContain(`이동주소검증${suffix}`);
    expect(await lookup(`이동주소검증${suffix}`)).toMatchObject({ photoCount: 0, facilityCount: 0, facilityTotal: 0 });

    // The address search is warm, but new photos/facilities must appear immediately.
    await db.execute('INSERT INTO Photos (MarkerID, PhotoURL, ThumbnailURL) VALUES (?, ?, ?)',
      [id, 'https://example.test/photo.jpg', 'https://example.test/thumb.webp']);
    await db.execute('INSERT INTO MarkerFacilities (MarkerID, FacilityID, Quantity) VALUES (?, 1, 2)', [id]);
    expect(await lookup(`이동주소검증${suffix}`)).toMatchObject({
      thumbnailUrl: 'https://example.test/thumb.webp', photoCount: 1, facilityCount: 1, facilityTotal: 2,
    });
  } finally {
    await db.execute('DELETE FROM Markers WHERE MarkerID = ?', [id]);
    await enqueue(id);
  }
});

import { test, expect, type User } from '../fixtures';
import { createMarker as create, offsetNorth, tinyPng, type CreatedMarker } from '../helpers/markers';
import type { APIRequestContext } from '@playwright/test';
import type mysql from 'mysql2/promise';

const UNKNOWN = 2_000_000_000;
type File = { name: string; mimeType: string; buffer: Buffer };
const png = (): File => ({ name: 'report.png', mimeType: 'image/png', buffer: tinyPng() });

// The address is filled asynchronously after creation; the per-marker report list needs it (see the NULL-address test).
async function createMarker(db: mysql.Pool, user: User): Promise<CreatedMarker> {
  const marker = await create(user);
  await expect.poll(async () => {
    const [rows] = await db.query('SELECT Address FROM Markers WHERE MarkerID = ?', [marker.markerId]);
    return (rows as { Address: string | null }[])[0]?.Address;
  }, { timeout: 10_000 }).not.toBeNull();
  return marker;
}

type ReportForm = { description?: string; newLatitude?: number; newLongitude?: number; photo?: File | File[] | null; latitude?: number; longitude?: number; markerId?: number | string };

function sendReport(api: APIRequestContext, marker: CreatedMarker, form: ReportForm = {}) {
  const { photo = png(), ...rest } = form;
  const fields = { markerId: marker.markerId, latitude: marker.latitude, longitude: marker.longitude, description: 'the bar moved', ...rest };
  const multipart = new FormData();
  for (const [k, v] of Object.entries(fields)) multipart.append(k, String(v));
  for (const p of photo ? [photo].flat() : []) multipart.append('photos', new Blob([p.buffer], { type: p.mimeType }), p.name);
  return api.post('/api/v1/reports', { multipart });
}

async function markerReports(api: APIRequestContext, markerId: number) {
  const res = await api.get(`/api/v1/reports/marker/${markerId}`);
  expect(res.status()).toBe(200);
  return res.json();
}

/** Files a report and returns its id from the per-marker list. */
async function fileReport(api: APIRequestContext, marker: CreatedMarker, form?: ReportForm): Promise<number> {
  const before = new Set((await markerReports(api, marker.markerId)).map((r: { reportId: number }) => r.reportId));
  const res = await sendReport(api, marker, form);
  expect(res.status(), await res.text()).toBe(200);
  const created = (await markerReports(api, marker.markerId)).filter((r: { reportId: number }) => !before.has(r.reportId));
  expect(created).toHaveLength(1);
  return created[0].reportId;
}

const reportById = async (api: APIRequestContext, markerId: number, reportId: number) =>
  (await markerReports(api, markerId)).find((r: { reportId: number }) => r.reportId === reportId);

test.describe('filing', () => {
  test('a logged-in user can report a marker and the report is listed as pending', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);

    const res = await sendReport(alice.api, marker, { description: 'two bars now' });
    expect(res.status()).toBe(200);
    const list = await markerReports(api, marker.markerId);
    expect(list).toHaveLength(1);
    expect(list[0]).toMatchObject({ markerId: marker.markerId, userId: alice.userId, description: 'two bars now', status: 'PENDING' });
    expect(list[0].photoUrls).toHaveLength(1);

    const all = await (await api.get('/api/v1/reports/all')).json();
    expect(all.markers[marker.markerId].reports.map((r: { reportId: number }) => r.reportId)).toContain(list[0].reportId);
  });

  test('an anonymous visitor can report a marker', async ({ users, db, api }) => {
    const marker = await createMarker(db, await users.create());
    const reportId = await fileReport(api, marker);
    expect(await reportById(api, marker.markerId, reportId)).toMatchObject({ status: 'PENDING' });
  });

  test('a report can move the marker by up to 30 m but not further', async ({ users, db }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const here = { lat: marker.latitude, lng: marker.longitude };

    const near = offsetNorth(here, 20);
    expect((await sendReport(alice.api, marker, { newLatitude: near.lat, newLongitude: near.lng })).status()).toBe(200);

    const far = offsetNorth(here, 100);
    const res = await sendReport(alice.api, marker, { newLatitude: far.lat, newLongitude: far.lng });
    expect(res.status()).toBe(406);
    expect((await res.json()).error).toBeTruthy();
  });

  test('a report keeps at most 5 photos, like a new marker', async ({ users, db, api }) => {
    const owner = await users.create();
    const marker = await createMarker(db, owner);
    const id = await fileReport(api, marker, { photo: Array.from({ length: 7 }, png) });
    expect((await reportById(api, marker.markerId, id)).photoUrls).toHaveLength(5);
  });

  test('one visitor can file 10 reports an hour', async ({ users, db, api }) => {
    const owner = await users.create();
    const marker = await createMarker(db, owner);
    for (let i = 0; i < 10; i++) expect((await sendReport(api, marker)).status()).toBe(200);
    expect((await sendReport(api, marker)).status()).toBe(429);
    expect(await markerReports(api, marker.markerId)).toHaveLength(10);
  });

  test('a report needs a photo', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const res = await sendReport(alice.api, marker, { photo: null });
    expect(res.status()).toBe(409); // documented status for "upload at least one photo"
    expect(await markerReports(api, marker.markerId)).toHaveLength(0);
  });

  test('a report photo that is not an image is rejected', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const res = await sendReport(alice.api, marker, { photo: { name: 'x.png', mimeType: 'image/png', buffer: Buffer.from('plain text') } });
    expect(res.status()).toBe(400);
    expect(await markerReports(api, marker.markerId)).toHaveLength(0);
  });

  test('a report with a bad word in the description is rejected', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    expect((await sendReport(alice.api, marker, { description: 'fuck' })).status()).toBe(400);
    expect(await markerReports(api, marker.markerId)).toHaveLength(0);
  });

  test('malformed reports are rejected with 4xx', async ({ users, db }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    expect((await sendReport(alice.api, marker, { latitude: 'north' as never })).status()).toBe(400);
    expect((await sendReport(alice.api, marker, { markerId: '' })).status()).toBe(400);
    expect((await sendReport(alice.api, marker, { markerId: 'abc' })).status()).toBe(400);
    expect((await sendReport(alice.api, marker, { latitude: 35.68, longitude: 139.69 })).status()).toBe(403); // Tokyo
  });

  test('reporting an unknown marker is rejected without a server error', async ({ users, db }) => {
    const alice = await users.create();
    const marker = await createMarker(db, alice);
    const res = await sendReport(alice.api, { ...marker, markerId: UNKNOWN });
    expect([404, 409]).toContain(res.status());
  });

  test('reports of a marker whose address is not resolved can be listed', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    expect((await sendReport(alice.api, marker)).status()).toBe(200);
    await db.execute('UPDATE Markers SET Address = NULL WHERE MarkerID = ?', [marker.markerId]);
    expect((await api.get(`/api/v1/reports/marker/${marker.markerId}`)).status()).toBe(200);
  });

  test('a non-numeric marker id in the list path gives 400', async ({ api }) => {
    expect((await api.get('/api/v1/reports/marker/abc')).status()).toBe(400);
  });
});

test.describe('approving', () => {
  test('the marker owner approves a report and the marker takes its changes', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const moved = offsetNorth({ lat: marker.latitude, lng: marker.longitude }, 20);
    const reportId = await fileReport(alice.api, marker, { description: 'moved 20 m north', newLatitude: moved.lat, newLongitude: moved.lng });
    const photosBefore = ((await (await api.get(`/api/v1/markers/${marker.markerId}/details`)).json()).photos ?? []).length;

    expect((await owner.api.post(`/api/v1/reports/approve/${reportId}`)).status()).toBe(200);

    expect(await reportById(api, marker.markerId, reportId)).toMatchObject({ status: 'APPROVED' });
    const details = await (await api.get(`/api/v1/markers/${marker.markerId}/details`)).json();
    expect(details.description).toBe('moved 20 m north');
    expect(details.latitude).toBeCloseTo(moved.lat, 5);
    expect(details.longitude).toBeCloseTo(moved.lng, 5);
    expect(details.photos).toHaveLength(photosBefore + 1);

    const comments = await (await api.get(`/api/v1/comments/${marker.markerId}/comments`)).json();
    expect(comments.comments[0]).toMatchObject({ userId: 1 }); // credited as the k-pullup account (UserID 1)
    expect(comments.comments[0].commentText).toContain(alice.username);

    // The credit follows a later rename instead of keeping the old name.
    const renamed = `리네임${Date.now() % 100000}`;
    expect((await alice.api.patch('/api/v1/users/me', { data: { username: renamed } })).status()).toBe(200);
    const after = await (await api.get(`/api/v1/comments/${marker.markerId}/comments`)).json();
    expect(after.comments[0].commentText).toBe(`🔉 ${renamed}님께서 정보 제공`);
  });

  test('approving an anonymous report credits it anonymously', async ({ users, db, api }) => {
    const owner = await users.create();
    const marker = await createMarker(db, owner);
    const reportId = await fileReport(api, marker);
    expect((await owner.api.post(`/api/v1/reports/approve/${reportId}`)).status()).toBe(200);
    const comments = await (await api.get(`/api/v1/comments/${marker.markerId}/comments`)).json();
    expect(comments.comments[0].commentText).toContain('익명');
  });

  test('an admin can approve a report on someone else’s marker', async ({ users, db, api }) => {
    const [owner, admin] = await Promise.all([users.create(), users.create({ admin: true })]);
    const marker = await createMarker(db, owner);
    const reportId = await fileReport(api, marker);
    expect((await admin.api.post(`/api/v1/reports/approve/${reportId}`)).status()).toBe(200);
    expect(await reportById(api, marker.markerId, reportId)).toMatchObject({ status: 'APPROVED' });
  });

  test('someone who does not own the marker cannot approve or deny its reports', async ({ users, db, api }) => {
    const [owner, alice, mallory] = await Promise.all([users.create(), users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const reportId = await fileReport(alice.api, marker, { description: 'vandalised text' });

    const approve = await mallory.api.post(`/api/v1/reports/approve/${reportId}`);
    const deny = await mallory.api.post(`/api/v1/reports/deny/${reportId}`);
    // The reporter is not the owner either.
    const self = await alice.api.post(`/api/v1/reports/approve/${reportId}`);
    expect(await reportById(api, marker.markerId, reportId)).toMatchObject({ status: 'PENDING' });
    expect((await (await api.get(`/api/v1/markers/${marker.markerId}/details`)).json()).description).not.toBe('vandalised text');
    expect([approve.status(), deny.status(), self.status()]).toEqual([403, 403, 403]);
  });

  test('a report that was already decided cannot be decided again', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const reportId = await fileReport(alice.api, marker);
    expect((await owner.api.post(`/api/v1/reports/approve/${reportId}`)).status()).toBe(200);

    const again = await owner.api.post(`/api/v1/reports/approve/${reportId}`);
    const deny = await owner.api.post(`/api/v1/reports/deny/${reportId}`);
    const comments = await (await api.get(`/api/v1/comments/${marker.markerId}/comments`)).json();
    expect(comments.totalComments).toBe(1);
    expect(await reportById(api, marker.markerId, reportId)).toMatchObject({ status: 'APPROVED' });
    expect(again.status()).toBe(409);
    expect(deny.status()).toBe(409);
  });

  test('approving or denying an unknown report gives 404', async ({ users }) => {
    const owner = await users.create();
    expect((await owner.api.post(`/api/v1/reports/approve/${UNKNOWN}`)).status()).toBe(404);
    expect((await owner.api.post(`/api/v1/reports/deny/${UNKNOWN}`)).status()).toBe(404);
  });

  test('approving and denying need a login and a numeric id', async ({ users, api }) => {
    expect((await api.post('/api/v1/reports/approve/1')).status()).toBe(401);
    expect((await api.post('/api/v1/reports/deny/1')).status()).toBe(401);
    const owner = await users.create();
    expect((await owner.api.post('/api/v1/reports/approve/abc')).status()).toBe(400);
    expect((await owner.api.post('/api/v1/reports/deny/abc')).status()).toBe(400);
  });
});

test.describe('denying', () => {
  test('the marker owner denies a report and the marker stays as it was', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const moved = offsetNorth({ lat: marker.latitude, lng: marker.longitude }, 20);
    const reportId = await fileReport(alice.api, marker, { description: 'wrong info', newLatitude: moved.lat, newLongitude: moved.lng });

    expect((await owner.api.post(`/api/v1/reports/deny/${reportId}`)).status()).toBe(200);
    expect(await reportById(api, marker.markerId, reportId)).toMatchObject({ status: 'DENIED' });
    const details = await (await api.get(`/api/v1/markers/${marker.markerId}/details`)).json();
    expect(details.description).toBe(marker.description);
    expect(details.latitude).toBeCloseTo(marker.latitude, 5);
  });
});

test.describe('deleting', () => {
  const del = (user: User, reportId: number, markerId: number) => user.api.delete(`/api/v1/reports?reportID=${reportId}&markerID=${markerId}`);

  test('the reporter can delete their report', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const reportId = await fileReport(alice.api, marker);
    expect((await del(alice, reportId, marker.markerId)).status()).toBe(200);
    expect(await reportById(api, marker.markerId, reportId)).toBeUndefined();
  });

  test('the marker owner can delete a report on their marker', async ({ users, db, api }) => {
    const [owner, alice] = await Promise.all([users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const reportId = await fileReport(alice.api, marker);
    expect((await del(owner, reportId, marker.markerId)).status()).toBe(200);
    expect(await reportById(api, marker.markerId, reportId)).toBeUndefined();
  });

  test('a stranger cannot delete a report', async ({ users, db, api }) => {
    const [owner, alice, mallory] = await Promise.all([users.create(), users.create(), users.create()]);
    const marker = await createMarker(db, owner);
    const reportId = await fileReport(alice.api, marker);
    const res = await del(mallory, reportId, marker.markerId);
    expect(await reportById(api, marker.markerId, reportId)).toBeDefined();
    expect(res.status()).toBe(403);
  });

  test('deleting a report does not touch the photos of another report', async ({ users, db, api }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const [aliceMarker, bobMarker] = await Promise.all([createMarker(db, alice), createMarker(db, bob)]);
    const victim = await fileReport(api, aliceMarker);
    const own = await fileReport(bob.api, bobMarker);

    // Bob deletes his own report but passes Alice's report id as markerID.
    expect((await del(bob, own, victim)).status()).toBe(200);
    expect((await reportById(api, aliceMarker.markerId, victim)).photoUrls).toHaveLength(1);
  });

  test('deleting an unknown report gives 404', async ({ users }) => {
    const alice = await users.create();
    expect((await del(alice, UNKNOWN, 1)).status()).toBe(404);
  });

  test('deleting needs a login and numeric ids', async ({ users, api }) => {
    expect((await api.delete('/api/v1/reports?reportID=1&markerID=1')).status()).toBe(401);
    const alice = await users.create();
    expect((await alice.api.delete('/api/v1/reports?reportID=abc&markerID=1')).status()).toBe(400);
    expect((await alice.api.delete('/api/v1/reports?reportID=1&markerID=abc')).status()).toBe(400);
  });
});

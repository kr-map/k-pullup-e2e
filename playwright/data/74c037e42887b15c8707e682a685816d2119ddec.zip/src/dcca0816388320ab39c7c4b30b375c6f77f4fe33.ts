import { test as base, expect, type User } from '../fixtures';
import { createMarker as create, tinyPng, type MarkerForm } from '../helpers/markers';
import type { APIRequestContext } from '@playwright/test';
import type mysql from 'mysql2/promise';

let pool: mysql.Pool;
const test = base.extend<{ dbHandle: void }>({ dbHandle: [async ({ db }, use) => { pool = db; await use(); }, { auto: true }] });

// The address is resolved asynchronously after creation; AddStory needs it (see the NULL-address test).
async function createMarker(user: User, opts?: MarkerForm) {
  const marker = await create(user, opts);
  await expect.poll(async () => {
    const [rows] = await pool.query('SELECT Address FROM Markers WHERE MarkerID = ?', [marker.markerId]);
    return (rows as { Address: string | null }[])[0]?.Address;
  }, { timeout: 10_000 }).not.toBeNull();
  return marker;
}

const UNKNOWN = 2_000_000_000;
type File = { name: string; mimeType: string; buffer: Buffer };
const png = (): File => ({ name: 'story.png', mimeType: 'image/png', buffer: tinyPng() });

const addStory = (user: User, markerId: number, caption = 'morning set', photo: File | null = png()) =>
  user.api.post(`/api/v1/markers/${markerId}/stories`, { multipart: photo ? { caption, photo } : { caption } });

async function markerStories(api: APIRequestContext, markerId: number) {
  const res = await api.get(`/api/v1/markers/${markerId}/stories`);
  expect(res.status()).toBe(200);
  return res.json();
}

async function postedStory(user: User, markerId: number, caption?: string) {
  const res = await addStory(user, markerId, caption);
  expect(res.status(), await res.text()).toBe(201);
  return res.json();
}

test.describe('posting', () => {
  test('a user can post a photo story that shows on the marker and in the global feed', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    await markerStories(api, markerId); // primes the per-marker cache
    await api.get('/api/v1/markers/stories?page=1&pageSize=100'); // primes the global cache

    const story = await postedStory(alice, markerId, 'morning set');
    expect(story).toMatchObject({ markerID: markerId, userID: alice.userId, username: alice.username, caption: 'morning set' });
    expect(story.storyID).toBeGreaterThan(0);
    expect(story.photoURL).toMatch(/^https?:\/\//);
    expect(new Date(story.expiresAt).getTime()).toBeGreaterThan(Date.now());

    const list = await markerStories(api, markerId);
    expect(list).toHaveLength(1);
    expect(list[0]).toMatchObject({ storyID: story.storyID, caption: 'morning set', username: alice.username });

    const all = await (await api.get('/api/v1/markers/stories?page=1&pageSize=100')).json();
    expect(all.map((s: { storyID: number }) => s.storyID)).toContain(story.storyID);
  });

  test('a long caption is cut to 30 characters', async ({ users }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const story = await postedStory(alice, markerId, 'x'.repeat(40));
    expect(story.caption).toBe('x'.repeat(30));
  });

  test('a long Korean caption is cut to 30 characters without breaking a character', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const caption = 'a' + '철봉'.repeat(20);
    const res = await addStory(alice, markerId, caption);
    expect(res.status()).toBe(201);
    expect((await res.json()).caption).toBe(caption.slice(0, 30));
    expect((await markerStories(api, markerId))[0].caption).toBe(caption.slice(0, 30));
  });

  test('bad words in the caption are masked', async ({ users }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const story = await postedStory(alice, markerId, 'fuck this bar');
    expect(story.caption).not.toContain('fuck');
    expect(story.caption).toContain('this bar');
  });

  test('a story needs a photo', async ({ users }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const res = await addStory(alice, markerId, 'no photo', null);
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toBeTruthy();
  });

  test('a file that is not an image is rejected', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const res = await addStory(alice, markerId, 'text', { name: 'story.png', mimeType: 'image/png', buffer: Buffer.from('not an image at all') });
    expect(res.status()).toBe(400);
    expect(await markerStories(api, markerId)).toHaveLength(0);
  });

  test('a user can have only one live story per marker', async ({ users, api }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    await postedStory(alice, markerId);
    await postedStory(bob, markerId); // another user still can

    const second = await addStory(alice, markerId, 'again');
    expect(await markerStories(api, markerId)).toHaveLength(2);
    expect(second.status()).toBe(409);
  });

  test('a story can be posted on a marker whose address is not resolved yet', async ({ users, db }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    await db.execute('UPDATE Markers SET Address = NULL WHERE MarkerID = ?', [markerId]);
    expect((await addStory(alice, markerId)).status()).toBe(201);
  });

  test('posting a story to an unknown marker gives 404', async ({ users }) => {
    const alice = await users.create();
    expect((await addStory(alice, UNKNOWN)).status()).toBe(404);
  });

  test('posting needs a login and a numeric marker id', async ({ users, api }) => {
    const { markerId } = await createMarker(await users.create());
    expect((await api.post(`/api/v1/markers/${markerId}/stories`, { multipart: { caption: 'x', photo: png() } })).status()).toBe(401);
    const alice = await users.create();
    expect((await alice.api.post('/api/v1/markers/abc/stories', { multipart: { caption: 'x', photo: png() } })).status()).toBe(400);
  });
});

test.describe('listing', () => {
  test('stories of a marker without stories is an empty list', async ({ users, api }) => {
    const { markerId } = await createMarker(await users.create());
    expect(await markerStories(api, markerId)).toEqual([]);
  });

  test('bad ids and pagination give 400', async ({ api }) => {
    expect((await api.get('/api/v1/markers/abc/stories')).status()).toBe(400);
    expect((await api.get('/api/v1/markers/1/stories?page=0')).status()).toBe(400);
    expect((await api.get('/api/v1/markers/stories?pageSize=-1')).status()).toBe(400);
  });
});

test.describe('deleting', () => {
  test('the author can delete their story and it disappears everywhere', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const story = await postedStory(alice, markerId);
    await markerStories(api, markerId); // cache it
    await api.get('/api/v1/markers/stories?page=1&pageSize=100');

    const res = await alice.api.delete(`/api/v1/markers/${markerId}/stories/${story.storyID}`);
    expect(res.status()).toBe(200);
    expect(await markerStories(api, markerId)).toEqual([]);
    const all = await (await api.get('/api/v1/markers/stories?page=1&pageSize=100')).json();
    expect(all.map((s: { storyID: number }) => s.storyID)).not.toContain(story.storyID);
    // A deleted story frees the one-per-marker slot.
    expect((await addStory(alice, markerId)).status()).toBe(201);
  });

  test('another user cannot delete the story', async ({ users, api }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    const story = await postedStory(alice, markerId);
    const res = await bob.api.delete(`/api/v1/markers/${markerId}/stories/${story.storyID}`);
    expect(await markerStories(api, markerId)).toHaveLength(1);
    expect(res.status()).toBe(403);
  });

  test('an admin can delete anyone’s story', async ({ users, api }) => {
    const [alice, admin] = await Promise.all([users.create(), users.create({ admin: true })]);
    const { markerId } = await createMarker(alice);
    const story = await postedStory(alice, markerId);
    expect((await admin.api.delete(`/api/v1/markers/${markerId}/stories/${story.storyID}`)).status()).toBe(200);
    expect(await markerStories(api, markerId)).toEqual([]);
  });

  test('deleting an unknown story, or through the wrong marker, gives 404', async ({ users, api }) => {
    const alice = await users.create();
    const [{ markerId }, other] = await Promise.all([createMarker(alice), createMarker(alice)]);
    const story = await postedStory(alice, markerId);
    expect((await alice.api.delete(`/api/v1/markers/${other.markerId}/stories/${story.storyID}`)).status()).toBe(404);
    expect(await markerStories(api, markerId)).toHaveLength(1);
    expect((await alice.api.delete(`/api/v1/markers/${markerId}/stories/${UNKNOWN}`)).status()).toBe(404);
  });

  test('deleting needs a login and numeric ids', async ({ users, api }) => {
    expect((await api.delete('/api/v1/markers/1/stories/1')).status()).toBe(401);
    const alice = await users.create();
    expect((await alice.api.delete('/api/v1/markers/abc/stories/1')).status()).toBe(400);
    expect((await alice.api.delete('/api/v1/markers/1/stories/abc')).status()).toBe(400);
  });
});

test.describe('story reactions', () => {
  test('thumbs up and down are counted and the liker sees their like', async ({ users, api }) => {
    const [alice, bob, carol] = await Promise.all([users.create(), users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    const { storyID } = await postedStory(alice, markerId);
    await markerStories(api, markerId); // cache it

    expect((await bob.api.post(`/api/v1/markers/stories/${storyID}/reactions`, { data: { reactionType: 'thumbsup' } })).status()).toBe(200);
    expect((await carol.api.post(`/api/v1/markers/stories/${storyID}/reactions`, { data: { reactionType: 'thumbsdown' } })).status()).toBe(200);

    expect((await markerStories(bob.api, markerId))[0]).toMatchObject({ storyID, thumbsUp: 1, thumbsDown: 1, userLiked: true });
    expect((await markerStories(carol.api, markerId))[0]).toMatchObject({ userLiked: false });
    expect((await markerStories(api, markerId))[0]).toMatchObject({ userLiked: false });

    // Switching replaces the earlier reaction.
    await bob.api.post(`/api/v1/markers/stories/${storyID}/reactions`, { data: { reactionType: 'thumbsdown' } });
    const switched = (await markerStories(bob.api, markerId))[0];
    expect(switched.thumbsUp ?? 0).toBe(0);
    expect(switched).toMatchObject({ thumbsDown: 2, userLiked: false });

    expect((await bob.api.delete(`/api/v1/markers/stories/${storyID}/reactions`)).status()).toBe(200);
    expect((await markerStories(api, markerId))[0]).toMatchObject({ thumbsDown: 1 });
  });

  test('an unknown reaction type is rejected', async ({ users }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const { storyID } = await postedStory(alice, markerId);
    const res = await alice.api.post(`/api/v1/markers/stories/${storyID}/reactions`, { data: { reactionType: 'love' } });
    expect(res.status()).toBe(400);
  });

  test('reacting to an unknown story gives 404', async ({ users }) => {
    const alice = await users.create();
    expect((await alice.api.post(`/api/v1/markers/stories/${UNKNOWN}/reactions`, { data: { reactionType: 'thumbsup' } })).status()).toBe(404);
  });

  test('story reactions need a login and a numeric id', async ({ users, api }) => {
    expect((await api.post('/api/v1/markers/stories/1/reactions', { data: { reactionType: 'thumbsup' } })).status()).toBe(401);
    expect((await api.delete('/api/v1/markers/stories/1/reactions')).status()).toBe(401);
    const alice = await users.create();
    expect((await alice.api.post('/api/v1/markers/stories/abc/reactions', { data: { reactionType: 'thumbsup' } })).status()).toBe(400);
  });
});

test.describe('story reports', () => {
  test('a user can report a story once', async ({ users, db }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    const { storyID } = await postedStory(alice, markerId);

    expect((await bob.api.post(`/api/v1/markers/stories/${storyID}/report`, { data: { reason: 'spam' } })).status()).toBe(200);
    const [rows] = await db.query('SELECT Reason FROM StoryReports WHERE StoryID = ? AND UserID = ?', [storyID, bob.userId]);
    expect(rows).toEqual([{ Reason: 'spam' }]);
  });

  test('reporting the same story twice is a conflict', async ({ users }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    const { storyID } = await postedStory(alice, markerId);
    await bob.api.post(`/api/v1/markers/stories/${storyID}/report`, { data: { reason: 'spam' } });
    expect((await bob.api.post(`/api/v1/markers/stories/${storyID}/report`, { data: { reason: 'spam' } })).status()).toBe(409);
  });

  test('reporting an unknown story gives 404', async ({ users }) => {
    const alice = await users.create();
    expect((await alice.api.post(`/api/v1/markers/stories/${UNKNOWN}/report`, { data: { reason: 'spam' } })).status()).toBe(404);
  });

  test('a reason over 255 characters is rejected', async ({ users }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    const { storyID } = await postedStory(alice, markerId);
    expect((await bob.api.post(`/api/v1/markers/stories/${storyID}/report`, { data: { reason: 'x'.repeat(256) } })).status()).toBe(400);
  });

  test('reporting needs a login and a numeric id', async ({ users, api }) => {
    expect((await api.post('/api/v1/markers/stories/1/report', { data: { reason: 'spam' } })).status()).toBe(401);
    const alice = await users.create();
    expect((await alice.api.post('/api/v1/markers/stories/abc/report', { data: { reason: 'spam' } })).status()).toBe(400);
  });
});

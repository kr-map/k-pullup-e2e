import { test, expect, newContext, randomIP, uniqueEmail, PASSWORD } from '../fixtures';
import { requestReset, mailedResetLink, resetPassword, login, sendCode, confirmCode, mailedCode, signup } from '../helpers/auth';

test('email proof: another client cannot borrow a confirmed address to sign up', async ({ api, baseURL }) => {
  const email = uniqueEmail('proof-signup');
  expect((await sendCode(api, email)).status()).toBe(200);
  expect((await confirmCode(api, email, await mailedCode(email))).status()).toBe(200);
  const attacker = await newContext(baseURL, randomIP());
  try {
    expect((await signup(attacker, email, 'Attack3r-password')).status()).toBe(400);
    expect((await signup(api, email, PASSWORD)).status()).toBe(201);
  } finally { await attacker.dispose(); }
});

test('email proof: another account cannot borrow a confirmed address for an email change', async ({ api, users }) => {
  const attacker = await users.create();
  const email = uniqueEmail('proof-change');
  expect((await sendCode(api, email)).status()).toBe(200);
  expect((await confirmCode(api, email, await mailedCode(email))).status()).toBe(200);
  expect((await attacker.api.patch('/api/v1/users/me', { data: { email } })).status()).toBe(400);
  expect((await (await attacker.api.get('/api/v1/users/me')).json()).email).toBe(attacker.email);
  expect((await signup(api, email, PASSWORD)).status()).toBe(201);
});

test('email proof: a replacement code invalidates the earlier client proof', async ({ api, baseURL, db }) => {
  const email = uniqueEmail('proof-replaced');
  expect((await sendCode(api, email)).status()).toBe(200);
  const oldCode = await mailedCode(email);
  expect((await confirmCode(api, email, oldCode)).status()).toBe(200);
  const replacement = oldCode === '123456' ? '654321' : '123456';
  // Deterministically model a resend without relying on a random new code or mail ordering.
  await db.execute('UPDATE PasswordTokens SET Token = ?, Verified = FALSE WHERE Email = ?', [replacement, email]);
  const owner = await newContext(baseURL, randomIP());
  try {
    expect((await confirmCode(owner, email, replacement)).status()).toBe(200);
    expect((await signup(api, email, PASSWORD)).status()).toBe(400);
    expect((await signup(owner, email, PASSWORD)).status()).toBe(201);
  } finally { await owner.dispose(); }
});

test('email proof: forged cookies, another address and server-side expiry are rejected', async ({ api, db }) => {
  const email = uniqueEmail('proof-boundaries');
  expect((await sendCode(api, email)).status()).toBe(200);
  const code = await mailedCode(email);
  const confirmed = await confirmCode(api, email, code);
  expect(confirmed.status()).toBe(200);
  const cookie = confirmed.headersArray().find(h => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('email_verification='));
  expect(cookie?.value).toMatch(/HttpOnly/i);
  expect(cookie?.value).toContain('path=/api/v1');
  for (const forged of ['invalid', `${code}:${email}`]) {
    expect((await api.post('/api/v1/auth/signup', {
      data: { email, password: PASSWORD }, headers: { Cookie: `email_verification=${forged}` },
    })).status()).toBe(400);
  }
  const other = uniqueEmail('proof-other');
  await db.execute('INSERT INTO PasswordTokens (Token, Email, Verified, ExpiresAt, CreatedAt) VALUES (?, ?, TRUE, NOW() + INTERVAL 5 MINUTE, NOW())', [code, other]);
  expect((await signup(api, other, PASSWORD)).status()).toBe(400);
  await db.execute('UPDATE PasswordTokens SET ExpiresAt = NOW() - INTERVAL 1 SECOND WHERE Email = ?', [email]);
  expect((await signup(api, email, PASSWORD)).status()).toBe(400);
});

test('email proof: an invalid profile update preserves proof and a successful update consumes it', async ({ users, db }) => {
  const alice = await users.create();
  const email = uniqueEmail('proof-rollback');
  expect((await sendCode(alice.api, email)).status()).toBe(200);
  expect((await confirmCode(alice.api, email, await mailedCode(email))).status()).toBe(200);
  expect((await alice.api.patch('/api/v1/users/me', { data: { email, password: 'short' } })).status()).toBe(400);
  expect((await alice.api.patch('/api/v1/users/me', { data: { email } })).status()).toBe(200);
  const [rows] = await db.query('SELECT COUNT(*) n FROM PasswordTokens WHERE Email = ?', [email]);
  expect(Number((rows as { n: number }[])[0].n)).toBe(0);
});

test('security: a recycled OAuth email cannot take over the previous identity', async ({ api, db }) => {
  const email = uniqueEmail('oauth-identity');
  const sub = `owner-${email}`;
  const token = async (subject: string, address: string) =>
    (await api.get(`http://127.0.0.1:18090/__apple/token?${new URLSearchParams({ sub: subject, email: address })}`)).text();
  const signIn = async (subject: string, address: string) => api.post('/api/v1/auth/apple', {
    data: { identityToken: await token(subject, address) },
  });
  const original = await signIn(sub, email);
  expect(original.status()).toBe(200);
  const ownerId = (await original.json()).user.userId;
  const attack = await signIn(`different-${email}`, email);
  expect(attack.status()).toBe(401);
  expect((await signIn(sub.toUpperCase(), email)).status()).toBe(401);
  const [rows] = await db.query('SELECT ProviderID FROM Users WHERE UserID = ?', [ownerId]);
  expect((rows as { ProviderID: string }[])[0].ProviderID).toBe(sub);
});

test('security: OAuth identity stays the same after its provider changes the email', async ({ api }) => {
  const sub = `stable-${uniqueEmail('subject')}`;
  const signIn = async (email: string) => {
    const token = await (await api.get(`http://127.0.0.1:18090/__apple/token?${new URLSearchParams({ sub, email })}`)).text();
    return api.post('/api/v1/auth/apple', { data: { identityToken: token } });
  };
  const first = await signIn(uniqueEmail('before'));
  expect(first.status()).toBe(200);
  const second = await signIn(uniqueEmail('after'));
  expect(second.status()).toBe(200);
  expect((await second.json()).user.userId).toBe((await first.json()).user.userId);
});

test('security: concurrent requests can consume a password reset token only once', async ({ api, users, db }) => {
  const alice = await users.create();
  expect((await requestReset(api, alice.email)).status()).toBe(200);
  const { token } = await mailedResetLink(alice.email);
  const blocker = await db.getConnection();
  const passwords = ['First-r3set-password', 'Second-r3set-password'];
  let attempts: Promise<Awaited<ReturnType<typeof resetPassword>>[]> | undefined;
  try {
    await blocker.beginTransaction();
    await blocker.execute('SELECT UserID FROM Users WHERE UserID = ? FOR UPDATE', [alice.userId]);
    attempts = Promise.all(passwords.map(password => resetPassword(api, token, password)));
    // Both requests must reach a DB lock before it is released. With the fix,
    // one waits on Users and the other waits on the reset-token row instead.
    await expect.poll(async () => {
      const [rows] = await db.query(
        "SELECT COUNT(DISTINCT trx_id) n FROM information_schema.innodb_trx WHERE trx_state = 'LOCK WAIT' AND trx_query LIKE '%Users SET PasswordHash%' " +
        "OR trx_state = 'LOCK WAIT' AND trx_query LIKE '%PasswordResetTokens%FOR UPDATE%'",
      );
      return Number((rows as { n: number }[])[0].n);
    }, { timeout: 10_000 }).toBeGreaterThanOrEqual(2);
  } finally {
    await blocker.rollback();
    blocker.release();
  }
  const results = await attempts!;
  expect(results.map(r => r.status()).sort()).toEqual([200, 400]);
  const winner = passwords[results.findIndex(r => r.status() === 200)];
  expect((await login(api, alice.email, winner)).status()).toBe(200);
  expect((await login(api, alice.email, PASSWORD)).status()).toBe(401);
});

test('security: bucket gallery is restricted to administrators', async ({ api, users }) => {
  expect((await api.get('/api/v1/gallery')).status()).toBe(401);
  const ordinary = await users.create();
  expect((await ordinary.api.get('/api/v1/gallery')).status()).toBe(403);
  const admin = await users.create({ admin: true });
  expect((await admin.api.get('/api/v1/gallery')).status()).toBe(200);
});

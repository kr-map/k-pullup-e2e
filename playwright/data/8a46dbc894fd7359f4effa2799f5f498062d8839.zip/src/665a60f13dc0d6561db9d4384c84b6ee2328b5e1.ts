import WebSocket from 'ws';
import { randomUUID } from 'node:crypto';
import { test, expect, randomIP } from '../fixtures';

const ORIGIN = 'https://www.k-pullup.com';
const JOINED = ' 님이 입장하셨습니다.';
const LEFT = ' 님이 퇴장하셨습니다.';
const STRIKE = '씨발'; // in resource/chat_strike_words.txt
const MASKED_ONLY = '시발'; // in badwords.txt, deliberately not a strike word

type Msg = { uid?: string; message?: string; userId?: string; userNickname?: string; roomID?: string; timestamp?: number; error?: string };

const room = () => `e2e-${randomUUID()}`;
const cid = () => randomUUID();
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

class Client {
  readonly messages: Msg[] = [];
  closed: { code: number } | null = null;
  constructor(readonly ws: WebSocket) {
    ws.on('message', (data) => this.messages.push(JSON.parse(data.toString())));
    ws.on('close', (code) => (this.closed = { code }));
  }

  /** Waits for a message matching `pred` that arrived after index `from`. */
  async waitFor(pred: (m: Msg) => boolean, { timeout = 5_000, from = 0 } = {}): Promise<Msg> {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const hit = this.messages.slice(from).find(pred);
      if (hit) return hit;
      await sleep(25);
    }
    throw new Error(`no matching message within ${timeout}ms; got ${JSON.stringify(this.messages)}`);
  }

  async waitClosed(timeout = 5_000) {
    const deadline = Date.now() + timeout;
    while (!this.closed && Date.now() < deadline) await sleep(25);
    return this.closed;
  }

  has(pred: (m: Msg) => boolean) {
    return this.messages.some(pred);
  }

  send(text: string) {
    this.ws.send(text);
  }

  close() {
    this.ws.close();
  }
}

/** Connects like the frontend: `/ws/<room>?request-id=<cid>` from an allowed origin. */
function connect(baseURL: string, markerId: string, opts: { cid?: string; ip?: string; origin?: string } = {}) {
  const url = `${baseURL.replace(/^http/, 'ws')}/ws/${markerId}?request-id=${encodeURIComponent(opts.cid ?? cid())}`;
  return new WebSocket(url, { headers: { Origin: opts.origin ?? ORIGIN, 'Fly-Client-IP': opts.ip ?? randomIP() } });
}

const clients: Client[] = [];

/** Opens a chat connection and waits for its own join announcement. */
async function join(baseURL: string, markerId: string, opts: { cid?: string; ip?: string } = {}) {
  const ws = connect(baseURL, markerId, opts);
  const c = new Client(ws);
  clients.push(c);
  await new Promise<void>((resolve, reject) => {
    ws.once('open', () => resolve());
    ws.once('error', reject);
    ws.once('unexpected-response', (_req, res) => reject(new Error(`upgrade refused: ${res.statusCode}`)));
  });
  return c;
}

const joinedMsg = (c: Client) => c.waitFor((m) => !!m.message?.endsWith(JOINED));
const chat = (text: string) => (m: Msg) => m.message === text;

test.afterEach(() => {
  for (const c of clients.splice(0)) c.ws.terminate();
});

test('joining a room announces the client under a nickname derived from its cid', async ({ baseURL }) => {
  const id = cid();
  const r = room();
  const a = await join(baseURL!, r, { cid: id });
  const joined = await joinedMsg(a);
  expect(joined).toMatchObject({ roomID: r, userId: id });
  expect(joined.userNickname).toMatch(/^\S+ \S+ \[[0-9a-f]{8}\]$/);
  expect(joined.message).toBe(`${joined.userNickname}${JOINED}`);
  await a.waitFor((m) => m.userNickname === 'chulbong-kr' && m.message === `${r} (1명 접속 중)`);
});

test('the same cid keeps its nickname across reconnects and rooms, another cid gets a different one', async ({ baseURL }) => {
  const id = cid();
  const first = (await joinedMsg(await join(baseURL!, room(), { cid: id }))).userNickname;
  const again = (await joinedMsg(await join(baseURL!, room(), { cid: id }))).userNickname;
  const other = (await joinedMsg(await join(baseURL!, room(), { cid: cid() }))).userNickname;
  expect(again).toBe(first);
  expect(other).not.toBe(first);
});

test('a message is broadcast to everyone in the room with the sender nickname', async ({ baseURL }) => {
  const r = room();
  const aliceId = cid();
  const alice = await join(baseURL!, r, { cid: aliceId });
  const aliceNick = (await joinedMsg(alice)).userNickname;
  const bob = await join(baseURL!, r);
  await alice.waitFor((m) => m.message === `${r} (2명 접속 중)`);

  const text = `hello ${randomUUID()}`;
  alice.send(text);
  const got = await bob.waitFor(chat(text));
  expect(got).toMatchObject({ message: text, userNickname: aliceNick, userId: aliceId, roomID: r });
  expect(got.uid).toBeTruthy();
  expect(got.timestamp).toBeGreaterThan(Date.now() - 60_000);
  await alice.waitFor(chat(text)); // the sender sees its own message too
});

test('a message does not reach other rooms', async ({ baseURL }) => {
  const r = room();
  const alice = await join(baseURL!, r);
  const elsewhere = await join(baseURL!, room());
  const neighbour = await join(baseURL!, r);
  await joinedMsg(elsewhere);

  const text = `only here ${randomUUID()}`;
  alice.send(text);
  await neighbour.waitFor(chat(text));
  await sleep(300);
  expect(elsewhere.has(chat(text))).toBe(false);
  expect(elsewhere.has((m) => m.roomID === r)).toBe(false);
});

test('others see a leave announcement when a client disconnects', async ({ baseURL }) => {
  const r = room();
  const alice = await join(baseURL!, r);
  const aliceNick = (await joinedMsg(alice)).userNickname;
  const bob = await join(baseURL!, r);
  await joinedMsg(bob);
  alice.close();
  await bob.waitFor((m) => m.message === `${aliceNick}${LEFT}`);
  await bob.waitFor((m) => m.message === `${r} (1명 접속 중)`);
});

test('a client joining later receives the room recent messages', async ({ baseURL }) => {
  const r = room();
  const alice = await join(baseURL!, r);
  const texts = [`first ${randomUUID()}`, `second ${randomUUID()}`];
  for (const t of texts) {
    alice.send(t);
    await alice.waitFor(chat(t));
  }
  alice.close();

  const late = await join(baseURL!, r);
  await joinedMsg(late);
  const history = late.messages.filter((m) => texts.includes(m.message!)).map((m) => m.message);
  expect(history).toEqual(texts);
});

test('a 500-character message is delivered, a 501-character one is rejected and not broadcast', async ({ baseURL }) => {
  const r = room();
  const alice = await join(baseURL!, r);
  const bob = await join(baseURL!, r);
  await joinedMsg(bob);

  const ok = '가'.repeat(499) + 'a'; // 500 runes, ~1.5 KiB: well under the frame cap
  const tooLong = '가'.repeat(501);
  const from = alice.messages.length;
  alice.send(tooLong);
  await alice.waitFor((m) => m.error === 'Message is too long (max 500 characters).', { from });
  alice.send(ok);
  await bob.waitFor(chat(ok));
  expect(bob.has(chat(tooLong))).toBe(false);
  expect(alice.closed).toBeNull();
});

test('a frame over 4 KiB closes the sender connection and is not broadcast', async ({ baseURL }) => {
  const r = room();
  const alice = await join(baseURL!, r);
  const bob = await join(baseURL!, r);
  await joinedMsg(bob);

  const huge = 'x'.repeat(5 * 1024);
  alice.send(huge);
  expect(await alice.waitClosed()).toMatchObject({ code: 1009 }); // RFC 6455: message too big
  await sleep(300);
  expect(bob.has(chat(huge))).toBe(false);
  expect(bob.closed).toBeNull();
});

test('bad words are masked in the broadcast message', async ({ baseURL }) => {
  const r = room();
  const alice = await join(baseURL!, r);
  const bob = await join(baseURL!, r);
  await joinedMsg(bob);

  const tag = randomUUID();
  alice.send(`${tag} ${MASKED_ONLY} 철봉`);
  const got = await bob.waitFor((m) => !!m.message?.startsWith(tag));
  expect(got.message).toBe(`${tag} ** 철봉`);
});

test('three strike words mute the sender IP for every room and cid while it still receives', async ({ baseURL }) => {
  const r = room();
  const ip = randomIP();
  const swearer = await join(baseURL!, r, { ip });
  const bystander = await join(baseURL!, r); // another IP in the same room
  await joinedMsg(bystander);

  for (let i = 0; i < 3; i++) {
    swearer.send(`${STRIKE} ${i}`);
    await sleep(250); // stay under the per-connection rate limit
  }
  await swearer.waitFor((m) => m.userId === 'system' && m.message === '비속어를 반복해서 사용하여 5분 동안 채팅을 보낼 수 없습니다. 대화는 계속 볼 수 있습니다.');

  const blocked = `after mute ${randomUUID()}`;
  swearer.send(blocked);
  const notice = await swearer.waitFor((m) => m.userId === 'system' && !!m.message?.startsWith('비속어 반복 사용으로 채팅이 제한되었습니다.'));
  expect(notice.message).toMatch(/(\d+)초 후에 다시 보낼 수 있습니다\.$/);
  expect(Number(notice.message!.match(/(\d+)초/)![1])).toBeLessThanOrEqual(300);

  // Unaffected IP keeps talking, and the muted client still reads it.
  const fine = `still here ${randomUUID()}`;
  bystander.send(fine);
  await swearer.waitFor(chat(fine));
  await bystander.waitFor(chat(fine));

  // A fresh cid in another room from the same IP is still muted.
  const otherRoom = room();
  const sameIpNewCid = await join(baseURL!, otherRoom, { ip });
  const watcher = await join(baseURL!, otherRoom);
  await joinedMsg(watcher);
  const evade = `evade ${randomUUID()}`;
  sameIpNewCid.send(evade);
  await sameIpNewCid.waitFor((m) => m.userId === 'system' && !!m.message?.startsWith('비속어 반복 사용으로 채팅이 제한되었습니다.'));

  await sleep(300);
  expect(bystander.has(chat(blocked))).toBe(false);
  expect(watcher.has(chat(evade))).toBe(false);
  expect(swearer.closed).toBeNull();
});

test('a system notice reaches only the muted sender, not the room', async ({ baseURL }) => {
  const r = room();
  const ip = randomIP();
  const swearer = await join(baseURL!, r, { ip });
  const bystander = await join(baseURL!, r);
  await joinedMsg(bystander);
  for (let i = 0; i < 4; i++) {
    swearer.send(`${STRIKE} ${i}`);
    await sleep(250);
  }
  await swearer.waitFor((m) => !!m.message?.startsWith('비속어 반복 사용으로 채팅이 제한되었습니다.'));
  await sleep(300);
  expect(bystander.has((m) => m.userId === 'system')).toBe(false);
});

test('sending faster than the rate limit gets a slow-down error and keeps the connection', async ({ baseURL }) => {
  const r = room();
  const alice = await join(baseURL!, r);
  await joinedMsg(alice);
  for (let i = 0; i < 15; i++) alice.send(`burst ${i}`);
  await alice.waitFor((m) => m.error === 'Rate limit exceeded. Please slow down.');

  await sleep(1_200); // the bucket refills at 5 per second
  const after = `after burst ${randomUUID()}`;
  alice.send(after);
  await alice.waitFor(chat(after));
  expect(alice.closed).toBeNull();
});

test('a crowded room flooding past the rate limit does not crash the server', async ({ baseURL, api }) => {
  // Rate-limit replies used to be written beside writePump: "concurrent write to websocket connection" killed the process.
  const r = room();
  const crowd = await Promise.all(Array.from({ length: 20 }, () => join(baseURL!, r)));
  for (let i = 0; i < 60; i++) for (const c of crowd) c.send(`flood ${i}`);
  await crowd[0].waitFor((m) => m.error === 'Rate limit exceeded. Please slow down.');
  await sleep(1_000);
  expect((await api.get('/')).status()).toBe(200);
  await joinedMsg(await join(baseURL!, room()));
});

test('a second connection with the same cid in the same room is refused, the first keeps working', async ({ baseURL }) => {
  const r = room();
  const id = cid();
  const first = await join(baseURL!, r, { cid: id });
  await joinedMsg(first);

  const second = await join(baseURL!, r, { cid: id });
  await second.waitFor((m) => m.error === 'duplicate connection');
  expect(await second.waitClosed()).not.toBeNull();

  const text = `still alive ${randomUUID()}`;
  first.send(text);
  await first.waitFor(chat(text));
});

test('the same cid may be in two different rooms at once', async ({ baseURL }) => {
  const id = cid();
  const a = await join(baseURL!, room(), { cid: id });
  const b = await join(baseURL!, room(), { cid: id });
  await joinedMsg(a);
  await joinedMsg(b);
  expect(b.has((m) => !!m.error)).toBe(false);
});

test('a room id containing "&" is rejected without joining', async ({ baseURL }) => {
  const ws = connect(baseURL!, `bad&${randomUUID()}`);
  const c = new Client(ws);
  clients.push(c);
  const outcome = await new Promise<string>((resolve) => {
    ws.once('unexpected-response', (_req, res) => resolve(`http ${res.statusCode}`));
    ws.once('open', () => resolve('open'));
  });
  if (outcome === 'open') {
    await c.waitFor((m) => m.error === 'wrong marker id');
    expect(await c.waitClosed()).not.toBeNull();
    expect(c.has((m) => !!m.message?.endsWith(JOINED))).toBe(false);
  } else {
    expect(outcome).toBe('http 400');
  }
});

test('a websocket handshake from a foreign origin is refused', async ({ baseURL }) => {
  const ws = connect(baseURL!, room(), { origin: 'https://evil.example' });
  ws.on('error', () => {}); // terminate() on a refused handshake emits an error
  const status = await new Promise<number | 'open'>((resolve) => {
    ws.once('unexpected-response', (_req, res) => resolve(res.statusCode!));
    ws.once('open', () => resolve('open'));
  });
  ws.terminate();
  expect(status).toBe(403);
});

test('a plain HTTP request to the chat endpoint gets 426 Upgrade Required', async ({ api }) => {
  const res = await api.get(`/ws/${room()}?request-id=${cid()}`);
  expect(res.status()).toBe(426);
});

import { test, expect, type User } from '../fixtures';
import { createMarker } from '../helpers/markers';
import type { APIRequestContext } from '@playwright/test';

const BAD_WORD = 'fuck'; // in badwords.txt

const post = (user: User, markerId: number, commentText: string) =>
  user.api.post('/api/v1/comments', { data: { markerId, commentText } });

async function listComments(api: APIRequestContext, markerId: number) {
  const res = await api.get(`/api/v1/comments/${markerId}/comments?page=1&pageSize=10`);
  expect(res.status()).toBe(200);
  return res.json();
}

test.describe('posting', () => {
  test('a user can comment on a marker and everyone sees it', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);

    const res = await post(alice, markerId, 'nice bar');
    expect(res.status()).toBe(200);
    const comment = await res.json();
    expect(comment).toMatchObject({ markerId, userId: alice.userId, commentText: 'nice bar' });
    expect(comment.commentId).toBeGreaterThan(0);

    const list = await listComments(api, markerId);
    expect(list).toMatchObject({ totalComments: 1, currentPage: 1, totalPages: 1 });
    expect(list.comments[0]).toMatchObject({ commentId: comment.commentId, userId: alice.userId, username: alice.username, commentText: 'nice bar' });
  });

  test('the created comment carries the author username', async ({ users }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const res = await post(alice, markerId, 'hello');
    expect(res.status()).toBe(200);
    expect((await res.json()).username).toBe(alice.username);
  });

  test('anonymous users cannot comment', async ({ api, users }) => {
    const { markerId } = await createMarker(await users.create());
    const res = await api.post('/api/v1/comments', { data: { markerId, commentText: 'hi' } });
    expect(res.status()).toBe(401);
  });

  test('a comment with a bad word is rejected', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const res = await post(alice, markerId, `what the ${BAD_WORD}`);
    expect(res.status()).toBe(400);
    expect((await res.json()).error).toBeTruthy();
    expect((await listComments(api, markerId)).totalComments).toBe(0);
  });

  test('an empty comment is rejected', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const res = await post(alice, markerId, '');
    expect(res.status()).toBe(400);
    expect((await listComments(api, markerId)).totalComments).toBe(0);
  });

  test('a malformed body is rejected', async ({ users }) => {
    const alice = await users.create();
    const res = await alice.api.post('/api/v1/comments', { headers: { 'Content-Type': 'application/json' }, data: '{"markerId":' });
    expect(res.status()).toBe(400);
  });

  test('commenting on an unknown marker gives 404', async ({ users }) => {
    const alice = await users.create();
    const res = await post(alice, 2_000_000_000, 'ghost');
    expect(res.status()).toBe(404);
  });

  test('a user can comment at most 3 times on one marker', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    for (let i = 1; i <= 3; i++) expect((await post(alice, markerId, `comment ${i}`)).status()).toBe(200);

    const fourth = await post(alice, markerId, 'comment 4');
    expect(fourth.status()).toBe(400);
    expect((await fourth.json()).error).toBeTruthy();
    expect((await listComments(api, markerId)).totalComments).toBe(3);

    // The limit is per user: someone else can still comment.
    const bob = await users.create();
    expect((await post(bob, markerId, 'mine')).status()).toBe(200);
  });

  test('a deleted comment frees a slot in the per-marker limit', async ({ users }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const ids: number[] = [];
    for (let i = 1; i <= 3; i++) ids.push((await (await post(alice, markerId, `c${i}`)).json()).commentId);
    expect((await alice.api.delete(`/api/v1/comments/${ids[0]}`)).status()).toBe(200);
    expect((await post(alice, markerId, 'again')).status()).toBe(200);
  });
});

test.describe('listing', () => {
  test('comments are paginated newest first', async ({ users, api }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    for (const text of ['first', 'second', 'third']) {
      expect((await post(alice, markerId, text)).status()).toBe(200);
      await new Promise((r) => setTimeout(r, 1100)); // PostedAt has second precision
    }
    expect((await post(bob, markerId, 'fourth')).status()).toBe(200);

    const page1 = await (await api.get(`/api/v1/comments/${markerId}/comments?page=1&pageSize=3`)).json();
    expect(page1).toMatchObject({ totalComments: 4, totalPages: 2, currentPage: 1 });
    expect(page1.comments.map((c: { commentText: string }) => c.commentText)).toEqual(['fourth', 'third', 'second']);
    const page2 = await (await api.get(`/api/v1/comments/${markerId}/comments?page=2&pageSize=3`)).json();
    expect(page2.comments.map((c: { commentText: string }) => c.commentText)).toEqual(['first']);
  });

  test('a marker without comments lists none', async ({ users, api }) => {
    const { markerId } = await createMarker(await users.create());
    expect(await listComments(api, markerId)).toMatchObject({ comments: [], totalComments: 0, totalPages: 0 });
  });

  test('a non-numeric marker id or bad pagination gives 400', async ({ api }) => {
    expect((await api.get('/api/v1/comments/abc/comments')).status()).toBe(400);
    expect((await api.get('/api/v1/comments/1/comments?page=0')).status()).toBe(400);
    expect((await api.get('/api/v1/comments/1/comments?pageSize=-1')).status()).toBe(400);
  });
});

test.describe('editing', () => {
  test('the author can edit their comment', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const { commentId } = await (await post(alice, markerId, 'before')).json();

    const res = await alice.api.patch(`/api/v1/comments/${commentId}`, { data: { commentText: 'after' } });
    expect(res.status()).toBe(200);
    expect((await listComments(api, markerId)).comments[0]).toMatchObject({ commentId, commentText: 'after' });
  });

  test('another user cannot edit the comment', async ({ users, api }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    const { commentId } = await (await post(alice, markerId, 'original')).json();

    const res = await bob.api.patch(`/api/v1/comments/${commentId}`, { data: { commentText: 'hijacked' } });
    expect([403, 404]).toContain(res.status());
    expect((await listComments(api, markerId)).comments[0].commentText).toBe('original');
  });

  test('editing in a bad word is rejected', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const { commentId } = await (await post(alice, markerId, 'clean')).json();
    const res = await alice.api.patch(`/api/v1/comments/${commentId}`, { data: { commentText: BAD_WORD } });
    expect(res.status()).toBe(400);
    expect((await listComments(api, markerId)).comments[0].commentText).toBe('clean');
  });

  test('editing needs a login, a numeric id and an existing comment', async ({ users, api }) => {
    const alice = await users.create();
    expect((await api.patch('/api/v1/comments/1', { data: { commentText: 'x' } })).status()).toBe(401);
    expect((await alice.api.patch('/api/v1/comments/abc', { data: { commentText: 'x' } })).status()).toBe(400);
    expect((await alice.api.patch('/api/v1/comments/2000000000', { data: { commentText: 'x' } })).status()).toBe(404);
  });
});

test.describe('deleting', () => {
  test('the author can delete their comment, once', async ({ users, api }) => {
    const alice = await users.create();
    const { markerId } = await createMarker(alice);
    const { commentId } = await (await post(alice, markerId, 'bye')).json();

    expect((await alice.api.delete(`/api/v1/comments/${commentId}`)).status()).toBe(200);
    expect((await listComments(api, markerId)).totalComments).toBe(0);
    expect((await alice.api.delete(`/api/v1/comments/${commentId}`)).status()).toBe(404);
  });

  test('another user cannot delete the comment', async ({ users, api }) => {
    const [alice, bob] = await Promise.all([users.create(), users.create()]);
    const { markerId } = await createMarker(alice);
    const { commentId } = await (await post(alice, markerId, 'stay')).json();

    expect([403, 404]).toContain((await bob.api.delete(`/api/v1/comments/${commentId}`)).status());
    expect((await listComments(api, markerId)).totalComments).toBe(1);
  });

  test('an admin can delete anyone’s comment', async ({ users, api }) => {
    const [alice, admin] = await Promise.all([users.create(), users.create({ admin: true })]);
    const { markerId } = await createMarker(alice);
    const { commentId } = await (await post(alice, markerId, 'moderate me')).json();

    expect((await admin.api.delete(`/api/v1/comments/${commentId}`)).status()).toBe(200);
    expect((await listComments(api, markerId)).totalComments).toBe(0);
  });

  test('deleting needs a login and a numeric id', async ({ users, api }) => {
    const alice = await users.create();
    expect((await api.delete('/api/v1/comments/1')).status()).toBe(401);
    expect((await alice.api.delete('/api/v1/comments/abc')).status()).toBe(400);
  });
});

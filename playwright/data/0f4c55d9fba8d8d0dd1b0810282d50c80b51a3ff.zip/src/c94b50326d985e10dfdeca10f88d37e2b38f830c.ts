import { expect, type User } from '../fixtures';
import { randomInt } from 'node:crypto';
import zlib from 'node:zlib';
import type { Pool } from 'mysql2/promise';

export type Point = { lat: number; lng: number };
export type CreatedMarker = { markerId: number; latitude: number; longitude: number; description: string };

// Inland South Korea: land in mock/external.mjs and inside the Asia/Seoul timezone, away from the mock's sea box.
export const randomLandPoint = (): Point => ({
  lat: Number((35.3 + randomInt(2_000_000) / 1_000_000).toFixed(6)),
  lng: Number((127.4 + randomInt(1_400_000) / 1_000_000).toFixed(6)),
});

/** Moves `p` north by about `meters`. */
export const offsetNorth = (p: Point, meters: number): Point => ({ lat: Number((p.lat + meters / 111_320).toFixed(7)), lng: p.lng });

let png: Buffer | undefined;
/** A small valid PNG (8x8, solid color). */
export function tinyPng(): Buffer {
  return (png ??= pngOfSize(8, 8));
}

/** A valid w x h PNG with a horizontal gradient. */
export function pngOfSize(w: number, h: number): Buffer {
  const crcTable = Array.from({ length: 256 }, (_, n) => { for (let k = 0; k < 8; k++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1; return n >>> 0; });
  const crc = (buf: Buffer) => { let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (type: string, data: Buffer) => {
    const len = Buffer.alloc(4), sum = Buffer.alloc(4), td = Buffer.concat([Buffer.from(type), data]);
    len.writeUInt32BE(data.length); sum.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, sum]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr.set([8, 2, 0, 0, 0], 8);
  const row = Buffer.alloc(1 + w * 3, 0x55); row[0] = 0;
  for (let x = 0; x < w; x++) row[1 + x * 3] = Math.floor((x / w) * 255);
  const raw = Buffer.concat(Array.from({ length: h }, () => row));
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

export type MarkerForm = { at?: Point; description?: string; photos?: number; photo?: Buffer };

/** Multipart body for POST /api/v1/markers, as the frontend sends it (`photos` PNG files). */
export function markerMultipart({ at = randomLandPoint(), description = 'e2e marker', photos = 0, photo }: MarkerForm = {}) {
  const multipart: Record<string, string | { name: string; mimeType: string; buffer: Buffer }> = {
    latitude: String(at.lat), longitude: String(at.lng), description,
  };
  // Playwright's multipart takes one value per key, so only a single photo can be attached this way.
  if (photos > 0) multipart.photos = { name: 'photo.png', mimeType: 'image/png', buffer: photo ?? tinyPng() };
  return multipart;
}

/** Creates a marker as `user` (random inland point unless `at`; `photos: 1` attaches a PNG) and returns the 201 body. */
export async function createMarker(user: User, opts: MarkerForm = {}): Promise<CreatedMarker> {
  const res = await user.api.post('/api/v1/markers', { multipart: markerMultipart(opts) });
  expect(res.status(), `create marker: ${await res.text()}`).toBe(201);
  return res.json();
}

/** Waits until the API's async address lookup has filled in Markers.Address for `markerId`. */
export async function waitForAddress(db: Pool, markerId: number) {
  await expect.poll(async () => ((await db.query('SELECT Address FROM Markers WHERE MarkerID = ?', [markerId])) as any)[0][0]?.Address ?? null, { timeout: 15_000 }).not.toBeNull();
}

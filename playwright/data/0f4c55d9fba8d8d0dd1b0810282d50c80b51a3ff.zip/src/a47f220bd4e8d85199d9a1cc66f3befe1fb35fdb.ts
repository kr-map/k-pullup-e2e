import { test as base, expect, request, type APIRequestContext } from '@playwright/test';
import mysql from 'mysql2/promise';
import { randomBytes, randomInt } from 'node:crypto';
import { asSetup, takeCalls, track } from './api-log';

export { expect };

const MAILPIT = 'http://127.0.0.1:28025';
export const PASSWORD = 'E2e-passw0rd!';

// Each simulated person gets its own client IP, so per-IP limits behave like production.
export const randomIP = () => `10.${randomInt(256)}.${randomInt(256)}.${randomInt(1, 255)}`;
export const uniqueEmail = (tag = 'user') => `${tag}-${Date.now()}-${randomBytes(3).toString('hex')}@e2e.k-pullup.test`;

export type User = {
  userId: number;
  email: string;
  password: string;
  username: string;
  token: string; // raw token from the login body; requests authenticate with the encrypted cookie
  ip: string;
  api: APIRequestContext; // sends this user's cookie and IP
};

/** Waits for the newest mail to `email` and returns its plain-text body. */
export async function latestMail(email: string, timeoutMs = 10_000): Promise<string> {
  const ctx = await request.newContext({ baseURL: MAILPIT });
  try {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const res = await ctx.get(`/api/v1/search?query=${encodeURIComponent(`to:"${email}"`)}&limit=1`);
      const { messages } = await res.json();
      if (messages?.length) {
        const msg = await (await ctx.get(`/api/v1/message/${messages[0].ID}`)).json();
        return msg.Text || msg.HTML;
      }
      await new Promise((r) => setTimeout(r, 200));
    }
    throw new Error(`no mail to ${email} within ${timeoutMs}ms`);
  } finally {
    await ctx.dispose();
  }
}

export const newContext = async (baseURL: string | undefined, ip: string, token?: string) =>
  track(await request.newContext({
    baseURL,
    extraHTTPHeaders: { 'Fly-Client-IP': ip, ...(token ? { Cookie: `token=${token}` } : {}) },
  }));

type Fixtures = {
  /** Attaches the test's API calls for the API report (reporters/api-report.ts). */
  apiLog: void;
  /** Anonymous client with its own IP. */
  api: APIRequestContext;
  /** Direct DB access for setup the API can't do (e.g. admin role) and for checking side effects. */
  db: mysql.Pool;
  /** Creates verified, logged-in users through the real signup flow. */
  users: { create(opts?: { admin?: boolean }): Promise<User>; login(email: string, password: string, ip?: string): Promise<User> };
};

export const test = base.extend<Fixtures, { dbPool: mysql.Pool }>({
  dbPool: [async ({}, use) => {
    const pool = mysql.createPool({ host: '127.0.0.1', port: 23306, user: 'root', password: 'e2e', database: 'chulbong', connectionLimit: 4 });
    await use(pool);
    await pool.end();
  }, { scope: 'worker' }],

  db: async ({ dbPool }, use) => use(dbPool),

  apiLog: [async ({}, use, testInfo) => {
    takeCalls();
    await use();
    const calls = takeCalls();
    if (calls.length) await testInfo.attach('api-calls', { body: JSON.stringify(calls), contentType: 'application/json' });
  }, { auto: true }],

  api: async ({ baseURL }, use) => {
    const ctx = await newContext(baseURL, randomIP());
    await use(ctx);
    await ctx.dispose();
  },

  users: async ({ baseURL, db }, use) => {
    const contexts: APIRequestContext[] = [];

    const login = async (email: string, password: string, ip = randomIP()): Promise<User> => {
      const anon = await newContext(baseURL, ip);
      contexts.push(anon);
      const res = await anon.post('/api/v1/auth/login', { data: { email, password } });
      expect(res.status(), `login ${email}: ${await res.text()}`).toBe(200);
      const body = await res.json();
      // The API encrypts cookies, so reuse the Set-Cookie value rather than the raw token.
      const cookie = res.headersArray().find((h) => h.name.toLowerCase() === 'set-cookie' && h.value.startsWith('token='));
      expect(cookie, 'login sets the token cookie').toBeTruthy();
      const api = await newContext(baseURL, ip, cookie!.value.split(';')[0].slice('token='.length));
      contexts.push(api);
      return { userId: body.user.userId, email, password, username: body.user.username, token: body.token, ip, api };
    };

    const create = ({ admin = false } = {}): Promise<User> => asSetup(async () => {
      const ip = randomIP();
      const anon = await newContext(baseURL, ip);
      contexts.push(anon);
      const email = uniqueEmail(admin ? 'admin' : 'user');

      expect((await anon.post('/api/v1/auth/verify-email/send', { form: { email } })).status()).toBe(200);
      const code = (await latestMail(email)).match(/\b\d{6}\b/)?.[0];
      expect(code, 'six-digit code in verification mail').toBeTruthy();
      expect((await anon.post('/api/v1/auth/verify-email/confirm', { form: { email, token: code! } })).status()).toBe(200);
      const signup = await anon.post('/api/v1/auth/signup', { data: { email, password: PASSWORD } });
      expect(signup.status(), await signup.text()).toBe(201);

      if (admin) await db.execute("UPDATE Users SET Role = 'admin' WHERE Email = ?", [email]);
      return login(email, PASSWORD, ip);
    });

    await use({ create, login });
    await Promise.all(contexts.map((c) => c.dispose()));
  },
});

import type { APIRequestContext, APIResponse } from '@playwright/test';

// Records every call made through a tracked APIRequestContext; the apiLog fixture attaches them per test.
export type ApiCall = {
  method: string;
  url: string;
  status?: number;
  ms: number;
  setup: boolean; // made while a fixture created or logged in a user
  request?: string;
  response?: string;
  responseType?: string;
  error?: string;
};

const MAX_BODY = 4096;
let calls: ApiCall[] = [];
let setupDepth = 0;

export const takeCalls = () => {
  const c = calls;
  calls = [];
  return c;
};

/** Marks calls made inside `fn` as setup, so the report can fold them away. */
export async function asSetup<T>(fn: () => Promise<T>): Promise<T> {
  setupDepth++;
  try {
    return await fn();
  } finally {
    setupDepth--;
  }
}

const clip = (s: string) => (s.length > MAX_BODY ? `${s.slice(0, MAX_BODY)}\n… (${s.length - MAX_BODY} more characters)` : s);

function describeRequest(opts: any): string | undefined {
  if (!opts) return undefined;
  if (opts.multipart) {
    const parts = Object.entries(opts.multipart).map(([k, v]: [string, any]) =>
      v && typeof v === 'object' && 'buffer' in v ? [k, `<file ${v.name} · ${v.mimeType} · ${v.buffer.length} bytes>`] : [k, String(v)],
    );
    return clip(JSON.stringify({ multipart: Object.fromEntries(parts) }, null, 2));
  }
  if (opts.form) return clip(JSON.stringify({ form: opts.form }, null, 2));
  if (opts.data === undefined) return undefined;
  if (typeof opts.data === 'string') return clip(opts.data);
  if (Buffer.isBuffer(opts.data)) return `<${opts.data.length} bytes>`;
  return clip(JSON.stringify(opts.data, null, 2));
}

async function describeResponse(res: APIResponse): Promise<[string, string]> {
  const type = res.headers()['content-type'] ?? '';
  const body = await res.body().catch(() => Buffer.alloc(0));
  if (!body.length) return ['', type];
  if (!/json|text|xml|html/.test(type)) return [`<${body.length} bytes${type ? ` · ${type}` : ''}>`, type];
  const text = body.toString('utf8');
  try {
    return [clip(JSON.stringify(JSON.parse(text), null, 2)), type];
  } catch {
    return [clip(text), type];
  }
}

const METHODS = ['get', 'post', 'put', 'patch', 'delete', 'head', 'fetch'] as const;

/** Wraps a context so its calls show up in the API report. */
export function track(ctx: APIRequestContext): APIRequestContext {
  return new Proxy(ctx, {
    get(target, prop, receiver) {
      const value = Reflect.get(target, prop, receiver);
      if (!METHODS.includes(prop as any)) return typeof value === 'function' ? value.bind(target) : value;
      return async (url: string, opts?: any) => {
        const method = (prop === 'fetch' ? opts?.method ?? 'GET' : String(prop)).toUpperCase();
        const call: ApiCall = { method, url: String(url), ms: 0, setup: setupDepth > 0, request: describeRequest(opts) };
        calls.push(call);
        const t0 = performance.now();
        try {
          const res: APIResponse = await value.call(target, url, opts);
          call.ms = Math.round(performance.now() - t0);
          call.status = res.status();
          call.url = new URL(res.url()).pathname + new URL(res.url()).search;
          [call.response, call.responseType] = await describeResponse(res);
          return res;
        } catch (e: any) {
          call.ms = Math.round(performance.now() - t0);
          call.error = String(e?.message ?? e).split('\n')[0];
          throw e;
        }
      };
    },
  });
}

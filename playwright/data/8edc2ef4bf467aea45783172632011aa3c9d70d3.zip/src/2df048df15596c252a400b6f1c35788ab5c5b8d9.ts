import type { ResultSetHeader } from 'mysql2/promise';
import { test, expect } from '../fixtures';
import { tinyPng } from '../helpers/markers';

const board = '/api/v1/community';
const title = '초보가 쓰기 좋은 낮은 봉이 있나요?';
const body = '입구 근처에 낮은 철봉이 있는지 궁금해요.';

test('only admins create and pin board notices while ordinary posts keep their type', async ({ api, db, users }) => {
  const [member, admin] = await Promise.all([users.create(), users.create({ admin: true })]);
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location, Address) VALUES (?, ST_GeomFromText('POINT(37.25 127.05)', 4326), ?)",
    [member.userId, '경기도 수원시 영통구 영통동 123'],
  );
  const regular = await member.api.post(board + '/posts', { data: { markerId: marker.insertId, kind: 'question', title, body, rulesAccepted: true } });
  expect(regular.status(), await regular.text()).toBe(201);
  const { id: regularId } = await regular.json();
  const pin = board + '/posts/' + regularId + '/notice';
  const data = { title: '게시판 운영 안내', body: '서로 존중하며 이용해 주세요.', rulesAccepted: true };
  expect((await api.post(board + '/notices', { data })).status()).toBe(401);
  expect((await member.api.post(board + '/notices', { data })).status()).toBe(403);
  expect((await member.api.post(board + '/posts', { data: { ...data, markerId: marker.insertId, kind: 'notice' } })).status()).toBe(400);
  expect((await member.api.put(pin, { data: { isNotice: true } })).status()).toBe(403);
  expect((await admin.api.put(pin, { data: {} })).status()).toBe(400);
  expect((await admin.api.put(pin, { data: { isNotice: true } })).status()).toBe(204);

  const created = await admin.api.post(board + '/notices', { data });
  expect(created.status(), await created.text()).toBe(201);
  const { id: noticeId } = await created.json();
  const list = async (mode: string) => {
    const r = await api.get(board + '/posts?notices=' + mode);
    expect(r.status(), await r.text()).toBe(200);
    return (await r.json()).items.filter((item: { id: number }) => [regularId, noticeId].includes(item.id));
  };
  expect(await list('only')).toMatchObject([
    { id: noticeId, markerId: null, kind: 'notice', isNotice: true },
    { id: regularId, markerId: marker.insertId, kind: 'question', isNotice: true },
  ]);
  expect(await list('exclude')).toEqual([]);
  expect((await admin.api.put(pin, { data: { isNotice: false } })).status()).toBe(204);
  expect((await admin.api.put(pin, { data: { isNotice: false } })).status()).toBe(204);
  expect(await list('only')).toMatchObject([{ id: noticeId }]);
  expect(await list('exclude')).toMatchObject([{ id: regularId, kind: 'question', isNotice: false }]);
});

test('marker threads, district filtering, reply privacy and read state', async ({ api, db, users }) => {
  const [author, visitor] = await Promise.all([users.create(), users.create()]);
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location, Address) VALUES (?, ST_GeomFromText('POINT(37.25 127.05)', 4326), ?)",
    [author.userId, '경기도 수원시 영통구 영통동 123'],
  );
  const data = { markerId: marker.insertId, kind: 'question', title, body, rulesAccepted: true };
  expect((await api.post(board + '/posts', { data })).status()).toBe(401);
  expect((await api.get(board + '/inbox')).status()).toBe(401);
  expect((await author.api.post(board + '/posts', { data: { ...data, title: ' ' } })).status()).toBe(400);
  expect((await author.api.post(board + '/posts', { data: { ...data, markerId: 2_000_000_000 } })).status()).toBe(404);
  const created = await author.api.post(board + '/posts', { data });
  expect(created.status(), await created.text()).toBe(201);
  const { id } = await created.json();
  const path = board + '/posts/' + id;

  // Fetching a thread or reloading it does not automatically count another view.
  expect(await (await api.get(path)).json()).toMatchObject({ post: { viewCount: 0 } });
  const view = path + '/view';
  expect((await api.post(view, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1)' } })).status()).toBe(204);
  const browser = { headers: { 'User-Agent': 'Mozilla/5.0 Firefox/130.0' } };
  const opens = await Promise.all([api.post(view, browser), api.post(view, browser)]);
  expect(opens.map((response) => response.status()).sort()).toEqual([200, 204]);
  expect(await opens.find((response) => response.ok() && response.status() === 200)?.json()).toEqual({ viewCount: 1 });
  expect(await (await api.get(path)).json()).toMatchObject({ post: { viewCount: 1 } });

  const query = new URLSearchParams({ markerId: String(marker.insertId), kind: 'question', region: '경기 수원시 영통구' });
  const listed = await api.get(board + '/posts?' + query);
  expect(listed.status(), await listed.text()).toBe(200);
  expect(await listed.json()).toMatchObject({ items: [{ id, title, body, markerId: marker.insertId, replyCount: 0 }], next: 0 });
  query.set('region', '경기 수원시 권선구');
  expect(await (await api.get(board + '/posts?' + query)).json()).toEqual({ items: [], next: 0 });

  expect((await visitor.api.delete(path)).status()).toBe(403);
  expect((await api.post(path + '/replies', { data: { body } })).status()).toBe(401);
  expect((await author.api.post(path + '/replies', { data: { body: '다음 주에 갈 예정이에요.' } })).status()).toBe(201);
  const answer = await visitor.api.post(path + '/replies', { data: { body: '입구 오른쪽에 낮은 철봉이 하나 있어요.', rulesAccepted: true } });
  expect(answer.status(), await answer.text()).toBe(201);
  const reply = await answer.json();
  expect(await (await api.get(path)).json()).toMatchObject({
    post: { replyCount: 2 }, replies: { items: [{ userId: author.userId }, { id: reply.id, userId: visitor.userId }], next: 0 },
  });
  expect(await (await visitor.api.get(board + '/inbox')).json()).toEqual([]);
  expect(await (await author.api.get(board + '/inbox')).json()).toMatchObject([{ id: reply.id, postId: id, title, seen: false }]);
  expect((await visitor.api.post(path + '/read', { data: { through: reply.id } })).status()).toBe(204);
  expect(await (await author.api.get(board + '/inbox?summary=1')).json()).toEqual({ unread: true });
  expect((await author.api.post(path + '/read', { data: { through: reply.id } })).status()).toBe(204);
  expect(await (await author.api.get(board + '/inbox?summary=1')).json()).toEqual({ unread: false });
  expect(await (await author.api.get(board + '/inbox')).json()).toMatchObject([{ id: reply.id, seen: true }]);
  expect((await author.api.delete(path + '/replies/' + reply.id)).status()).toBe(404);
  expect((await visitor.api.delete(path + '/replies/' + reply.id)).status()).toBe(204);
  expect(await (await author.api.get(board + '/inbox')).json()).toEqual([]);

  await db.execute('DELETE FROM Markers WHERE MarkerID = ?', [marker.insertId]);
  expect(await (await api.get(path)).json()).toMatchObject({ post: { markerId: null, address: '경기도 수원시 영통구 영통동 123' } });
  expect((await author.api.delete(path)).status()).toBe(204);
  expect((await api.get(path)).status()).toBe(404);
});

test('visit notes accept text alone or a verified photo', async ({ db, api, users }) => {
  const author = await users.create();
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location) VALUES (?, ST_GeomFromText('POINT(37.24 127.06)', 4326))", [author.userId],
  );
  const data = { markerId: marker.insertId, kind: 'review', title: '입구 오른쪽에 낮은 봉', body, rulesAccepted: true };
  const text = await author.api.post(board + '/posts', { data });
  expect(text.status(), await text.text()).toBe(201);
  expect(await (await api.get(board + '/posts/' + (await text.json()).id)).json()).toMatchObject({ post: { photoUrl: null } });
  const multipart = { ...data, markerId: String(data.markerId), rulesAccepted: "true", photo: { name: 'visit.png', mimeType: 'image/png', buffer: tinyPng() } };
  expect((await author.api.post(board + '/posts', { multipart: { ...multipart, kind: 'question' } })).status()).toBe(400);
  const photographed = await author.api.post(board + '/posts', { multipart });
  expect(photographed.status(), await photographed.text()).toBe(201);
  const url = board + '/posts/' + (await photographed.json()).id;
  const { post } = await (await api.get(url)).json();
  expect(post.photoUrl).toContain('/community/');
  expect((await api.get(post.photoUrl)).status()).toBe(200);
  expect((await author.api.delete(url)).status()).toBe(204);
  expect((await api.get(post.photoUrl)).status()).toBe(404);
});

test('tag filtering and the private moderation queue', async ({ api, db, users }) => {
  const [author, visitor, admin] = await Promise.all([
    users.create(), users.create(), users.create({ admin: true }),
  ]);
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location) VALUES (?, ST_GeomFromText('POINT(37.25 127.05)', 4326))",
    [author.userId],
  );
  const data = { markerId: marker.insertId, kind: 'question', title, body, topic: 'equipment', rulesAccepted: true };
  expect((await author.api.post(board + '/posts', { data: { ...data, topic: 'unknown' } })).status()).toBe(400);
  const created = await author.api.post(board + '/posts', { data });
  expect(created.status(), await created.text()).toBe(201);
  const { id } = await created.json();
  const path = board + '/posts/' + id;
  const posts = board + '/posts?markerId=' + marker.insertId + '&topic=';
  expect(await (await api.get(posts + 'equipment')).json()).toMatchObject({ items: [{ id, topic: 'equipment' }] });
  expect(await (await api.get(posts + 'training')).json()).toEqual({ items: [], next: 0 });
  expect((await api.get(board + '/moderation')).status()).toBe(401);
  expect((await visitor.api.get(board + '/moderation')).status()).toBe(403);
  expect((await visitor.api.post(board + '/moderation/' + id + '/dismiss', { data: { replyId: 0 } })).status()).toBe(403);

  const reply = await visitor.api.post(path + '/replies', { data: { body: '이곳은 공원 입구 오른쪽이에요.', rulesAccepted: true } });
  expect(reply.status(), await reply.text()).toBe(201);
  const { id: replyId } = await reply.json();
  const report = { reason: 'spam', replyId: 0 };
  expect((await author.api.post(path + '/report', { data: report })).status()).toBe(400);
  expect((await api.post(path + '/report', { data: report })).status()).toBe(401);
  expect((await visitor.api.post(path + '/report', { data: { ...report, reason: 'injected' } })).status()).toBe(400);
  for (let i = 0; i < 2; i++) {
    expect((await visitor.api.post(path + '/report', { data: report })).status()).toBe(204);
  }
  expect((await admin.api.post(path + '/report', { data: { replyId, reason: 'privacy' } })).status()).toBe(204);
  const queue = async () => {
    const response = await admin.api.get(board + '/moderation');
    expect(response.status(), await response.text()).toBe(200);
    return (await response.json()).filter((item: { postId: number }) => item.postId === id);
  };
  expect(await queue()).toMatchObject([
    { postId: id, replyId: null, reasons: 'spam', count: 1 },
    { postId: id, replyId, count: 1, reasons: 'privacy' },
  ]);
  const focusedQueue = `${board}/moderation?postId=${id}&replyId=${replyId}`;
  expect((await visitor.api.get(focusedQueue)).status()).toBe(403);
  expect(await (await admin.api.get(focusedQueue)).json()).toMatchObject([{ postId: id, replyId, count: 1 }]);
  expect((await admin.api.post(board + '/moderation/' + id + '/dismiss', { data: { replyId: 0 } })).status()).toBe(204);
  expect(await queue()).toMatchObject([{ postId: id, replyId }]);
  expect((await admin.api.delete(path + '/replies/' + replyId)).status()).toBe(204);
  expect(await (await admin.api.get(focusedQueue)).json()).toEqual([]);
  expect(await queue()).toEqual([]);
  expect((await api.get(path)).status()).toBe(200);
  expect((await author.api.delete(path)).status()).toBe(204);
});

test('posting rejects abusive text after Unicode normalization', async ({ db, users }) => {
  const author = await users.create();
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location) VALUES (?, ST_GeomFromText('POINT(37.25 127.05)', 4326))",
    [author.userId],
  );
  const data = { markerId: marker.insertId, kind: 'question', title, body, rulesAccepted: true };
  expect((await author.api.post(board + '/posts', { data: { ...data, title: 'ｆｕｃｋ' } })).status()).toBe(400);
  const created = await author.api.post(board + '/posts', { data });
  expect(created.status(), await created.text()).toBe(201);
  const { id } = await created.json();
  const path = board + '/posts/' + id;
  expect((await author.api.post(path + '/replies', { data: { body: 'f\u200buck' } })).status()).toBe(400);
  expect((await author.api.delete(path)).status()).toBe(204);
});

test('first-write consent and temporary or account-wide moderation', async ({ api, db, users }) => {
  const [author, visitor, admin] = await Promise.all([users.create(), users.create(), users.create({ admin: true })]);
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location) VALUES (?, ST_GeomFromText('POINT(37.25 127.05)', 4326))", [author.userId],
  );
  const data = { markerId: marker.insertId, kind: 'question', title, body };
  expect((await author.api.post(board + '/posts', { data })).status()).toBe(409);
  const created = await author.api.post(board + '/posts', { data: { ...data, rulesAccepted: true } });
  expect(created.status(), await created.text()).toBe(201);
  const { id } = await created.json();
  const path = board + '/posts/' + id;
  expect((await visitor.api.post(path + '/replies', { data: { body } })).status()).toBe(409);
  expect((await visitor.api.post(path + '/replies', { data: { body, rulesAccepted: true } })).status()).toBe(201);
  expect((await visitor.api.post(path + '/replies', { data: { body } })).status()).toBe(201);

  const target = board + '/restrictions/' + visitor.userId;
  const action = (value: string) => ({ data: { action: value, reason: 'spam' } });
  expect((await visitor.api.put(target, action('lift'))).status()).toBe(403);
  expect((await admin.api.put(board + '/restrictions/' + admin.userId, action('account'))).status()).toBe(403);
  expect((await admin.api.put(target, action('write1'))).status()).toBe(204);
  expect((await visitor.api.post(path + '/replies', { data: { body } })).status()).toBe(403);
  expect((await visitor.api.get(board + '/inbox')).status()).toBe(200);

  expect((await admin.api.put(target, action('account'))).status()).toBe(204);
  expect((await visitor.api.get(board + '/inbox')).status()).toBe(403);
  const login = await api.post('/api/v1/auth/login', { data: { email: visitor.email, password: visitor.password } });
  expect(login.status()).toBe(403);
  expect(await login.json()).toMatchObject({ code: 'ACCOUNT_BLOCKED' });
  expect(await (await admin.api.get(board + '/restrictions')).json()).toEqual(expect.arrayContaining([
    expect.objectContaining({ userId: visitor.userId, accountBlocked: true, reason: 'spam' }),
  ]));
  expect((await api.get(path)).status()).toBe(200);

  expect((await admin.api.put(target, action('lift'))).status()).toBe(204);
  const restored = await users.login(visitor.email, visitor.password);
  expect((await restored.api.post(path + '/replies', { data: { body } })).status()).toBe(201);
  expect((await author.api.delete(path)).status()).toBe(204);
});

test('public author history includes only that author and replies are capped at 300', async ({ api, db, users }) => {
  const [author, visitor, unlisted] = await Promise.all([users.create(), users.create(), users.create()]);
  const [marker] = await db.execute<ResultSetHeader>(
    "INSERT INTO Markers (UserID, Location) VALUES (?, ST_GeomFromText('POINT(37.25 127.05)', 4326))", [author.userId],
  );
  const seed = Array.from({ length: 21 }, (_, number) => [marker.insertId, author.userId, "", "", "question", `질문 ${number}`, body]);
  await db.query("INSERT INTO CommunityPosts(MarkerID, UserID, MarkerAddress, RegionKey, Kind, Title, Body) VALUES ?", [seed]);
  const authorPath = board + "/authors/" + author.userId;
  const firstResponse = await api.get(authorPath);
  expect(firstResponse.status(), await firstResponse.text()).toBe(200);
  const first = await firstResponse.json();
  expect(first.username).toBe(author.username);
  expect(first.items).toHaveLength(20);
  expect(first.items.every((item: { userId: number }) => item.userId === author.userId)).toBe(true);
  expect(first.next).toBe(first.items[19].id);
  const next = await (await api.get(authorPath + "?before=" + first.next)).json();
  expect(next).toMatchObject({ username: author.username, next: 0, items: [{ title: "질문 0" }] });

  expect((await api.get(board + "/authors/" + unlisted.userId)).status()).toBe(404);
  const replies = board + "/posts/" + first.items[0].id + "/replies";
  expect((await visitor.api.post(replies, { data: { body: "가".repeat(301), rulesAccepted: true } })).status()).toBe(400);
  expect((await visitor.api.post(replies, { data: { body: "가".repeat(300), rulesAccepted: true } })).status()).toBe(201);
  expect(await (await api.get(board + "/authors/" + visitor.userId)).json()).toEqual({
    username: visitor.username, items: [], next: 0,
  });
  await db.execute("DELETE FROM CommunityPosts WHERE UserID = ?", [author.userId]);
});

test('older unread replies remain reachable after the first 30 notices', async ({ db, users }) => {
  const [owner, author] = await Promise.all([users.create(), users.create()]);
  const [post] = await db.execute<ResultSetHeader>("INSERT INTO CommunityPosts(UserID,MarkerAddress,RegionKey,Kind,Title,Body) VALUES(?,'','','review','notifications','body')", [owner.userId]);
  const rows = Array.from({ length: 31 }, (_, i) => [post.insertId, author.userId, owner.userId, 'reply', i ? new Date() : null]);
  await db.query('INSERT INTO CommunityReplies(PostID,UserID,NotifyUserID,Body,ReadAt) VALUES ?', [rows]);
  const legacy = await (await owner.api.get(board + '/inbox')).json();
  const first = await (await owner.api.get(board + '/inbox?paged=1')).json();
  expect(first.items).toHaveLength(30);
  expect(first.items).toEqual(legacy);
  expect(first.next).toBe(legacy[29].id);
  const last = await (await owner.api.get(board + '/inbox?paged=1&before=' + first.next)).json();
  expect(last).toMatchObject({ items: [{ postId: post.insertId, seen: false }], next: 0 });
  expect(last.items[0].id).toBeLessThan(first.next);
  expect((await owner.api.get(board + '/inbox?paged=1&before=-1')).status()).toBe(400);
});

import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { test, expect } from '../fixtures';

const exec = promisify(execFile);
const enqueue = (id: number) => exec('docker', ['compose', 'exec', '-T', 'redis', 'redis-cli',
  'XADD', 'search:marker-updates', '*', 'markerId', String(id)]);

for (const scenario of [
  { term: 'Busanjin-gu', canonical: '부산진구', address: '부산광역시 부산진구 당감동 899', point: 'POINT(35.168 129.021)' },
  { term: '여수시웅천', canonical: '여수시 웅천', address: '전라남도 여수시 웅천동 1846', point: 'POINT(34.748 127.675)' },
  { term: '마곡나루역 철봉', canonical: '마곡나루역', address: '서울특별시 강서구 마곡동 743-3', point: 'POINT(37.567 126.828)' },
  { term: '재능대학교 제물포캠퍼스', canonical: '재능대', address: '인천광역시 미추홀구 도화동 193-12', point: 'POINT(37.475 126.654)' },
  { term: 'geukdong', canonical: '충북 극동대', address: '충청북도 음성군 감곡면 왕장리 450', point: 'POINT(37.127407 127.644136)' },
  { term: 'Geukdong University', canonical: '충북 극동대', address: '충청북도 음성군 감곡면 왕장리 450', point: 'POINT(37.127407 127.644136)' },
]) {
  test(`recent zero-result search resolves: ${scenario.term}`, async ({ api, db, users }) => {
    test.setTimeout(60_000);
    const owner = await users.create();
    const [insert]: any = await db.execute(
      'INSERT INTO Markers (UserID, Location, Address) VALUES (?, ST_GeomFromText(?, 4326), ?)',
      [owner.userId, scenario.point, scenario.address]);
    const id = insert.insertId;
    const find = async (term: string) => {
      const res = await api.get(`/api/v1/search/marker?term=${encodeURIComponent(term)}`);
      expect(res.status(), await res.text()).toBe(200);
      const body = await res.json();
      expect(Array.isArray(body.markers)).toBe(true);
      return body.markers.find((marker: any) => marker.markerId === id);
    };
    try {
      await enqueue(id);
      await expect.poll(() => find(scenario.canonical), { timeout: 20_000 }).toBeTruthy();
      expect(await find(scenario.term)).toMatchObject({ markerId: id, photoCount: 0, facilityCount: 0, facilityTotal: 0 });
      // Repeated queries must retain the same response contract when cached.
      expect(await find(scenario.term)).toMatchObject({ markerId: id, photoCount: 0 });
    } finally {
      await db.execute('DELETE FROM Markers WHERE MarkerID = ?', [id]);
      await enqueue(id);
    }
  });
}

test('a committed marker move refreshes search and summaries remain fresh', async ({ api, db, users }) => {
  test.setTimeout(60_000);
  const suffix = Date.now();
  const oldAddress = `서울특별시 강남구 이전주소검증${suffix}`;
  const address = `서울특별시 강남구 이동주소검증${suffix}`;
  const owner = await users.create();
  const [insert]: any = await db.execute(
    "INSERT INTO Markers (UserID, Location, Address) VALUES (?, ST_GeomFromText('POINT(37.5 127)', 4326), ?)", [owner.userId, oldAddress]);
  const id = insert.insertId;
  const lookup = async (term: string) => {
    const res = await api.get(`/api/v1/search/marker?term=${encodeURIComponent(term)}`);
    expect(res.status(), await res.text()).toBe(200);
    return (await res.json()).markers.find((m: any) => m.markerId === id);
  };
  try {
    await enqueue(id);
    await expect.poll(async () => (await lookup(`이전주소검증${suffix}`))?.address,
      { timeout: 20_000 }).toContain(`이전주소검증${suffix}`);
    await db.execute("UPDATE Markers SET Address = ?, Location = ST_GeomFromText('POINT(37.501 127)', 4326), UpdatedAt = NOW() WHERE MarkerID = ?", [address, id]);
    await enqueue(id);
    await expect.poll(async () => (await lookup(`이동주소검증${suffix}`))?.address,
      { timeout: 20_000 }).toContain(`이동주소검증${suffix}`);
    expect(await lookup(`이동주소검증${suffix}`)).toMatchObject({ photoCount: 0, facilityCount: 0, facilityTotal: 0 });

    // The address search is warm, but new photos/facilities must appear immediately.
    await db.execute('INSERT INTO Photos (MarkerID, PhotoURL, ThumbnailURL) VALUES (?, ?, ?)',
      [id, 'https://example.test/photo.jpg', 'https://example.test/thumb.webp']);
    await db.execute('INSERT INTO MarkerFacilities (MarkerID, FacilityID, Quantity) VALUES (?, 1, 2)', [id]);
    expect(await lookup(`이동주소검증${suffix}`)).toMatchObject({
      thumbnailUrl: 'https://example.test/thumb.webp', photoCount: 1, facilityCount: 1, facilityTotal: 2,
    });
  } finally {
    await db.execute('DELETE FROM Markers WHERE MarkerID = ?', [id]);
    await enqueue(id);
  }
});
